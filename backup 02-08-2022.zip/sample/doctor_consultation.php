<?php
    $host = "localhost";
    $user = "u964751242_whealth";
    $dbname = "u964751242_whealth";
    $pass = "6!xl+msLx";
    $conn = mysqli_connect($host, $user, $pass, $dbname);

    if($_GET['error'] != "") {
        echo $_GET['error'];
        echo '<br/>';
    }
?>
<form action="" method="POST">
    
</form>
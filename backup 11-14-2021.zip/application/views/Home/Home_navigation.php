		<nav class="navbar navbar-whealth navbar-fixed-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#whealth-navigation">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#" style="padding: 6px;">
					    <img src="<?php echo base_url() . 'assets/img/whealth.png'; ?>" style="padding: 0px; height: 100%;">
					    </a>
				</div>

				<div class="collapse navbar-collapse" id="whealth-navigation">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="<?=base_url('/home');?>">Home</a></li>
						<li><a href="#services">Services</a></li>
						<li><a href="#aboutus">About Us</a></li>
						<li><a href="#downloadOurApp">Our App!</a></li>
						<li><a href="#inquiries">Inquiries</a></li>
						<li><a href="#contactus">Contact Us</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<style>
		@import url('https://fonts.googleapis.com/css2?family=Glory&display=swap');body{font-family:'Glory',sans-serif;}
		    .navbar-whealth { font-family:'Glory',sans-serif;border-radius: 0; margin-bottom: 0px; min-height: 85px; background-color: #fff; border-color: transparent; }.navbar-nav>li>a { font-size: 17px;padding-top: 10px; padding-bottom: 10px; line-height: 65px; color:#0c9cfe;}.navbar-brand { float: left; height: 85px; padding: 19.5px 15px; font-size: 19px; line-height: 21px; }
		</style>

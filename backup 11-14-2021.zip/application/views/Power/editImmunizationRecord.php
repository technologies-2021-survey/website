<?php $result = (array) $immunizations; ?>
<?php $this->load->view('Power/navigation'); ?>
<?php 
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
    <h4>Edit Immunization Record</h4>
    <form action="<?php echo base_url().$textss; ?>/editImmunizationRecord/<?php echo $this->uri->segment(3); ?>" method="POST">
        <div class="form-group">
            <label>Patient Name</label>
            <input type="text" name="patient_name" class="form-control" value="<?php echo $patient_name; ?>" disabled="">
        </div>
        <div class="form-group">
            <label>Parent Name</label>
            <input type="text" name="parent_name" class="form-control" value="<?php echo $parent_name; ?>" disabled="">
        </div>
        <div class="form-group">
            <label>Date</label>
            <input type="date" name="dates" class="form-control" value="<?php echo $result[0]['date']; ?>">
        </div>
        <div class="form-group">
            <label>Vaccine</label><br/>
            <select name="vaccine" class="form-control" required="">
                <?php
                $q = $this->db->query("SELECT * FROM vaccine_terms_tbl");
                foreach($q->result_array() as $row) {
                    $asdsd = $this->db->query("SELECT * FROM `immunization_record` WHERE `immunization_record_id` = '".$asd."'")->result_array();
                    if($vaccine_id == $asdsd[0]['immunization_record_id']) {
                        echo '<option value="'.$row['vaccine_terms_id'].'" selected="">'.$row['vaccine_terms_title'].'</option>';
                    } else {
                        echo '<option value="'.$row['vaccine_terms_id'].'">'.$row['vaccine_terms_title'].'</option>';
                    }
                    
                }
                ?>
            </select>
        </div>
        <script>
        $(document).ready(function(){
            $('select[name=vaccine]').multiselect({
                nonSelectedText: 'Select Vaccine',
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                buttonWidth:'400px',
            });
        });
        </script>
        <div class="form-group">
            <label>Route</label>
            <input type="text" name="route" class="form-control" value="<?php echo $result[0]['route']; ?>">
        </div>
        <div class="pull-right">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
        </div>
        <div style="clear:both;"></div>
    </form>

                
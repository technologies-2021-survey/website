<?php $this->load->view('Power/navigation'); ?>

    <h4>Consultation Request</h4>
    <div class="row">
        <div class="col-sm-3">
            <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control" style="margin-bottom: 10px;">
                <option value="" selected="">Consultation Requests</option>
                <option value="./consultation">Consultation</option>
            </select>
        </div>
        <div class="col-sm-3">
                <?php
                $array = array('','','','');
                if(isset($_GET['filter'])) {
                    if($_GET['filter'] == "") {
                        $array[0] = 'selected';
                    } else if($_GET['filter'] == "pending") {
                        $array[1] = 'selected';
                    } else if($_GET['filter'] == "approved") {
                        $array[2] = 'selected';
                    } else if($_GET['filter'] == "finished") {
                        $array[3] = 'selected';
                    }
                }
                ?>
                <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control" style="margin-bottom: 10px;">
                    <option value="?filter=" <?php echo $array[0]; ?>>Filter: All</option>
                    <option value="?filter=pending" <?php echo $array[1]; ?>>Filter: Pending</option>
                    <option value="?filter=approved" <?php echo $array[2]; ?>>Filter: Approved</option>
                    <option value="?filter=finished" <?php echo $array[3]; ?>>Filter: Finished</option>
                </select>
            </div>
    </div>
    <div class="search">
        <?php
            $textss = "";
            if($this->session->selection == "doctor") {
                $textss = "doctor";
            } else if($this->session->selection == "receptionist") {
                $textss = "receptionist";
            } else if($this->session->selection == "administrator") {
                $textss = "administrator";
            } 
            foreach($consultations as $row) {
                echo '<div class="consultation-'.$row['consultation_id'].'">';
                    echo '<div class="consultation-heading" style="padding: 10px;box-shadow: 0 0 2px #000 inset;">';
                        echo $row['parent_name'];
                        echo '<div class="pull-right">';
                            if($row['consultation_status'] == "Refund") {
                                echo '<b style="color:red;">';
                            }
                            echo $row['consultation_status'];
                            if($row['consultation_status'] == "Refund") {
                                echo '</b>';
                            }
                        echo '</div>';
                        echo '<div style="clear:both;"></div>';
                    echo '</div>';
                    echo '<div class="consultation-body" style="background: rgb(244 244 244);display: none;word-break:break-all;height: 600px;overflow-y: scroll; padding: 20px;">';
                        echo '<label>Parent Name:</label><br/>';
                        echo $row['parent_name'];
                        echo '<br/><br/>';

                        echo '<label>Patient Name:</label><br/>';
                        echo $row['patient_name'];
                        echo '<br/><br/>';

                        echo '<label>Date Consultation:</label><br/>';
                        echo $row['date_consultation_datetime'];
                        echo '<br/><br/>';

                        echo '<label>Date Consultation End:</label><br/>';
                        echo $row['date_consultation_datetime_end'];
                        echo '<br/><br/>';

                        echo '<label>Reason:</label><br/>';
                        echo $row['reason'];
                        echo '<br/><br/>';

                        echo '<label>Money:</label> P'.$row['money'];
                        echo '<br/><br/>';
                    
                        echo '<label>Proof of Transaction:</label><br/>';
                        echo '<img src="data:image/png;base64,'.$row['consultation_proof_of_transaction'].'" class="pot" style="display:block;width: 100px;margin-bottom: 20px;"/>';
                        
                        if($row['consultation_prescription'] != "") {
                            echo '<label>Prescriptions:</label><br/>';
                            echo $row['consultation_prescription'];
                        }
                        if($row['consultation_status'] == "Finished" || $row['consultation_status'] == "Cancelled") {
                            
                        } else {
                            echo '<hr/>';

                            if($row['consultation_status'] == "Pending") {
                                echo '<div class="row">';
                                    echo '<div class="col-md-4">';
                                        echo '<a href="'.base_url().''.$textss.'/approveConsultation/'.$row['consultation_id'].'"><button id="donePrescription" data-id="'.$row['consultation_id'].'" class="btn btn-success btn-block">Approve Consultation</button></a>';
                                    echo '</div>';
                                    echo '<div class="col-md-4">';
                                        echo '<a href="'.base_url().''.$textss.'/cancelConsultation/'.$row['consultation_id'].'"><button class="btn btn-success btn-block">Cancel Consultation</button></a>';
                                    echo '</div>';
                                echo '</div>';
                            } else if($row['consultation_status'] != "Refund") {
                                if($row['interview_id'] == "0") {
                                    echo '<label>Interview:</label><br/>';
                                    
                                    if(isset($_POST['submitDoctorInterview'])) {
                                        $doctor_id = $_POST['doctor_id'];

                                        $displays = $this->db->query("SELECT * FROM `doctors_tbl` WHERE `doctor_id` = '".$doctor_id."'");
                                        if($displays->num_rows() > 0) {
                                            // exist
                                            $this->db->query("UPDATE `consultations` SET `interview_id` = '".$doctor_id."' WHERE consultation_id = '".$row['consultation_id']."'"); // delete all
                                            redirect(base_url() . $textss .'/consultation_requests?success=Successfully!');
                                        } else {
                                            redirect(base_url() . $textss .'/consultation_requests?error=Error! There\'s something wrong!');
                                        }
                                       
                                    }
                                    echo '<form action="" method="POST" style="margin-bottom: 20px;">';
                                        echo '<div class="row">';
                                            echo '<div class="col-md-6">';
                                                echo '<select name="doctor_id" class="form-control" style="width:20%;">';
                                                    $displays2 = $this->db->query("SELECT * FROM `doctors_tbl`");
                                                    if($displays2->num_rows() > 0) {
                                                        //exist
                                                        foreach($displays2->result_array() as $display_row2) {
                                                            echo '<option value="'.$display_row2['doctor_id'].'" selected="">'.$display_row2['doctor_name'].'</option>';
                                                        }
                                                    } else {
                                                        // not exist
                                                        echo '<option>No doctor found.</option>';
                                                    }
                                                echo '</select>';
                                                echo '<button class="btn btn-primary" name="submitDoctorInterview" style="margin-top:20px;">Submit Doctor Interview</button>';
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</form>';
                                } else {
                                    // not exist
                                    echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
                                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />';
                                    
                                    
                                    if(isset($_POST['submitCommonIllness'])) {
                                        $this->db->query("DELETE FROM patients_illness_tbl WHERE `type` = 'consultations' AND id = '".$row['consultation_id']."'"); // delete all
                                        $common_illness = $_POST['common_illness'];


                                        $countError =0;
                                        foreach($common_illness as $rowzxc1) {
                                            $asdasd = $this->db->query("SELECT * FROM terms_tbl WHERE terms_id = '".$rowzxc1."'");
                                            if($asdasd->num_rows() > 0 ) {
                                                // exist
                                            } else {
                                                $countError++;
                                            }
                                        }

                                        if($countError != 0) {
                                            redirect($textss."/consultation_requests?error=There\'s something wrong.");
                                        }
                                        foreach($common_illness as $rowzxc) {
                                            $asdasddd = $this->db->query("SELECT * FROM terms_tbl WHERE `terms_id` = '".$rowzxc."'")->result_array();
                                            $this->db->query("INSERT INTO `patients_illness_tbl` (`type`, `id`, `terms_id`,`terms_title`, `timestamp`) VALUES('consultations', '".$row['consultation_id']."', '".$rowzxc."', '".$asdasddd[0]['terms_title']."','".time()."')");
                                            
                                        }
                                        redirect(base_url() . $textss .'/consultation_requests?success=Successfully!');
                                    }
                                    echo '<label>Common Illness:</label><br/>';
                                    echo '<form action="" method="POST" style="margin-bottom: 20px;">';
                                        echo '<div class="row">';
                                            echo '<div class="col-md-6">';
                                                echo '<select id="common_illness" name="common_illness[]" multiple class="form-control">';
                                                    $displays = $this->db->query("SELECT * FROM `terms_tbl`");
                                                    foreach($displays->result_array() as $display_row) {
                                                        $ifSelected = $this->db->query("SELECT * FROM `patients_illness_tbl` WHERE `type` = 'consultations' AND `id` = '".$row['consultation_id']."' AND `terms_id` = '".$display_row['terms_id']."'");

                                                        if($ifSelected->num_rows() > 0) {
                                                            //exist
                                                            echo '<option value="'.$display_row['terms_id'].'" selected="">'.$display_row['terms_title'].'</option>';
                                                        } else {
                                                            // not exist
                                                            echo '<option value="'.$display_row['terms_id'].'">'.$display_row['terms_title'].'</option>';
                                                        }
                                                        
                                                    }
                                                echo '</select>';
                                                echo '<button class="btn btn-primary" name="submitCommonIllness" style="margin-left:20px;">Submit Common Illness</button>';
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</form>';
                                    echo"<script>
                                        $(document).ready(function() {
                                            $('#common_illness').multiselect({
                                            nonSelectedText: 'Select Common Illness',
                                            enableFiltering: true,
                                            enableCaseInsensitiveFiltering: true,
                                            buttonWidth:'400px'
                                            });
                                        });
                                    </script>";

                                    echo '<br/><br/>';
                                    echo '<form action="'.base_url().''.$textss.'/sendlink" method="POST" style="margin-bottom: 20px;">';
                                        echo '<input type="hidden" name="id" value="'.$row['consultation_id'].'">';
                                        echo '<div class="form-group">';
                                            echo '<label>Google Link</label>';
                                            echo '<div class="input-group">';
                                                echo '<input type="text" name="googlelink" value="'.$row['googlelink'].'" class="form-control" placeholder="https://meet.google.com/......">';
                                                echo '<div class="input-group-btn">';
                                                    echo '<span class="input-group-btn">';
                                                        echo '<button class="btn btn-success" type="submit" name="submit">Send!</button>';
                                                    echo '</span>';
                                                echo '</div>';
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</form>';

                                    echo '<div class="row">';
                                        echo '<div class="col-md-4">';
                                            echo '<button id="addPrescription" data-id="'.$row['consultation_id'].'" class="btn btn-success btn-block">Add Prescription</button>';
                                        echo '</div>';
                                        echo '<div class="col-md-4">';
                                            echo '<a href="'.base_url().''.$textss.'/cancelConsultation/'.$row['consultation_id'].'"><button class="btn btn-success btn-block">Cancel Consultation</button></a>';
                                        echo '</div>';
                                        echo '<div class="col-md-4">';
                                            echo '<a href="'.base_url().''.$textss.'/doneConsultation/'.$row['consultation_id'].'"><button id="donePrescription" data-id="'.$row['consultation_id'].'" class="btn btn-success btn-block">Done Consultation</button></a>';
                                        echo '</div>';
                                    echo '</div>';
                                }
                                
                            }
                        }
                    echo '</div>';
                echo '</div>';
            }
        ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $('.consultation-heading').click(function() {
                    $(this).siblings(".consultation-body").slideToggle();
                    console.log(0);    
                });

                $('.pot').click(function() {
                    $('#viewModal').modal('show');
                    var image = $(this).attr("src");
                    $("#POT").attr("src", image);
                });

                $('#addPrescription').click(function() {
                    var hid = $(this).attr("data-id");
                    $('input[name=prescription_id]').attr("value", hid);
                    $('#addPrescriptionModal').modal('show');
                });
            });
        </script>
    </div>
    <?php
        echo $links;
    ?>
    <!-- Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">Proof of Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="#" id="POT">
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addPrescriptionModal" tabindex="-1" role="dialog" aria-labelledby="addPrescriptionModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPrescriptionModalLabel">Add Prescription</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url().$textss; ?>/addPrescription" method="POST">
                        <input type="hidden" name="prescription_id">
                        <div class="form-group">
                            <label>Add Prescription</label>
                            <textarea class="form-control" name="prescription" style="height: 200px;margin-bottom: 10px;"></textarea>
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
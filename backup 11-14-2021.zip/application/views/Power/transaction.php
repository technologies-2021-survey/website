<?php $this->load->view('Power/navigation'); ?>
<?php
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <h4>Transaction</h4>
    <?php
    
        foreach($transactions as $row) {
            echo '<div class="transaction-'.$row['overallId'].'">';
                    echo '<div class="transaction-heading" style="padding: 10px;box-shadow: 0 0 2px #000 inset;">';
                        echo $row['parent_name'];
                        echo ' / ';
                        echo ucfirst($row['category']);
                        echo '<div class="pull-right"><b>P'.$row['money'].'</b></div>';
                        echo '<div style="clear:both;"></div>';
                    echo '</div>';
                    echo '<div class="transaction-body"  style="background: rgb(244 244 244);display: none;word-break:break-all;height: 600px;overflow-y: scroll; padding: 20px;">';
                    
                        echo '<b>Parent Name:</b><br/>';
                        echo $row['parent_name'];
                        echo '<br/><br/>';
                        echo '<b>Patient Name:</b><br/>';
                        echo $row['patient_name'];
                        echo '<br/><br/>';
                        echo '<b>Date Start:</b><br/>';
                        echo $row['datetime'];
                        echo '<br/><br/>';
                        echo '<b>Date End:</b><br/>';
                        echo $row['datetime_end'];
                        echo '<br/><br/>';
                        echo '<b>Reference Number:</b><br/>';
                        echo $row['reference_number'];
                        echo '<br/><br/>';
                        echo '<b>Amount:</b><br/>P';
                        echo $row['money'];
                        echo '<br/><br/>';
                        if($row['category'] == "appointments") {
                            if($row['description'] != "") {
                                echo '<b>Description:</b><br/>';
                                echo $row['description'];
                                echo '<br/><br/>';
                            }
                        } else if($row['category'] == "consultations") {
                            if($row['prescription'] != "") {
                                echo '<b>Prescriptions:</b><br/>';
                                echo $row['prescription'];
                                echo '<br/><br/>';
                            }
                            if($row['reason'] != "") {
                                echo '<b>Reason:</b><br/>';
                                echo $row['reason'];
                                echo '<br/><br/>';
                            }
                        } 
                        echo '<b>Proof of Transaction:</b><br/>';
                        echo '<img src="data:image/png;base64,'.$row['proof_of_transaction'].'" class="pot" style="display:block;width: 100px;margin-bottom: 20px;"/>';
                        echo '<br/><br/>';
                        echo '<b>Status:</b><br/>';
                        echo $row['status'];
                    echo '</div>';
            echo '</div>';
        }
    ?>
    <?php echo $links; ?>
    <script type="text/javascript">
    $(document).ready(function() {

        $('.transaction-heading').click(function() {
            $(this).siblings(".transaction-body").slideToggle();
            console.log(0);    
        });
        $('.pot').click(function() {
            $('#viewModal').modal('show');
            var image = $(this).attr("src");
            $("#POT").attr("src", image);
        });
    });
    </script>
    <!-- Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">Proof of Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="#" id="POT"class="img-responsive">
                </div>
            </div>
        </div>
    </div>
<?php $this->load->view('Power/navigation'); ?>
<?php
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <h4>Patient List</h4>

	<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Patient Name</th>
                <th>Gender</th>
                <th>Birthdate</th>
                <th>Parent Name</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($patients as $row) {
                echo '<tr class="patients-'.$row['parent_id'].'">';
                    echo '<td>'.$row['patient_id'].'</td>';
                    echo '<td>'.$row['patient_name'].'</td>';
                    echo '<td>'.$row['patient_gender'].'</td>';


                    $birthDate = $row['patient_birthdate'];
                    $from = new DateTime($birthDate);
                    $to   = new DateTime('today');
                    $age = $from->diff($to)->y;

                    echo '<td>'.$row['patient_birthdate'].'<br/>(Age: '.$age.')</td>';
                    echo '<td>'.$row['parent_name'].'</td>';
                    echo '<td><a href="'.base_url().$textss.'//addImmunizationRecord/'.$row['patient_id'].'" class="btn btn-success" style="margin-bottom:10px;">Add Immunization Record</a><br/><a href="'.base_url().$textss.'//viewImmunizationRecord/'.$row['patient_id'].'" class="btn btn-warning">View Immunization Record</a></td>';
                    echo '<td><a href="'.base_url().$textss.'//addPediatricChart/'.$row['patient_id'].'" class="btn btn-info" style="margin-bottom:10px;">Add Pediatric Chart</a><br/><a href="'.base_url().$textss.'//viewPediatricChart/'.$row['patient_id'].'" class="btn btn-warning">View Pediatric Chart</a></td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
	</div>
    <?php echo $links; ?>

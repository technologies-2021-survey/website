<?php

$countConsultations = 0;
$countAppointments = 0;
$selectionz = "";
$array = array('','','','');
if(isset($_GET['v'])) {
    $v = $_GET['v'];
    if($v == "1week") {
        date_default_timezone_set("Asia/Manila");
        $timestamp = strtotime(date("M d, Y 00:00:00", time()));
        $array[0] = ' selected';
        $selectionz = strtotime("-7 day", $timestamp); // 7 days
    } else if($v == "2weeks") {
        date_default_timezone_set("Asia/Manila");
        $timestamp = strtotime(date("M d, Y 00:00:00", time()));
        $array[1] = ' selected';
        $selectionz = strtotime("-14 day", $timestamp); // 2 weeks
    } else if($v == "1month") {
        date_default_timezone_set("Asia/Manila");
        $timestamp = strtotime(date("M d, Y 00:00:00", time()));
        $array[2] = ' selected';
        $selectionz = strtotime("-1 month", $timestamp); // 1 month
    } else if($v == "1year") {
        date_default_timezone_set("Asia/Manila");
        $timestamp = strtotime(date("M d, Y 00:00:00", time()));
        $array[3] = ' selected';
        $selectionz = strtotime("-1 year", $timestamp); // 1year
    }
} else {
    $array[0] = ' selected';
    $selectionz = strtotime("-7 day", $timestamp); // 7 days
}
date_default_timezone_set("Asia/Manila");
$timestamp = strtotime(date("M d, Y 00:00:00", time()));

$q = $this->db->query("SELECT * FROM `consultations` WHERE (`date_consultation_sub` >= $selectionz OR `date_consultation_sub` <= $timestamp)");
foreach($q->result_array() as $row) {
    $countConsultations++;
}

$q2 = $this->db->query("SELECT * FROM `appointments` WHERE (`appointment_timestamp_sub` >= $selectionz OR `appointment_timestamp_sub` <= $timestamp)");
foreach($q2->result_array() as $row) {
    $countAppointments++;
}

$sum = $countAppointments + $countConsultations;

$timestamp2 = strtotime(date("M d, Y 00:00:00", time()));
$selection3 = strtotime("+1day -1minute", $timestamp2); // 1 month

$approved = 0;
$pending = 0;
$finished = 0;

$q3 = $this->db->query("SELECT * FROM `consultations` WHERE (`date_consultation_sub` >= $timestamp2 OR date_consultation_sub <= $selection3) AND consultation_status = 'Approved'");
foreach($q3->result_array() as $row) {
    $approved++;
}

$q4 = $this->db->query("SELECT * FROM `appointments` WHERE (`appointment_timestamp_sub` >= $timestamp2 OR appointment_timestamp_sub <= $selection3) AND appointment_status = 'Approved'");
foreach($q4->result_array() as $row) {
    $approved++;
}

$q5 = $this->db->query("SELECT * FROM `consultations` WHERE (`date_consultation_sub` >= $timestamp2 OR date_consultation_sub <= $selection3) AND consultation_status = 'Pending'");
foreach($q5->result_array() as $row) {
    $pending++;
}

$q6 = $this->db->query("SELECT * FROM `appointments` WHERE (`appointment_timestamp_sub` >= $timestamp2 OR appointment_timestamp_sub <= $selection3) AND appointment_status = 'Pending'");
foreach($q6->result_array() as $row) {
    $pending++;
}

$q7 = $this->db->query("SELECT * FROM `consultations` WHERE (`date_consultation_sub` >= $timestamp2 OR date_consultation_sub <= $selection3) AND consultation_status = 'Finished'");
foreach($q7->result_array() as $row) {
    $finished++;
}

$q8 = $this->db->query("SELECT * FROM `appointments` WHERE (`appointment_timestamp_sub` >= $timestamp2 OR appointment_timestamp_sub <= $selection3) AND appointment_status = 'Finished'");
foreach($q8->result_array() as $row) {
    $finished++;
}

?>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.1/Chart.min.js"></script>
<script type="text/javascript">

window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer", {
		title:{
			text: ""              
		},
		data: [              
		{
			// Change type to "doughnut", "line", "splineArea", etc.
			type: "column",
			dataPoints: [
				{ label: "Appointments",  y: <?php if($countAppointments == null || $countAppointments == "") {echo "0";} else {echo $countAppointments;} ?>   },
				{ label: "Consultations", y: <?php if($countConsultations == null || $countConsultations == "") {echo "0";} else {echo $countConsultations;} ?>  }
			]
		}
		]
	});
	chart.render();

    var canvas = document.getElementById("barChart");
    var ctx = canvas.getContext('2d');
    canvas.height = 140;

    // Global Options:
    Chart.defaults.global.defaultFontColor = 'black';
    Chart.defaults.global.defaultFontSize = 16;

    var data = {
        labels: ["Approved", "Pending", "Finished"],
        datasets: [
            {
                fill: true,
                backgroundColor: [
                    '#4f81bc',
                    '#c0504e',
                    '#cbc044'],
                data: [<?php echo $approved;?>, <?php echo $pending;?>, <?php echo $finished; ?>],
                borderColor: ['#4f81bc','#c0504e','#cbc044'],
                borderWidth: [2,2,2]
            }
        ]
    };

    // Notice the rotation from the documentation.

    var options = {
            title: {
                    display: false,
                },
            rotation: -0.7 * Math.PI,
            maintainAspectRatio: false,
    };


    // Chart declaration:
    var myBarChart = new Chart(ctx, {
        type: 'pie',
        data: data,
        options: options
    });
}
</script>
<div class="row">
    <div class="col-sm-6">
        <div class="panel panel-default" style="box-shadow: 0 0 1px #000;">
            <div class="panel-body">
                <h4>Status</h4>
                <div style="height: 344px;">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="panel panel-default" style="box-shadow: 0 0 1px #000;">
            <div class="panel-body">
                <h4>Number of Patients: <b><?php echo $sum; ?></b></h4>
                <div class="pull-right">
                    <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control" style="margin-bottom: 10px;">
                        <option value="?v=1week"<?php echo $array[0];?>>Last week</option>
                        <option value="?v=2weeks"<?php echo $array[1];?>>Last 2 weeks</option>
                        <option value="?v=1month"<?php echo $array[2];?>>Last 1 month</option>
                        <option value="?v=1year"<?php echo $array[3];?>>Last 1 year</option>
                    </select>
                </div>
                <div style="clear:both;"></div>
                <div id="chartContainer" style="height: 300px; width: 100%;"></div>
            </div>
        </div>
    </div>
</div>
<div class="row" style="margin-top: 20px;">
    <div class="col-sm-12">
        <h4>Next Patients</h4>
        <div class="row">
           <?php 
               $count = 1;
                foreach($nextPatients as $rows) {
                   echo '<div class="col-lg-12" style="width: 97%;positive:relative; height: 92px ; padding: 23px 18px; padding-left: 80px!important;margin: 30px;margin-bottom:0px!important; background: #eee; border-radius: 100px; display: inline-flex;">
                        <span style=" position: absolute; left: 2%; top: 32%; font-size: 22px; font-weight: bold; ">
                            '.$count.'
                        </span>
                        <div class="col-sm-6">
                            Parent Name: '.$rows['parent_name'].'
                            <br/>Patient Name: '.$rows['patient_name'].'<br/>
                            '.ucfirst($rows['category']).'
                        </div>
                        <div class="col-sm-6">
                            Date Time: '.$rows['datetime'].' 
                            <br/> Date End: '.$rows['datetime_end'].'
                        </div>
                   </div>';
                   $count++;
                }
           ?>
        </div>
    </div>
</div>

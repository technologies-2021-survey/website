<?php
    $userInfo = "";
    foreach($data as $row) {
        $userInfo = $row;
    }
?>
		<nav role="navigation" class="navbar" style="background-color: #1982c4;">
			<div class="container-fluid">
				<div class="navbar-header">
					<button data-target="#whealth-navigation" data-toggle="collapse" class="navbar-toggle" type="button">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#" style="margin-left: 0px; color: #fff;">WHealth</a>
				</div>

				<div id="whealth-navigation" class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
					<?php
						$texts = "";
						$names = "";
						if($this->session->selection == "doctor") {
							$texts = "doctor";
							$names = $userInfo->doctor_name;
						} else if($this->session->selection == "receptionist") {
							$texts = "receptionist";
							$names = $userInfo->receptionist_name;
						} else if($this->session->selection == "administrator") {
							$texts = "administrator";
							$names = $userInfo->admin_name;
						}
					?>
						<li><a href="<?=base_url('/'.$texts);?>" style="color: #fff;">Home</a></li>
						<li class="dropdown">
                            			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="color: #fff;"><?=$names;?><span class="caret"></span></a>
                            			<ul class="dropdown-menu" role="menu" style="background-color: #1982c4; color: #fff;">
                                <li>
								<a href="<?=base_url('/'.$texts.'/change_profile_picture');?>">Change Profile Picture</a>
								<a href="<?=base_url('/'.$texts.'/logout');?>">Logout</a>
                                </li>
                            </ul> 
                        </li>
						<li><a href="<?=base_url('/'.$texts.'/messages');?>" style="color: #fff;">Messages</a></li>
						<li><a href="<?=base_url('/'.$texts.'/logout');?>" style="color: #fff;">Log out</a></li>
					</ul>
				</div>
			</div>
		</nav>

		<div class="container-fluid">
			<div class="row row-offcanvas row-offcanvas-left">
				<?php $this->load->view('Power/Include/sidebar'); ?>
				<div class="col-xs-12 col-sm-9 content">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a></h3>
						</div>
						<div class="panel-body">
						

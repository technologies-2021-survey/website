<?php $this->load->view('Power/navigation'); ?>

<h4>Add Access Privilege / <?php echo $name; ?></h4>
<?php 
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
}

/*
    1. Inquiries List - View Inquiry
    2. - Delete Inquiry
    3. Appointment - View Appointment
    ** none ** 4. Payment - View Payment
    5. Consultation - View Consultation
    6. Transaction - View Transaction
    7. Immunization Record - View Immunization
    8. - Add Immunization Record
    9. - Edit Immunization Record
    10. - Delete Immunization
    11. Parent List - View Parent List
    12. - Add Parent
    13. - View Child List
    14. - Add Child
    15. - Edit Child
    16. - Delete Child
    17. Patient List - View Patient List
    18. Access Privilege
    19. Report Generation
    20. Patient Satisfaction
    21. Data Analytics
    22. Management

    
*/
$count = 1;
$arraysz = array(
    'View Inquiry', // 1 @
    'Delete Inquiry', // 2
    'View Appointment', // 3 @
    'View Payment', // @
    'View Consultation', // 5 @
    'View Transaction', // 6 @
    'View Immunization Record', // 7 @
    'Add Immunization Record', // 8
    'Edit Immunization Record', // 9
    'Delete Immunization Record', // 10
    'View Parent List', // 11 @
    'Add Parent', // 12
    'View Child List', // 13 
    'Add Child', // 14
    'Edit Child', // 15
    'Delete Child', // 16
    'Patient List', // 17 @
    'Access Privilege', // 18
    'View Announcement', // 19
    'Add Announcement', // 20
    'Delete Announcement', // 21
    'Edit Announcement', // 22
    'View Patient Satisfaction Questions', //23
    'Add Patient Satisfaction Questions', //24
    'Delete Patient Satisfaction Questions', //25
    'Edit Patient Satisfaction Questions', //26
    'Report Generation', //27
    'Patient Satisfaction', //28
    'Data Analytics', //29
    'Management',//30
    'View Pediatric Chart', //31
    'Add Pediatric Chart', //32
    'Edit Pediatric Chart', //33
    'Delete Pediatric Chart', //34
    'Health Tips' // 35
);
?>
<style type="text/css">select.form-control { width: 15%; }</style>
<?php //echo var_dump($user); ?>
<form action="<?php echo base_url() . $textss; ?>/addAccessPrivilege/<?php echo $idd; ?>/<?php echo $selectionn;?>" method="POST">
    <?php
    for($i=0;$i<36;$i++){
        echo '<div class="form-group">';
            echo '<label>'.($i+1).'. '.$arraysz[$i].'</label>';
            echo '<select class="form-control" required=""  name="add[]">';
                if($this->power_model->getAccessPrivilegeRow($idd, $selectionn, ($i+1)) == 1) {
                    // exist, off
                    echo '<option value="OFF" selected>OFF</option>';
                    echo '<option value="ON">ON</option>';
                } else {
                    // not exist, on
                    echo '<option value="ON" selected>ON</option>';
                    echo '<option value="OFF">OFF</option>';
                }
                
            echo '</select>';
        echo '</div>';
    }
    ?>
    <div class="pull-right">
        <input type="submit" name="submit" value="Submit" class="btn btn-primary">
    </div>
    <div style="clear:both;"></div>
</form>
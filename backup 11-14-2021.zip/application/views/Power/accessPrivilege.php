<?php $this->load->view('Power/navigation'); ?>

    <h4>Access Privilege</h4>
    <div class="search">

        <?php 
            $array = array();

            function check($id, $selection, $arrays) {
                $status = '';
                for($i = 0; $i < count($arrays); $i++) {
                    if($arrays[$i]['id'] == $id && $arrays[$i]['selection'] == $selection) {
                        $status = 'exist';
                        break;
                    }
                }
                return $status;
            }

            foreach($accessprivileges as $row) {
                if(check($row['doctor_id'], '1', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['doctor_id'],
                        'selection' => '1'
                    );
                }
                if(check($row['receptionist_id'], '2', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['receptionist_id'],
                        'selection' => '2'
                    );
                }
                if(check($row['admin_id'], '3', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['admin_id'],
                        'selection' => '3'
                    );
                }
            }
            foreach($array as $display) {
                $result = $this->power_model->getUserInfo($display['id'],$display['selection']);
                foreach($result as $data) {
                    $x = "";
                    if($display['selection'] == 1) {
                        //doctor
                        $x .= "<b>".$data['doctor_name']."</b>";
                        $x .= '<a href="'.base_url().'/administrator/addAccessPrivilege/'.$display['id'].'/'.$display['selection'].'" class="btn btn-info pull-right">Access Privilege</a>';
                        $x .= "<span style='display:block;'>Doctor</span>";
                    } else if($display['selection'] == 2) {
                        // admin
                        $x .= "<b>".$data['admin_name']."</b>";
                        $x .= '<a href="'.base_url().'/administrator/addAccessPrivilege/'.$display['id'].'/'.$display['selection'].'" class="btn btn-info pull-right">Access Privilege</a>';
                        $x .= "<span style='display:block;'>Administrator</span>";
                    } else if($display['selection'] == 3) {
                        // receptionist
                        $x .= "<b>".$data['receptionist_name']."</b>";
                        $x .= '<a href="'.base_url().'/administrator/addAccessPrivilege/'.$display['id'].'/'.$display['selection'].'" class="btn btn-info pull-right">Access Privilege</a>';
                        $x .= "<span style='display:block;'>Receptionist</span>";
                    }
                    echo '<div class="well">';
                        echo $x;
                        echo '<div style="clear:both;"></div>';
                    echo '</div>';
                }
            }
            echo $links;
        ?>
    </div>
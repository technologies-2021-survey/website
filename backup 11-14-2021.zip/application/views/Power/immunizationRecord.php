<?php $this->load->view('Power/navigation'); ?>
<?php 
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <h4>Immunization Record</h4>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Patient Name</th>
                <th>Date</th>
                <th>Vaccine</th>
                <th>Route</th>
                <th>Parent Name</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($immunizationrecords as $row) {
                echo '<tr class="immunization_record-'.$row['immunization_record_id'].'">';
                    echo '<td>'.$row['immunization_record_id'].'</td>';
                    echo '<td>'.$row['patient_name'].'</td>';
                    echo '<td>'.$row['date'].'</td>';
                    $qs = $this->db->query("SELECT * FROM `vaccine_terms_tbl` WHERE `vaccine_terms_id` = '".$row['vaccine_id']."'")->result_array();
                    echo '<td>'.$qs[0]['vaccine_terms_title'].'</td>';
                    echo '<td>'.$row['route'].'</td>';
                    echo '<td>'.$row['parent_name'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().''.$textss.'//viewImmunizationRecord/'.$row['patient_id'].'" class="btn btn-info" style="margin-right:10px;">View</a>';
                        echo '<a href="'.base_url().''.$textss.'//editImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-warning" style="margin-right:10px;">Edit</a>';
                        echo '<a href="'.base_url().''.$textss.'//deleteImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-danger">Delete</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div>
    <?php
        echo $links;
    ?>

<?php $this->load->view('Power/navigation'); ?>
<?php 
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
		
	<h4>Inquiries</h4>
<div class="table-responsive">
	<table class="table table-striped table-hover">
		<thead>
			<tr class="info">
				<td>#</td>
				<td>Title</td>
				<td>Body</td>
				<td>Name</td>
				<td>Email Address</td>
				<td>Phone Number</td>
				<td>Date & Time</td>
				<td></td>
			</tr>
		</thead>
		<tbody>
			<?php
				foreach($inquiries as $per_inquiry):
				?>
				<tr>
					<td>
						<?=$per_inquiry->Inquiries_ID; ?>
					</td>
					<td>
						<?=$per_inquiry->Inquiries_title; ?>
					</td>
					<td>
						<?=$per_inquiry->Inquiries_body; ?>
					</td>
					<td>
						<?=$per_inquiry->Inquiries_Name; ?>
					</td>
					<td>
						<?=$per_inquiry->Inquiries_EmailAddress; ?>
					</td>
					<td>
						<?=$per_inquiry->Inquiries_PhoneNumber; ?>
					</td>
					<td>
						<?=
							date('M d, Y h:iA', $per_inquiry->Inquiries_DateTime);
							//  you must put to application/config/config.php after define function:
							// date_default_timezone_set('Asia/Manila');
						?>
					</td>
					<td>
						<a href="<?=base_url()?>index.php/<?php echo $textss;?>/view/<?=$per_inquiry->Inquiries_ID; ?>" class="btn btn-success">View</a>
						<a href="<?=base_url()?>index.php/<?php echo $textss;?>/delete/<?=$per_inquiry->Inquiries_ID; ?>" class="btn btn-danger">Delete</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

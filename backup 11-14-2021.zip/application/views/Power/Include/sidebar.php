<?php
$textss = "";
$textssss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
    $textssss = 1;
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
    $textssss = 3;
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
    $textssss = 2;
} 
?>
<div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
    <ul class="list-group panel">
        <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>SIDE PANEL</b></li>
        <li class="list-group-item"><a href="<?=base_url('/'.$textss.'/index');?>"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
        <li>
            <a href="#sidebar" class="list-group-item " data-toggle="collapse">Menu  <span class="glyphicon glyphicon-chevron-right"></span></a>
        </li>
        
        <li class="collapse" id="sidebar">
            <?php
            $resultAccess = $this->power_model->setAccessPrivilege($this->session->id, $textssss);
            $resultAccessArray = (array) $resultAccess;
    
            $access = array(0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0);
            foreach($resultAccess as $data) {
                $number = $data['category'];
                if($data['category']) {$access[$number] = $data['category']; }
            }
            ?>
            <?php if($access[1] == 0) { echo '<a href="'.base_url('/'.$textss.'/inquiries_list').'"  class="list-group-item">Inquiries List</a>'; } ?>
            <?php if($access[3] == 0) { echo '<a href="'.base_url('/'.$textss.'/appointment').'"  class="list-group-item">Appointment</a>'; } ?>
            <?php //if($access[4] == 0) { echo '<a href="'.base_url('/'.$textss.'/payment').'"  class="list-group-item">Payment</a>'; } ?>
            <?php if($access[5] == 0) { echo '<a href="'.base_url('/'.$textss.'/consultation').'"  class="list-group-item">Consultation</a>'; } ?>
            <?php if($access[6] == 0) { echo '<a href="'.base_url('/'.$textss.'/transaction_appointment').'"  class="list-group-item">Transaction (Appointments)</a>'; } ?>
            <?php if($access[6] == 0) { echo '<a href="'.base_url('/'.$textss.'/transaction_consultation').'"  class="list-group-item">Transaction (Consultations)</a>'; } ?>
            <?php if($access[7] == 0) { echo '<a href="'.base_url('/'.$textss.'/immunizationrecord').'"  class="list-group-item">Immunization</a>'; } ?>
            <?php if($access[11] == 0) { echo '<a href="'.base_url('/'.$textss.'/parents').'"  class="list-group-item">Parent List</a>'; } ?>
            <?php if($access[17] == 0) { echo '<a href="'.base_url('/'.$textss.'/patients').'"  class="list-group-item">Patient List</a>'; } ?>
            <?php if($access[19] == 0) {echo '<a href="'.base_url('/'.$textss.'/announcements').'"  class="list-group-item">Announcements List</a>'; } ?>
            <?php if($access[23] == 0) {echo '<a href="'.base_url('/'.$textss.'/patient_satisfaction').'"  class="list-group-item">Patient Satisfactions</a>'; } ?>
            <?php if($access[30] == 0) {echo '<a href="'.base_url('/'.$textss.'/terms').'"  class="list-group-item">Pre-defined Terms</a>'; } ?>
            <?php if($access[35] == 0) {echo '<a href="'.base_url('/'.$textss.'/health_tips').'"  class="list-group-item">Health Tips</a>'; } ?>
            <?php echo '<a href="'.base_url('/'.$textss.'/clinic_analytics').'"  class="list-group-item">Clinic Analytics</a>'; ?>
            <?php
                if($this->session->selection == "administrator") {
            ?>
            <a href="<?=base_url('/administrator/accessprivilege');?>" class="list-group-item">Access Privilege</a>
            <?php
                }
            ?>
        </li>
    </ul>
</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
		if(isset($_GET['success'])) {
		?>
			<script type="text/javascript">
			Swal.fire(
				'Good job!',
				'Successfully!',
				'success'
			);
			</script>
		<?php
		}
		?>

		<?php
		if(isset($_GET['error'])) {
		?>
			<script type="text/javascript">
			Swal.fire(
				'Error!',
				'There\'s something wrong!',
				'error'
			);
			</script>
		<?php
		}
		?>
	</body>
</html>
<?php $results = (array) $announcements; ?>
<?php $this->load->view('Power/navigation'); ?>
<?php 
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <h4><?php echo $title; ?> | Edit Announcement</h4>
    <form action="<?php echo base_url().$textss; ?>/editAnnouncements/<?php echo $this->uri->segment(3); ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Title <span style="color:red;">*</span></label>
            <input type="text" name="announcement_tbl_title" class="form-control" value="<?php echo $title; ?>">
        </div>
        <div class="form-group">
            <label>Content <span style="color:red;">*</span></label>
            <textarea name="announcement_tbl_content" class="form-control" style="height: 200px;"><?php echo htmlentities($content); ?></textarea>
        </div>
        <div class="form-group">
            <label>Image</label>
            <input type="file" name="announcement_tbl_image" class="form-control">
            <p style="font-size:11px;font-style:italic;">If you have already uploaded an image, then you do not want to change the current image, do not put an image in the input field.</p>
        </div>
        <div class="pull-right">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
        </div>
        <div style="clear:both;"></div>
    </form>
<?php $this->load->view('Power/navigation'); ?>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment-with-locales.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>

        <!-- Tempus Dominus JavaScript -->
        <script src="https://rawgit.com/tempusdominus/bootstrap-3/master/build/js/tempusdominus-bootstrap-3.js" crossorigin="anonymous"></script>

        <!-- Tempus Dominus Styles -->
        <link href="https://rawgit.com/tempusdominus/bootstrap-3/master/build/css/tempusdominus-bootstrap-3.css" rel="stylesheet" crossorigin="anonymous">
        
        
        <h4>Appointment</h4>
        <div class="row">
            <div class="col-sm-3">
                <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);" class="form-control" style="margin-bottom: 10px;">
                    <option value="" selected="">Appointments</option>
                    <option value="./appointment_requests">Appointment Requests</option>
                </select>
            </div>
        </div>
        
        <div id="calendar"></div>
        
        <?php 
        $textss = "";
        if($this->session->selection == "doctor") {
            $textss = "doctor";
        } else if($this->session->selection == "receptionist") {
            $textss = "receptionist";
        } else if($this->session->selection == "administrator") {
            $textss = "administrator";
        } 
        ?>

        <!-- Modal -->
        <div class="modal fade" id="addAppointmentModel" tabindex="-1" role="dialog" aria-labelledby="addAppointmentLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addAppointmentLabel">Add Appointment</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button> 
                    </div>
                    <div class="modal-body">
                        <form id="addAppointment">
                        <div class="form-group">
                                <label>Details</label>
                                <textarea id="details" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Start date / time</label>
                                <div class="input-group date"  id="dateTime" data-target-input="nearest">
                                    <input type="text" id="getTime" class="form-control datetimepicker-input" data-target="#dateTime"/>
                                    <span class="input-group-addon" data-target="#dateTime" data-toggle="datetimepicker">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>End date / time</label>
                                <input type="text" id="getTime2" class="form-control" readonly=""/>
                            </div>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function(){
                var calendar = $('#calendar').fullCalendar({
                    editable:true,
                    header:{
                        left:'prev,next today',
                        center:'title',
                        right:'month,agendaWeek,agendaDay'
                    },
                    events:"<?php echo base_url() . $textss; ?>/getAppointment",
                    selectable:true,
                    selectHelper:true,
                    
                    editable:true,
                });
            });
            $(function () {
                $('#dateTime').datetimepicker({
                    useSeconds: false,
                    stepping: 30,
                    disabledHours: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                    enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
                });
                $('input#getTime').on('input', function(){
                    var datetime = $('#getTime').val();
                    var d = new Date(datetime);
                    d.setMinutes ( d.getMinutes() + 30 );
                    $('#getTime2').val(getDateTimeFromTimestamp(d));
                });
            });
            function getDateTimeFromTimestamp(unixTimeStamp) {
                var date = new Date(unixTimeStamp + 30 * 60000);
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                minutes = minutes < 10 ? '0'+minutes : minutes;
            
                return ('0' + (date.getMonth() + 1)).slice(-2) + '/' +  ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear() + ' ' + ('0' + hours).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2) + ampm;
            }
        </script>

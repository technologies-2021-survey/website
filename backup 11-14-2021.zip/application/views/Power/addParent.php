    <?php $this->load->view('Power/navigation'); ?>

    
        <h4>Add Parent</h4>
        <?php 
        $textss = "";
        if($this->session->selection == "doctor") {
            $textss = "doctor";
        } else if($this->session->selection == "receptionist") {
            $textss = "receptionist";
        } else if($this->session->selection == "administrator") {
            $textss = "administrator";
        } 
        ?>
        <form action="<?php echo base_url() . $textss; ?>/addParents" method="POST">
            <div class="form-group">
                <label>Parent Name</label>
                <input type="text" name="parent_name" class="form-control" required="">
            </div>
            <div class="form-group">
                <label>Parent Email</label>
                <input type="email" name="parent_emailaddress" class="form-control" required="">
            </div>
            <div class="form-group">
                <label>Parent Phone Number</label>
                <input type="text" name="parent_phonenumber" class="form-control" required="">
            </div>
            <div class="pull-right">
                <input type="submit" name="submit" value="Submit" class="btn btn-primary">
            </div>
            <div style="clear:both;"></div>
        </form>
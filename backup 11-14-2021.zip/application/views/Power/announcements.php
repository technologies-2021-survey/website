<?php $this->load->view('Power/navigation'); ?>
<?php
$textss = "";
if($this->session->selection == "doctor") {
    $textss = "doctor";
} else if($this->session->selection == "receptionist") {
    $textss = "receptionist";
} else if($this->session->selection == "administrator") {
    $textss = "administrator";
} 
?>
    <h4>Announcements List</h4>
    <div class="pull-right">
        <a href="<?php echo base_url().$textss; ?>/addAnnouncements" class="btn btn-primary">Add Announcements</a>
    </div>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Date/Time</th>
                <th>Title</th>
                <th>Content</th>
                <th>Image</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($announcements as $row) {
                echo '<tr class="patients-'.$row['announcement_tbl_id'].'">';
                    echo '<td>'.$row['announcement_tbl_id'].'</td>';
                    echo '<td>'.date("m-d-Y h:i:sa", $row['announcement_tbl_date']).'</td>';
                    echo '<td>'.$row['announcement_tbl_title'].'</td>';
                    echo '<td><pre>'.htmlspecialchars($row['announcement_tbl_content']).'</pre></td>';
                    echo '<td>'.$row['announcement_tbl_image'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().$textss.'//editAnnouncements/'.$row['announcement_tbl_id'].'" class="btn btn-warning" style="margin:10px;">Edit Announcements</a>';
                        //echo '<a href="'.base_url().$textss.'//viewAnnouncements/'.$row['announcement_tbl_id'].'" class="btn btn-warning" style="margin-right:10px;">View Announcements</a>';
                        echo '<a href="'.base_url().$textss.'//deleteAnnouncements/'.$row['announcement_tbl_id'].'" class="btn btn-warning" style="margin:10px;">Delete Announcements</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div>
    <?php echo $links; ?>

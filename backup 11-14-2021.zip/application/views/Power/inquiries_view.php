<?php $this->load->view('Power/navigation'); ?>

	<table class="table table-primary">
		<thead>
			<tr class="info">
				<td>#</td>
				<td>Title</td>
				<td>Body</td>
				<td>Name</td>
				<td>Email Address</td>
				<td>Phone Number</td>
				<td>Date & Time</td>
			</tr>
		</thead>
		<tbody>
			<?php
			foreach($inquiries_view as $view){
				echo '<tr>';
					echo '<td>'; echo $view->Inquiries_ID; echo '</td>';
					echo '<td>'; echo $view->Inquiries_title; echo '</td>';
					echo '<td>'; echo $view->Inquiries_body; echo '</td>';
					echo '<td>'; echo $view->Inquiries_Name; echo '</td>';
					echo '<td>'; echo $view->Inquiries_EmailAddress; echo '</td>';
					echo '<td>'; echo $view->Inquiries_PhoneNumber; echo '</td>';
					echo '<td>'; echo date('M d, Y h:iA', $per_inquiry->Inquiries_DateTime); echo '</td>';
				echo '</tr>';
			}
			?>
		</tbody>
	</table>
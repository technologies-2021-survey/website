<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {
    var $client_service = "whealth-client";
    var $auth_key = "peekabookWhealthApi!@";

    public function check_auth() {
        $client_service = $this->input->get_request_header("Client-Service", TRUE);
        $auth_key = $this->input->get_request_header("Auth-Key", TRUE);

        if($client_service == $this->client_service && $auth_key == $this->auth_key) {
            return true;
        } else {
            return json_output(
                401,
                array(
                    'status' => 401,
                    'message' => 'Unauthorized.'
                )
            );
        }
    }
    public function itexmo($number, $message){
        $ch = curl_init();
        $itexmo = array('1' => $number, '2' => $message, '3' => 'ST-MICHA378601_38DKZ', 'passwd' => ')2hcz6prbn');
        curl_setopt($ch, CURLOPT_URL,"https://www.itexmo.com/php_api/api.php");
        curl_setopt($ch, CURLOPT_POST, 1);
         curl_setopt($ch, CURLOPT_POSTFIELDS, 
                  http_build_query($itexmo));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        return curl_exec ($ch);
        curl_close ($ch);
    }
    public function login($email, $selection) {
        $q = "";
        $role = 0;
        if($selection == "doctor") { $role = 1;$q = $this->db->select('doctor_phonenumber as phonenumber, doctor_sms_code_mobile, doctor_id, profile_picture')->from("doctors_tbl")->where(array('doctor_emailaddress'=> $email))->get()->row(); }
        else if($selection == "administrator") { $role = 2; $q = $this->db->select('admin_phonenumber as phonenumber, admin_sms_code_mobile, admin_id, profile_picture')->from("admins_tbl")->where(array('admin_emailaddress'=> $email))->get()->row(); }
        else if($selection == "receptionist") { $role = 3; $q = $this->db->select('receptionist_phonenumber as phonenumber, receptionist_sms_code_mobile, receptionist_id, profile_picture')->from("receptionists_tbl")->where(array('receptionist_emailaddress' => $email))->get()->row(); }
        else if($selection == "parent") { $role = 4; $q = $this->db->select('parent_phonenumber as phonenumber, parent_sms_code_mobile, parent_id, profile_picture')->from("parents_tbl")->where(array('parent_emailaddress' => $email, 'verified' => 1))->get()->row(); }

        if($q == "") {
            return array(
                'status' => 204,
                'message' => "Email not found or your account has not approved yet by admins."
            );
        } else {            

            $data_id = "";
            if($role == 1) { $data_id = $q->doctor_id; }
            else if($role == 2) { $data_id = $q->admin_id; }
            else if($role == 3) { $data_id = $q->receptionist_id; }
            else if($role == 4) { $data_id = $q->parent_id;  }

            $otps = mt_rand(000000,999999);
            $copyOtp = $otps;
            $this->auth_model->itexmo($q->phonenumber, $copyOtp . ' is your OTP. Please enter this to confirm your login.');
            if($role == 1) { 
                $this->db->set('doctor_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('doctor_id', $data_id);
                $this->db->update('doctors_tbl');
            } else if($role == 2) { 
                $this->db->set('admin_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('admin_id', $data_id);
                $this->db->update('admins_tbl');
            } else if($role == 3) { 
                $this->db->set('receptionist_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('receptionist_id', $data_id);
                $this->db->update('receptionists_tbl');
            } else if($role == 4) { 
                $this->db->set('parent_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('parent_id', $data_id);
                $this->db->update('parents_tbl');
            }
            return array(
                'status' => 200,
                'message' => 'Successfully login!',
                'id' => $data_id,
                'selection' => $role,
                'name' => $this->auth_model->getName($data_id, $role),
                'otp' => $copyOtp,
                'profile_picture' => (base64_encode($q->profile_picture) != "") ? base64_encode($q->profile_picture) : 'aHR0cHM6Ly9wZWVrYWJvb2sudGVjaC9hc3NldHMvaW1nL3doZWFsdGgucG5n'
            );
        }
    } // done, login

    public function resend($id, $selection) {
        $q = "";
        $role = 0;
        if($selection == 1) { $role = 1;$q = $this->db->select('doctor_phonenumber as phonenumber, doctor_sms_code_mobile, doctor_id, profile_picture')->from("doctors_tbl")->where(array('doctor_id'=> $id))->get()->row(); }
        else if($selection == 2) { $role = 2; $q = $this->db->select('admin_phonenumber as phonenumber, admin_sms_code_mobile, admin_id, profile_picture')->from("admins_tbl")->where(array('admin_id'=> $id))->get()->row(); }
        else if($selection == 3) { $role = 3; $q = $this->db->select('receptionist_phonenumber as phonenumber, receptionist_sms_code_mobile, receptionist_id, profile_picture')->from("receptionists_tbl")->where(array('receptionist_id' => $id))->get()->row(); }
        else if($selection == 4) { $role = 4; $q = $this->db->select('parent_phonenumber as phonenumber, parent_sms_code_mobile, parent_id, profile_picture')->from("parents_tbl")->where(array('parent_id' => $id, 'verified' => 1))->get()->row(); }

        if($q == "") {
            return array(
                'status' => 204,
                'message' => "Email not found or your account has not approved yet by admins."
            );
        } else {            

            $data_id = "";
            if($role == 1) { $data_id = $q->doctor_id; }
            else if($role == 2) { $data_id = $q->admin_id; }
            else if($role == 3) { $data_id = $q->receptionist_id; }
            else if($role == 4) { $data_id = $q->parent_id;  }

            $otps = mt_rand(000000,999999);
            $copyOtp = $otps;
            $this->auth_model->itexmo($q->phonenumber, $copyOtp . ' is your OTP. Please enter this to confirm your login.');
            if($role == 1) { 
                $this->db->set('doctor_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('doctor_id', $data_id);
                $this->db->update('doctors_tbl');
            } else if($role == 2) { 
                $this->db->set('admin_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('admin_id', $data_id);
                $this->db->update('admins_tbl');
            } else if($role == 3) { 
                $this->db->set('receptionist_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('receptionist_id', $data_id);
                $this->db->update('receptionists_tbl');
            } else if($role == 4) { 
                $this->db->set('parent_sms_code_mobile', $copyOtp);
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('parent_id', $data_id);
                $this->db->update('parents_tbl');
            }
            $asd = '';
            return array(
                'status' => 200,
                'message' => 'Successfully login!',
                'id' => $data_id,
                'selection' => $role,
                'name' => $this->auth_model->getName($data_id, $role),
                'otp' => $copyOtp,
                'profile_picture' => (base64_encode($q->profile_picture) != "") ? base64_encode($q->profile_picture) : 'aHR0cHM6Ly9wZWVrYWJvb2sudGVjaC9hc3NldHMvaW1nL3doZWFsdGgucG5n'
            );
        }
    } // done, login

    public function registration($first_name, $middle_name, $last_name, $email, $phone_number) {
        $qasd = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_emailaddress` = '".$email."'");
        if($qasd->num_rows() > 0) {
            // exist
            return array(
                'status' => 404,
                'message' => 'Error, email existing!'
            );
        }

        $qasd2 = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_phonenumber` = '".$phone_number."'");
        if($qasd2->num_rows() > 0) {
            // exist
            return array(
                'status' => 404,
                'message' => 'Error, phone number existing!'
            );
        }

        $array = array(
            "parent_name" => ucfirst($first_name) . ' ' . ucfirst($middle_name) . ' ' . ucfirst($last_name),
            "parent_emailaddress" => $email,
            "parent_phonenumber" => $phone_number  
        );

        $this->db->insert('parents_tbl', $array);

        return array(
            'status' => 200,
            'message' => 'Successfully register!'
        );
    }
    public function check_otp($id, $selection, $code) {
        if($selection == 1) { 
            $getCode = $this->db->query("SELECT * FROM doctors_tbl WHERE doctor_id = '".$id."' AND doctor_sms_code_mobile = '".$code."'");
            if($getCode->num_rows() > 0) {
                // exist
                $this->db->set('doctor_sms_code_mobile', "@@@@@@@@SUCCESS@@@@@@@@");
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('doctor_id', $id);
                $this->db->update('doctors_tbl');

                return array(
                    'status' => 200,
                    'message' => 'Successfully login!',
                );
            } else {
                // not exists
                return array(
                    'status' => 204,
                    'message' => 'Invalid code!',
                );
            }
        } else if($selection == 2) { 
            $getCode = $this->db->query("SELECT * FROM admins_tbl WHERE admin_id = '".$id."' AND admin_sms_code_mobile = '".$code."'");
            if($getCode->num_rows() > 0) {
                $this->db->set('admin_sms_code_mobile', "@@@@@@@@SUCCESS@@@@@@@@");
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('admin_id', $id);
                $this->db->update('admins_tbl');

                return array(
                    'status' => 200,
                    'message' => 'Successfully login!',
                );
            } else {
                return array(
                    'status' => 204,
                    'message' => 'Invalid code!',
                );
            }
        } else if($selection == 3) { 
            $getCode = $this->db->query("SELECT * FROM receptionists_tbl WHERE receptionist_id = '".$id."' AND receptionist_sms_code_mobile = '".$code."'");
            if($getCode->num_rows() > 0) {
                $this->db->set('receptionist_sms_code_mobile', "@@@@@@@@SUCCESS@@@@@@@@");
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('receptionist_id', $id);
                $this->db->update('receptionists_tbl');

                return array(
                    'status' => 200,
                    'message' => 'Successfully login!',
                );
            } else {
                return array(
                    'status' => 204,
                    'message' => 'Invalid code!',
                );
            }
        } else if($selection == 4) { 
            $getCode = $this->db->query("SELECT * FROM parents_tbl WHERE parent_id = '".$id."' AND parent_sms_code_mobile = '".$code."'");
            if($getCode->num_rows() > 0) {
                $this->db->set('parent_sms_code_mobile', "@@@@@@@@SUCCESS@@@@@@@@");
                $this->db->set('active', '1');
                $this->db->set('login_timeout', time()+36000); // 10 hours
                $this->db->where('parent_id', $id);
                $this->db->update('parents_tbl');

                return array(
                    'status' => 200,
                    'message' => 'Successfully login!',
                );
            } else {
                return array(
                    'status' => 204,
                    'message' => 'Invalid code!',
                );
            }
        } else {
            return array(
                'status' => 204,
                'message' => 'Invalid code!',
            );
        }
    } 
    public function getName($id, $selection) {
        if($selection == 1) {
            $q = $this->db->query("SELECT * FROM `doctors_tbl` WHERE `doctor_id` = '".$id."'"); 
            foreach($q->result() as $row) { 
                return $row->doctor_name;
            }
        } else if($selection == 2) {
            $q = $this->db->query("SELECT * FROM `admins_tbl` WHERE `admin_id` = '".$id."'"); 
            foreach($q->result() as $row) { 
                return $row->admin_name;
            }
        } else if($selection == 3) {
            $q = $this->db->query("SELECT * FROM `receptionists_tbl` WHERE `receptionist_id` = '".$id."'"); 
            foreach($q->result() as $row) { 
                return $row->receptionist_name;
            }
        } else if($selection == 4) {
            $q = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$id."'"); 
            foreach($q->result() as $row) { 
                return $row->parent_name;
            }
        } else if($selection == 5) {
            $q = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$id."'"); 
            foreach($q->result() as $row) { 
                return $row->patient_name;
            }
        }
        
    }
    public function milestone($id = 0, $parent_id) {
        $record_per_page = 5;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        
        $q = $this->db->query("SELECT * FROM `milestone_tbl` WHERE `parent_id` = '".$parent_id."' ORDER BY `milestone_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() > 0) {
            // existing
            // success
            foreach($q->result_array() as $row) { 

                $arr[] = array(
                    'status' => 200,
                    'milestone_id' => $row['milestone_id'],
                    'milestone_caption' => $row['milestone_caption'],
                    'milestone_image' => $row['milestone_image'],
                    'milestone_datetime' => $row['milestone_datetime'],
                    'parent_id' => $row['parent_id']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Milestones not found."
            );
        }
    }
    public function addAppointment($appointment_parent_id, $appointment_patient_id, $appointment_timestamp, $appointment_timestamp_end, $appointment_datetime, $appointment_datetime_end, $money, $appointment_description, $appointment_proof_of_transaction, $reference_number) {
        
        if(strlen($reference_number) == 0) {
            return array(
                'status' => 204,
                'message' => "Reference Number not found"
            );
        } else if(strlen($appointment_patient_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Patient ID not found"
            );
        } else if(strlen($appointment_proof_of_transaction) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Proof of Transaction not found"
            );
        } else if(strlen($appointment_parent_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Parent ID not found"
            );
        } else if(strlen($appointment_timestamp) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Timestamp not found"
            );
        } else if(strlen($appointment_timestamp_end) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Timestamp End not found"
            );
        } else if(strlen($appointment_description) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Description End not found"
            );
        }  else if(strlen($appointment_datetime) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Date Time not found"
            );
        } else if(strlen($appointment_datetime_end) == 0) {
            return array(
                'status' => 204,
                'message' => "Appointment Date Time End not found"
            );
        } else if(strlen($money) == 0) {
            return array(
                'status' => 204,
                'message' => "Money not found"
            );
        } else {
            $array = array(
                'appointment_parent_id' => $appointment_parent_id,
                'appointment_patient_id' => $appointment_patient_id,
                'appointment_timestamp' => $appointment_timestamp,
                'appointment_timestamp_end' => $appointment_timestamp_end,
                'date_text' => date('m/d/Y', $appointment_timestamp),
                'appointment_timestamp_sub' => $appointment_timestamp,
                'appointment_timestamp_sub_end' => $appointment_timestamp_end,
                'appointment_description' => $appointment_description,
                'appointment_datetime' => $appointment_datetime,
                'appointment_datetime_end' => $appointment_datetime_end,
                'appointment_proof_of_transaction' => $appointment_proof_of_transaction,
                'money' => $money,
                'reference_number' => $reference_number,
                'appointment_status' => 'Pending'
            );
            $this->db->insert('appointments', $array);
            return array(
                'status' => 200,
                'message' => "Successfully!"
            );
        }
    }
    public function consultations($id = 0, $parent_id) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        
        $qasd = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_parent_id` = '".$parent_id."' ORDER BY `consultation_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($qasd->num_rows() > 0) {
            // existing
            // success
            //return $parent_id;
            
            foreach($qasd->result_array() as $row) { 
                $getParent = $this->db->query("SELECT * FROM parents_tbl WHERE parent_id = '".$row['consultation_parent_id']."'")->result_array();
                $getPatient = $this->db->query("SELECT * FROM patients_tbl WHERE patient_id = '".$row['consultation_patient_id']."'")->result_array();


                $name = "";
                if($row['consultation_approve_selection'] == 1) {
                    $getApproveName = $this->db->query("SELECT * FROM doctors_tbl WHERE doctor_id = '".$row['consultation_approve_by']."'")->result_array();
                    $name = $getApproveName[0]['doctor_name'];
                } else if($row['consultation_approve_selection'] == 2) {
                    $getApproveName = $this->db->query("SELECT * FROM admins_tbl WHERE admin_id = '".$row['consultation_approve_by']."'")->result_array();
                    $name = $getApproveName[0]['admin_name'];
                } else if($row['consultation_approve_selection'] == 3) {
                    $getApproveName = $this->db->query("SELECT * FROM receptionists_tbl WHERE receptionist_id = '".$row['consultation_approve_by']."'")->result_array();
                    $name = $getApproveName[0]['receptionist_name'];
                }

                $arr[] = array(
                    'status' => 200,
                    'consultation_id'                   => $row['consultation_id'],
                    'consultation_parent_id'            => $row['consultation_parent_id'],
                    'consultation_parent_name'          => $getParent[0]['parent_name'],
                    'consultation_patient_id'           => $row['consultation_patient_id'],
                    'consultation_patient_name'         => $getPatient[0]['patient_name'],
                    'date_consultation'                 => $row['date_consultation'],
                    'date_consultation_end'             => $row['date_consultation_end'],
                    'date_consultation_datetime'        => $row['date_consultation_datetime'],
                    'date_consultation_datetime_end'    => $row['date_consultation_datetime_end'],
                    'reason'                            => $row['reason'],
                    'consultation_proof_of_transaction' => $row['consultation_proof_of_transaction'],
                    'consultation_prescription'         => $row['consultation_prescription'],
                    'googlelink'                        => $row['googlelink'],
                    'consultation_status'               => $row['consultation_status'],
                    'money'                             => $row['money'],
                    'survey_done'                       => $row['survey_done'],
                    'consultation_by'                   => $name,
                    'reference_number'                  => $row['reference_number'],
                    'approve_by' => $row['consultation_approve_by'],
                    'approve_selection' => $row['consultation_approve_selection']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Consultations not found."
            );
        }
    }   
    public function appointments($id = 0, $parent_id) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        
        $q = $this->db->query("SELECT * FROM `appointments` WHERE `appointment_parent_id` = '".$parent_id."' ORDER BY `appointment_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() > 0) {
            // existing
            // success
            foreach($q->result_array() as $row) { 

                $arr[] = array(
                    'status' => 200,
                    'appointment_id' => $row['appointment_id'],
                    'appointment_parent_id' => $row['appointment_parent_id'],
                    'appointment_timestamp' => $row['appointment_timestamp'],
                    'appointment_timestamp_end' => $row['appointment_timestamp_end'],
                    'appointment_description' => $row['appointment_description'],
                    'appointment_datetime' => $row['appointment_datetime'],
                    'appointment_datetime_end' => $row['appointment_datetime_end'],
                    'money' => $row['money'],
                    'survey_done' => $row['survey_done'],
                    'appointment_status' => $row['appointment_status'],
                    'appointment_proof_of_transaction' => $row['appointment_proof_of_transaction'],
                    'reference_number' => $row['reference_number'],
                    'approve_by' => $row['appointment_approve_by'],
                    'approve_selection' => $row['appointment_approve_selection']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Appointments not found."
            );
        }
    }
    public function addConsultation($consultation_parent_id, $consultation_patient_id, $date_consultation, $date_consultation_end,$date_consultation_datetime, $date_consultation_datetime_end, $reason, $money, $consultation_proof_of_transaction, $reference_number) {
        if(strlen($reference_number) == 0) {
            return array(
                'status' => 204,
                'message' => "Reference Number not found"
            );
        } else if(strlen($consultation_parent_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Consultation Parent ID not found"
            );
        } else if(strlen($consultation_patient_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Consultation Patient ID not found"
            );
        } else if(strlen($date_consultation) == 0) {
            return array(
                'status' => 204,
                'message' => "Date not found"
            );
        } else if(strlen($date_consultation_end) == 0) {
            return array(
                'status' => 204,
                'message' => "Date end not found"
            );
        } else if(strlen($date_consultation_datetime) == 0) {
            return array(
                'status' => 204,
                'message' => "Date string not found"
            );
        } else if(strlen($date_consultation_datetime_end) == 0) {
            return array(
                'status' => 204,
                'message' => "Date end string ID not found"
            );
        } else if(strlen($reason) == 0) {
            return array(
                'status' => 204,
                'message' => "Reason not found"
            );
        } else if(strlen($money) == 0) {
            return array(
                'status' => 204,
                'message' => "Money not found"
            );
        } else if(strlen($consultation_proof_of_transaction) == 0) {
            return array(
                'status' => 204,
                'message' => "Consultation Proof of Transaction not found"
            );
        } else {
            $array = array(
                'consultation_parent_id' => $consultation_parent_id,
                'consultation_patient_id' => $consultation_patient_id,
                'date_consultation' => $date_consultation,
                'date_consultation_end' => $date_consultation_end,
                'date_text' => date('m/d/Y', $date_consultation),
                'date_consultation_sub' => $date_consultation,
                'date_consultation_sub_end' => $date_consultation_end,
                'date_consultation_datetime' => $date_consultation_datetime,
                'date_consultation_datetime_end' => $date_consultation_datetime_end,
                'reason' => $reason,
                'money' => $money,
                'consultation_proof_of_transaction' => $consultation_proof_of_transaction,
                'consultation_status' => 'Pending',
                'reference_number' => $reference_number
            );
            $this->db->insert('consultations', $array);
            return array(
                'status' => 200,
                'message' => "Successfully!"
            );
        }
    }

    public function deleteMilestone($milestone_id, $parent_id){
        if(strlen($milestone_id) == 0 && strlen($parent_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Milestone ID and Parent ID not found."
            );
        } else {
            $this->db->where('milestone_id', $milestone_id);
            $this->db->where('parent_id', $parent_id);
            $this->db->delete('milestone_tbl');
            return array(
                'status' => 200,
                'message' => "Successfully!"
            );
        }
    }

    public function postMilestone($milestone_image, $milestone_caption, $parent_id) {
        if(strlen($milestone_image) == 0 && strlen($milestone_caption) == 0 && strlen($parent_id) == 0) {
            return array(
                'status' => 204,
                'message' => "Milestone Image, Milestone Caption and Parent ID not found."
            );
        } else if(strlen($milestone_image) == 0 && strlen($milestone_caption) == 0) {
            return array(
                'status' => 204,
                'message' => "Milestone Image and Milestone Caption and Parent ID not found."
            );
        } else {
            $array = array(
                'milestone_image' => (strlen($milestone_image == 0)) ? "" : $milestone_image,
                'milestone_caption' => (strlen($milestone_caption == 0)) ? "" : $milestone_caption,
                'parent_id' => $parent_id,
                'milestone_datetime' => time()
            );
            $this->db->insert('milestone_tbl', $array);
            return array(
                'status' => 200,
                'message' => "Successfully!"
            );
        }
    }

    public function getAvailable() {
        date_default_timezone_set("Asia/Manila");

        $start_time = 9;
        $count = 0;
        
        $data = array();
        for($i = 0; $i < 6; $i++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;
            if($count >= 1) {
                $start_time2 = strtotime(''.$start_time.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time2));
                $timestamp_number = strtotime('+30 minutes', $start_time2);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time2));
                $timestamp_number_end = strtotime('+60 minutes', $start_time2);

                $count = 0;
                $start_time+=1;
            } else {
                $start_time2 = strtotime(''.$start_time.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time2));
                $timestamp_number = strtotime('+0 minutes', $start_time2);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time2));
                $timestamp_number_end = strtotime('+30 minutes', $start_time2);
                $count += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time2 = 9;
        $count2 = 0;
        for($s = 0; $s < 6; $s++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 1 days'));
            if($count2 >= 1) {
                $start_time22 = strtotime($getDateNow . ' '.$start_time2.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time22));
                $timestamp_number = strtotime('+30 minutes', $start_time22);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time22));
                $timestamp_number_end = strtotime('+60 minutes', $start_time22);

                $count2 = 0;
                $start_time2+=1;
            } else {
                $start_time22 = strtotime($getDateNow . ' '.$start_time2.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time22));
                $timestamp_number = strtotime('+0 minutes', $start_time22);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time22));
                $timestamp_number_end = strtotime('+30 minutes', $start_time22);
                $count2 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time3 = 9;
        $count3 = 0;
        for($h = 0; $h < 6; $h++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 2 days'));
            if($count3 >= 1) {
                $start_time33 = strtotime($getDateNow . ' '.$start_time3.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time33));
                $timestamp_number = strtotime('+30 minutes', $start_time33);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time33));
                $timestamp_number_end = strtotime('+60 minutes', $start_time33);

                $count3 = 0;
                $start_time3+=1;
            } else {
                $start_time33 = strtotime($getDateNow . ' '.$start_time3.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time33));
                $timestamp_number = strtotime('+0 minutes', $start_time33);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time33));
                $timestamp_number_end = strtotime('+30 minutes', $start_time33);
                $count3 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time4 = 9;
        $count4 = 0;
        for($sr = 0; $sr < 6; $sr++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 3 days'));
            if($count4 >= 1) {
                $start_time44 = strtotime($getDateNow . ' '.$start_time4.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time44));
                $timestamp_number = strtotime('+30 minutes', $start_time44);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time44));
                $timestamp_number_end = strtotime('+60 minutes', $start_time44);

                $count4 = 0;
                $start_time4+=1;
            } else {
                $start_time44 = strtotime($getDateNow . ' '.$start_time4.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time44));
                $timestamp_number = strtotime('+0 minutes', $start_time44);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time44));
                $timestamp_number_end = strtotime('+30 minutes', $start_time44);
                $count4 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time5 = 9;
        $count5 = 0;
        for($ssd = 0; $ssd < 6; $ssd++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 4 days'));
            if($count5 >= 1) {
                $start_time55 = strtotime($getDateNow . ' '.$start_time5.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time55));
                $timestamp_number = strtotime('+30 minutes', $start_time55);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time55));
                $timestamp_number_end = strtotime('+60 minutes', $start_time55);

                $count5 = 0;
                $start_time5+=1;
            } else {
                $start_time55 = strtotime($getDateNow . ' '.$start_time5.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time55));
                $timestamp_number = strtotime('+0 minutes', $start_time55);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time55));
                $timestamp_number_end = strtotime('+30 minutes', $start_time55);
                $count5 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time6 = 9;
        $count6 = 0;
        for($sds = 0; $sds < 6; $sds++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 5 days'));
            if($count6 >= 1) {
                $start_time66 = strtotime($getDateNow . ' '.$start_time6.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time66));
                $timestamp_number = strtotime('+30 minutes', $start_time66);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time66));
                $timestamp_number_end = strtotime('+60 minutes', $start_time66);

                $count6 = 0;
                $start_time6+=1;
            } else {
                $start_time66 = strtotime($getDateNow . ' '.$start_time6.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time66));
                $timestamp_number = strtotime('+0 minutes', $start_time66);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time66));
                $timestamp_number_end = strtotime('+30 minutes', $start_time66);
                $count6 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                
                );
            }
        }

        $start_time7 = 9;
        $count7 = 0;
        for($ssdsd = 0; $ssdsd < 6; $ssdsd++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 6 days'));
            if($count7 >= 1) {
                $start_time77 = strtotime($getDateNow . ' '.$start_time7.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time77));
                $timestamp_number = strtotime('+30 minutes', $start_time77);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time77));
                $timestamp_number_end = strtotime('+60 minutes', $start_time77);

                $count7 = 0;
                $start_time7+=1;
            } else {
                $start_time77 = strtotime($getDateNow . ' '.$start_time7.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time77));
                $timestamp_number = strtotime('+0 minutes', $start_time77);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time77));
                $timestamp_number_end = strtotime('+30 minutes', $start_time77);
                $count7 += 1;
            }

            $q = $this->db->query("SELECT * FROM `appointments` WHERE appointment_timestamp_sub = $timestamp_number AND appointment_timestamp_sub_end = $timestamp_number_end")->num_rows();
            $q2 = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation_sub = $timestamp_number AND date_consultation_sub_end = $timestamp_number_end")->num_rows();

            if($q > 0 || $q2 > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }
        return $data;
    }

    public function getAvailableConsultation() {
        date_default_timezone_set("Asia/Manila");

        $start_time = 9;
        $count = 0;
        
        $data = array();
        for($i = 0; $i < 6; $i++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;
            if($count >= 1) {
                $start_time2 = strtotime(''.$start_time.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time2));
                $timestamp_number = strtotime('+30 minutes', $start_time2);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time2));
                $timestamp_number_end = strtotime('+60 minutes', $start_time2);

                $count = 0;
                $start_time+=1;
            } else {
                $start_time2 = strtotime(''.$start_time.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time2));
                $timestamp_number = strtotime('+0 minutes', $start_time2);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time2));
                $timestamp_number_end = strtotime('+30 minutes', $start_time2);
                $count += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time2 = 9;
        $count2 = 0;
        for($s = 0; $s < 6; $s++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 1 days'));
            if($count2 >= 1) {
                $start_time22 = strtotime($getDateNow . ' '.$start_time2.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time22));
                $timestamp_number = strtotime('+30 minutes', $start_time22);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time22));
                $timestamp_number_end = strtotime('+60 minutes', $start_time22);

                $count2 = 0;
                $start_time2+=1;
            } else {
                $start_time22 = strtotime($getDateNow . ' '.$start_time2.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time22));
                $timestamp_number = strtotime('+0 minutes', $start_time22);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time22));
                $timestamp_number_end = strtotime('+30 minutes', $start_time22);
                $count2 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time3 = 9;
        $count3 = 0;
        for($h = 0; $h < 6; $h++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 2 days'));
            if($count3 >= 1) {
                $start_time33 = strtotime($getDateNow . ' '.$start_time3.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time33));
                $timestamp_number = strtotime('+30 minutes', $start_time33);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time33));
                $timestamp_number_end = strtotime('+60 minutes', $start_time33);

                $count3 = 0;
                $start_time3+=1;
            } else {
                $start_time33 = strtotime($getDateNow . ' '.$start_time3.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time33));
                $timestamp_number = strtotime('+0 minutes', $start_time33);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time33));
                $timestamp_number_end = strtotime('+30 minutes', $start_time33);
                $count3 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time4 = 9;
        $count4 = 0;
        for($sr = 0; $sr < 6; $sr++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 3 days'));
            if($count4 >= 1) {
                $start_time44 = strtotime($getDateNow . ' '.$start_time4.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time44));
                $timestamp_number = strtotime('+30 minutes', $start_time44);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time44));
                $timestamp_number_end = strtotime('+60 minutes', $start_time44);

                $count4 = 0;
                $start_time4+=1;
            } else {
                $start_time44 = strtotime($getDateNow . ' '.$start_time4.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time44));
                $timestamp_number = strtotime('+0 minutes', $start_time44);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time44));
                $timestamp_number_end = strtotime('+30 minutes', $start_time44);
                $count4 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time5 = 9;
        $count5 = 0;
        for($ssd = 0; $ssd < 6; $ssd++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 4 days'));
            if($count5 >= 1) {
                $start_time55 = strtotime($getDateNow . ' '.$start_time5.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time55));
                $timestamp_number = strtotime('+30 minutes', $start_time55);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time55));
                $timestamp_number_end = strtotime('+60 minutes', $start_time55);

                $count5 = 0;
                $start_time5+=1;
            } else {
                $start_time55 = strtotime($getDateNow . ' '.$start_time5.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time55));
                $timestamp_number = strtotime('+0 minutes', $start_time55);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time55));
                $timestamp_number_end = strtotime('+30 minutes', $start_time55);
                $count5 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }

        $start_time6 = 9;
        $count6 = 0;
        for($sds = 0; $sds < 6; $sds++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 5 days'));
            if($count6 >= 1) {
                $start_time66 = strtotime($getDateNow . ' '.$start_time6.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time66));
                $timestamp_number = strtotime('+30 minutes', $start_time66);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time66));
                $timestamp_number_end = strtotime('+60 minutes', $start_time66);

                $count6 = 0;
                $start_time6+=1;
            } else {
                $start_time66 = strtotime($getDateNow . ' '.$start_time6.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time66));
                $timestamp_number = strtotime('+0 minutes', $start_time66);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time66));
                $timestamp_number_end = strtotime('+30 minutes', $start_time66);
                $count6 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                
                );
            }
        }

        $start_time7 = 9;
        $count7 = 0;
        for($ssdsd = 0; $ssdsd < 6; $ssdsd++) {
            $timestamp_number = 0;
            $timestamp_number_end = 0;

            $timestamp = 0;
            $timestamp_end = 0;

            $dateRightNow = date("Y-m-d", time());
            $getDateNow = date("Y-m-d", strtotime((string) $dateRightNow. ' + 6 days'));
            if($count7 >= 1) {
                $start_time77 = strtotime($getDateNow . ' '.$start_time7.':00'); // time start

                $timestamp = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time77));
                $timestamp_number = strtotime('+30 minutes', $start_time77);

                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+60 minutes', $start_time77));
                $timestamp_number_end = strtotime('+60 minutes', $start_time77);

                $count7 = 0;
                $start_time7+=1;
            } else {
                $start_time77 = strtotime($getDateNow . ' '.$start_time7.':00'); // time start
                $timestamp = date("m/d/Y h:i:sA", strtotime('+0 minutes', $start_time77));
                $timestamp_number = strtotime('+0 minutes', $start_time77);
                $timestamp_end = date("m/d/Y h:i:sA", strtotime('+30 minutes', $start_time77));
                $timestamp_number_end = strtotime('+30 minutes', $start_time77);
                $count7 += 1;
            }

            $q = $this->db->query("SELECT * FROM `consultations` WHERE date_consultation = $timestamp_number AND date_consultation_end = $timestamp_number_end")->num_rows();

            if($q > 0) {
                // exist
            } else {
                $data[] = array(
                    'time' => $timestamp . ' to ' . $timestamp_end,
                    'timestamp' => $timestamp_number,
                    'timestamp_end' => $timestamp_number_end,
                    'datetime' => date("m/d/Y h:i:sA", $timestamp_number),
                    'datetime_end' => date("m/d/Y h:i:sA", $timestamp_number_end)
                );
            }
        }
        return $data;
    }
    
    public function updateConsultation($data, $id) {
        $this->db->where('consultation_id', $id);
		$this->db->update('consultations', $data);
        return "Finished!";
    }

    public function updateAppointment($data, $id) {
        $this->db->where('appointment_id', $id);
		$this->db->update('appointments', $data);
        return "Finished!";
    }

    public function patientSatisfaction($type, $parent_id) {
        if($type == "appointments") {
            $q = $this->db->query("SELECT * FROM appointments_tbl WHERE appointment_parent_id = '".$parent_id."' AND survey_done ='' AND appointment_status = 'Finished'");
            $array = array();
            foreach($q->result_array() as $row) {
                $array[] = array(
                    'appointment_id' => $row['appointment_id']
                );
            }
            return $array;
        } else if($type == "consultations") {
            $q = $this->db->query("SELECT * FROM consultations WHERE consultation_parent_id = '".$parent_id."' AND survey_done ='' AND consultation_status = 'Finished'");
            $array = array();
            foreach($q->result_array() as $row) {
                $array[] = array(
                    'consultation_id' => $row['consultation_id']
                );
            }
            return $array;
        } else {
            return "Error";
        }
    }

    public function postPatientSatisfaction($answerOne, $answerTwo, $answerThree, $interview_id, $type, $id) {
        if($type == "appointments") {
            $array = array(
                'type' => 'appointments',
                'id' => $id,
                'answer_one' => $answerOne,
                'answer_two' => $answerTwo,
                'answer_three' => $answerThree,
                'interview_id' => $interview_id,
                'timestamp' => time()
            );
            $this->db->insert('surveys_tbl', $array);

            $this->db->query("UPDATE appointments SET survey_done = 1 WHERE appointment_id = '".$id."'");
            return "Done!";
        } else if($type == "consultations") {
            $array = array(
                'type' => 'consultations',
                'id' => $id,
                'answer_one' => $answerOne,
                'answer_two' => $answerTwo,
                'answer_three' => $answerThree,
                'interview_id' => $interview_id,
                'timestamp' => time()
            );
            $this->db->insert('surveys_tbl', $array);

            $this->db->query("UPDATE consultations SET survey_done = 1 WHERE consultation_id = '".$id."'");
            return "Done!";
        } else {
            return "Error";
        }
    }

    public function allTransactions($parent_id, $id = 0) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        $num_rowsss = 0;

        $q = $this->db->query("SELECT * FROM appointments WHERE appointment_parent_id = '".$parent_id."' ORDER BY `appointment_id` DESC LIMIT $start_from, $record_per_page");
		$array = array();
        $count = 1;

        if($q->num_rows() > 0) {
            foreach($q->result_array() as $row) {
                $array[] = array(
                    'overallId'            => $count,
                    'category'             => 'appointments',
                    'id'                   => $row['appointment_id'],
                    'parent_id'            => $row['appointment_parent_id'],
                    'patient_id'           => '',
                    'patient_name'         => '',
                    'timestamp'            => $row['appointment_timestamp'],
                    'timestamp_end'        => $row['appointment_timestamp_end'],
                    'proof_of_transaction' => $row['appointment_proof_of_transaction'],
                    'prescription'         => '',
                    'description'          => $row['appointment_description'],
                    'datetime'             => $row['appointment_datetime'],
                    'datetime_end'         => $row['appointment_datetime_end'],
                    'reason'               => '', //
                    'approve_by'           => '', //
                    'approve_selection'    => '', //
                    'googlelink'           => '', //
                    'money'                => $row['money'],
                    'survey_done'          => $row['survey_done'],
                    'status'               => $row['appointment_status'],
                    'reference_number'     => $row['reference_number']
                );
                $count++;
            }
        } else {
            $num_rowsss++;
        }

        $q2 = $this->db->query("SELECT * FROM consultations WHERE consultation_parent_id = '".$parent_id."'  ORDER BY `consultation_id` DESC LIMIT $start_from, $record_per_page");

        if($q2->num_rows() > 0) {
            foreach($q2->result_array() as $row2) {
                $getPatient = $this->db->query("SELECT * FROM `patients_tbl` WHERE patient_id = '".$row2['consultation_patient_id']."'")->result_array();

                $array[] = array(
                    'overallId'            => $count,
                    'category'             => 'consultations', //
                    'id'                   => $row2['consultation_id'], //
                    'parent_id'            => $row2['consultation_parent_id'], //
                    'patient_id'           => $row2['consultation_patient_id'], //
                    'patient_name'         => $getPatient[0]['patient_name'], //
                    'timestamp'            => $row2['date_consultation'], //
                    'timestamp_end'        => $row2['date_consultation_end'], //
                    'proof_of_transaction' => $row2['consultation_proof_of_transaction'], //
                    'prescription'         => $row2['consultation_prescription'], //
                    'description'          => '',
                    'datetime'             => $row2['date_consultation_datetime'], //
                    'datetime_end'         => $row2['date_consultation_datetime_end'], //
                    'reason'               => $row2['reason'], //
                    'approve_by'           => $row2['consultation_approve_by'], //
                    'approve_selection'    => $row2['consultation_approve_selection'], //
                    'googlelink'           => $row2['googlelink'], //
                    'money'                => $row2['money'], //
                    'survey_done'          => $row2['survey_done'], //
                    'status'               => $row2['consultation_status'], //
                    'reference_number'     => $row2['reference_number']
                );
                $count++;
            }
        } else {
            $num_rowsss++;
        }

        if($num_rowsss == 2) {
            return array(
                'status' => 204,
                'message' => "Transactions not found."
            );
        }

        return $array;
        
        
    }

    public function displayPatients($parent_id) {
        $q = $this->db->query("SELECT * FROM `patients_tbl` WHERE parent_id = '".$parent_id."'");
        if($q->num_rows() > 0) {
            //exist
            $array = array();
            foreach($q->result_array() as $row) {
                $array[] = array(
                    'patient_id' => $row['patient_id'],
                    'patient_name' => $row['patient_name'],
                    'patient_birthdate' => $row['patient_birthdate'],
                    'patient_gender' => $row['patient_gender']
                );
            }
            return $array;
        } else {
            return 'Error';
        }
        
    }

    public function announcements($id = 0) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        
        $q = $this->db->query("SELECT * FROM `announcement_tbl` ORDER BY `announcement_tbl_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() > 0) {
            // existing
            // success
            foreach($q->result_array() as $row) { 

                $arr[] = array(
                    'status' => 200,
                    'announcement_tbl_id' => $row['announcement_tbl_id'],
                    'announcement_tbl_date' => $row['announcement_tbl_date'],
                    'announcement_tbl_title' => $row['announcement_tbl_title'],
                    'announcement_tbl_content' => $row['announcement_tbl_content'],
                    'announcement_tbl_image' => $row['announcement_tbl_image']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Announcements not found."
            );
        }
    }
    public function health_tips($id = 0) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        
        $q = $this->db->query("SELECT * FROM `health_tips_tbl` ORDER BY `health_tips_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() == 0) {
            return array(
                'status' => 204,
                'message' => "Health Tips not found."
            );
        } else {
            // existing
            // success
            foreach($q->result_array() as $row) { 

                $arr[] = array(
                    'status' => 200,
                    'health_tips_id' => $row['health_tips_id'],
                    'health_tips_title' => $row['health_tips_title'],
                    'health_tips_link' => $row['health_tips_link']
                );
            }
            return $arr;
        }
    }
    public function babyRecords($id = 0, $patient_id) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;

        $q = $this->db->query("SELECT * FROM `patients_history_tbl` WHERE `patient_id` = '".$patient_id."' ORDER BY `patients_history_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() >= 1) {
            // existing
            // success
            foreach($q->result_array() as $row) { 
                $asd = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$row['patient_id']."'")->result_array();
                $arr[] = array(
                    'status' => 200,
                    'patients_history_id' => $row['patients_history_id'],
                    'patient_id' => $row['patient_id'],
                    'patient_name' => $asd[0]['patient_name'],
                    'patient_datetime' => $row['patient_datetime'],
                    'chiefComplaint' => $row['chiefComplaint'],
                    'medicalHistory' => $row['medicalHistory'],
                    
                    'pastMedicalHistory' => $row['pastMedicalHistory'],
                    'familyHistory' => $row['familyHistory'],
                    'birthHistory' => $row['birthHistory'],
                    'feedingHistory' => $row['feedingHistory'],
                    'immunization' => $row['immunization'],

                    'earAndBodyPiercing' => $row['earAndBodyPiercing'],
                    'circumcision' => $row['circumcision'],
                    'developmentalHistory' => $row['developmentalHistory'],
                    'bp' => $row['bp'],
                    'cr' => $row['cr'],

                    'rr' => $row['rr'],
                    'temp' => $row['temp'],
                    'O2Sat' => $row['O2Sat'],
                    'weight' => $row['weight'],
                    'Ht' => $row['Ht'],
                    
                    'hc' => $row['hc'],
                    'cc' => $row['cc'],
                    'ac' => $row['ac'],
                    'height' => $row['height'],
                    'skin' => $row['skin'],

                    'heent' => $row['heent'],
                    'thorax' => $row['thorax'],
                    'abdomen' => $row['abdomen'],
                    'genitourinarySystem' => $row['genitourinarySystem'],
                    'rectalExamination' => $row['rectalExamination'],

                    'extremities' => $row['extremities'],
                    'assessment' => $row['assessment'],
                    'lmp' => $row['lmp'],
                    'obstretrics' => $row['obstretrics'],
                    'Investigate' => $row['Investigate'],

                    'therapy' => $row['therapy']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Baby records not found."
            );
        }
    }
    public function immunizationRecords($id = 0, $patient_id) {
        $record_per_page = 10;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;

        $q = $this->db->query("SELECT * FROM `immunization_record` WHERE `patient_id` = '".$patient_id."' ORDER BY `immunization_record_id` DESC LIMIT $start_from, $record_per_page");		

        $arr = array();

        if($q->num_rows() >= 1) {
            // existing
            // success
            foreach($q->result_array() as $row) { 
                $asdasd = $this->db->query("SELECT * FROM `vaccine_terms_tbl` WHERE `vaccine_terms_id` = '".$row['vaccine_id']."'")->result_array();
                $arr[] = array(
                    'status' => 200,
                    'immunization_record_id' => $row['immunization_record_id'],
                    'patient_id' => $row['patient_id'],
                    'parent_id' => $row['parent_id'],
                    'date' => $row['date'],
                    'vaccine' => $asdasd[0]['vaccine_terms_title'],
                    'route' => $row['route'],
                    'timestamp' => $row['timestamp']
                );
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Immunization Record not found."
            );
        }
    }

    public function staffAllTransactions() {
		date_default_timezone_set("Asia/Manila");

        $num_rowsss = 0;
		$timestamp = strtotime(date("M d, Y 00:00:00", time()));
        $q = $this->db->query("SELECT * FROM appointments WHERE `appointment_timestamp` >= '".$timestamp."' AND appointment_status = 'Approved' ORDER BY `appointment_id`");
		$array = array();
        $count = 1;

        if($q->num_rows() > 0) {
            foreach($q->result_array() as $row) {
				$getParent = $this->db->query("SELECT * FROM `parents_tbl` WHERE parent_id = '".$row['appointment_parent_id']."'")->result_array();
                $getPatient = $this->db->query("SELECT * FROM `patients_tbl` WHERE patient_id = '".$row['appointment_patient_id']."'")->result_array();

                $array[] = array(
                    'overallId'            => $count,
                    'category'             => 'appointments',
                    'id'                   => $row['appointment_id'],
                    'parent_id'            => $row['appointment_parent_id'],
                    'parent_name'         => $getParent[0]['parent_name'],
                    'patient_id'           => $row['appointment_patient_id'],
                    'patient_name'         => $getPatient[0]['patient_name'],
                    'timestamp'            => $row['appointment_timestamp'],
                    'timestamp_end'        => $row['appointment_timestamp_end'],
                    'proof_of_transaction' => $row['appointment_proof_of_transaction'],
                    'prescription'         => '',
                    'description'          => $row['appointment_description'],
                    'datetime'             => $row['appointment_datetime'],
                    'datetime_end'         => $row['appointment_datetime_end'],
                    'reason'               => '', //
                    'approve_by'           => '', //
                    'approve_selection'    => '', //
                    'googlelink'           => '', //
                    'money'                => $row['money'],
                    'survey_done'          => $row['survey_done'],
                    'status'               => $row['appointment_status'],
                    'reference_number'     => $row['reference_number']
                );
                $count++;
            }
        }

        $q2 = $this->db->query("SELECT * FROM consultations  WHERE `date_consultation` >= '".$timestamp."' AND consultation_status = 'Approved'ORDER BY `consultation_id`");

        if($q2->num_rows() > 0) {
            foreach($q2->result_array() as $row2) {
                $getParent = $this->db->query("SELECT * FROM `parents_tbl` WHERE parent_id = '".$row2['consultation_parent_id']."'")->result_array();
                $getPatient = $this->db->query("SELECT * FROM `patients_tbl` WHERE patient_id = '".$row2['consultation_patient_id']."'")->result_array();

                $array[] = array(
                    'overallId'            => $count,
                    'category'             => 'consultations', //
                    'id'                   => $row2['consultation_id'], //
                    'parent_id'            => $row2['consultation_parent_id'], //
                    'parent_name'         => $getParent[0]['parent_name'], //
                    'patient_id'           => $row2['consultation_patient_id'], //
                    'patient_name'         => $getPatient[0]['patient_name'], //
                    'timestamp'            => $row2['date_consultation'], //
                    'timestamp_end'        => $row2['date_consultation_end'], //
                    'proof_of_transaction' => $row2['consultation_proof_of_transaction'], //
                    'prescription'         => $row2['consultation_prescription'], //
                    'description'          => '',
                    'datetime'             => $row2['date_consultation_datetime'], //
                    'datetime_end'         => $row2['date_consultation_datetime_end'], //
                    'reason'               => $row2['reason'], //
                    'approve_by'           => $row2['consultation_approve_by'], //
                    'approve_selection'    => $row2['consultation_approve_selection'], //
                    'googlelink'           => $row2['googlelink'], //
                    'money'                => $row2['money'], //
                    'survey_done'          => $row2['survey_done'], //
                    'status'               => $row2['consultation_status'], //
                    'reference_number'     => $row2['reference_number']
                );
                $count++;
            }
        }

        function sortTime($a, $b) {
			$a = $a['timestamp'];
			$b = $b['timestamp'];
			if ($a == $b)
			  return 0;
			return ($a < $b) ? -1 : 1;
		}

		usort($array, "sortTime");
		return $array;

		/*
        if($num_rowsss == 0) {
			
        } else {
			
            return array(
                'status' => 204,
                'message' => "Transactions not found."
            );
        }*/
    }

    public function transaction_appointment($id = "", $parent_id = "", $filter = "", $dates = "") {
        $record_per_page = 5;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;

        $q = "";
        if($parent_id == "") {
            $filter123 = "";
            $dates123 = "";
            if($filter == "") {
                if($dates == "") {
                    $filter123 = "";
                    $dates123 = "";
                } else if($dates != "") {
                    $filter123 = "";
                    $dates123 = "WHERE `date_text` = '".$dates."'";
                }
            } else if($filter != "") {
                if($dates == "") {
                    $filter123 = "WHERE `appointment_status` = '".$filter."'";
                    $dates123 = "";
                } else if($dates != "") {
                    $filter123 = "WHERE `appointment_status` = '".$filter."'";
                    $dates123 = "AND `date_text` = '".$dates."'";
                }
            }
            $q = $this->db->query("SELECT * FROM `appointments` ".$filter123." ".$dates123." ORDER BY `appointment_id` DESC LIMIT $start_from, $record_per_page");

        } else {
            $filter123 = "";
            $dates123 = "";
            $parents123 = "";
            if($filter == "") {
                if($dates == "") {
                    $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                    $filter123 = "";
                    $dates123 = "";
                    
                } else if($dates != "") {
                    $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                    $filter123 = "";
                    $dates123 = "AND `date_text` = '".$dates."'";
                }
            } else {
                if($dates == "") {
                    $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                    $filter123 = "AND `appointment_status` = '".$filter."'";
                    $dates123 = "";
                } else if($dates != "") {
                    $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                    $filter123 = "AND `appointment_status` = '".$filter."'";
                    $dates123 = "AND `date_text` = '".$dates."'";
                }
            }
            $q = $this->db->query("SELECT * FROM `appointments` ".$parents123." ".$filter123." ".$dates123."  ORDER BY `appointment_id` DESC LIMIT $start_from, $record_per_page");
        }
        $arr = array();

        $count = 1;

        if($q->num_rows() > 0) {
            // existing
            // success
            foreach($q->result_array() as $row) { 
                $getParent = $this->db->query("SELECT * FROM `parents_tbl` WHERE parent_id = '".$row['appointment_parent_id']."'")->result_array();
                $getPatient = $this->db->query("SELECT * FROM `patients_tbl` WHERE patient_id = '".$row['appointment_patient_id']."'")->result_array();
                $patients_illness = $this->db->query("SELECT * FROM `patients_illness_tbl` WHERE `type` = 'appointments' AND `id` = '".$row['appointment_id']."'");
                $illness="";
                if($patients_illness->num_rows() > 0) {
                    foreach($patients_illness->result_array() as $rews) {
                        $illness .= $rews['terms_title'].", ";
                    }
                }
                $arr[] = array(
                    'overallId'            => $count,
                    'category'             => 'appointments',
                    'id'                   => $row['appointment_id'],
                    'parent_id'            => $row['appointment_parent_id'],
                    'parent_name'         => $getParent[0]['parent_name'],
                    'patient_id'           => $row['appointment_patient_id'],
                    'patient_name'         => $getPatient[0]['patient_name'],
                    'timestamp'            => $row['appointment_timestamp'],
                    'timestamp_end'        => $row['appointment_timestamp_end'],
                    'proof_of_transaction' => $row['appointment_proof_of_transaction'],
                    'prescription'         => '',
                    'description'          => $row['appointment_description'],
                    'date_text'            => $row['date_text'],
                    'datetime'             => $row['appointment_datetime'],
                    'datetime_end'         => $row['appointment_datetime_end'],
                    'timestamp_sub'            => $row['appointment_timestamp_end'], //
                    'timestamp_sub_end'        => $row['appointment_timestamp_sub_end'], //
                    'reason'               => '', //
                    'approve_by'           => $row['appointment_approve_by'], //
                    'approve_selection'    => $row['appointment_approve_selection'], //
                    'interview_id'    => $row['interview_id'], //
                    'googlelink'           => '', //
                    'money'                => $row['money'],
                    'survey_done'          => $row['survey_done'],
                    'status'               => $row['appointment_status'],
                    'reference_number'     => $row['reference_number'],
                    'patient_illness'     => $illness
                );
                $count++;
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Transaction Appointment not found."
            );
        }
    }
    public function transaction_consultation($id = "", $parent_id = "", $filter = "", $dates = "") {
        $record_per_page = 5;
        $page = "";

        $q = "";

        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;
        if($parent_id == "") {
            $filter123 = "";
            $dates123 = "";
            if($filter == "") {
                if($dates == "") {
                    $filter123 = "";
                    $dates123 = "";
                } else if($dates != "") {
                    $filter123 = "";
                    $dates123 = "WHERE `date_text` = '".$dates."'";
                }
            } else if($filter != "") {
                if($dates == "") {
                    $filter123 = "WHERE `consultation_status` = '".$filter."'";
                    $dates123 = "";
                } else if($dates != "") {
                    $filter123 = "WHERE `consultation_status` = '".$filter."'";
                    $dates123 = "AND `date_text` = '".$dates."'";
                }
            }
            $q = $this->db->query("SELECT * FROM `consultations` ".$filter123." ".$dates123." ORDER BY `consultation_id` DESC LIMIT $start_from, $record_per_page");
        } else {
            $parents123 = "";
            $dates123 = "";
            $filter123 = "";

            if($filter == "") {
                if($dates == "") {
                    $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";	
                    $filter123 = "";
                    $dates123 = "";
                } else if($dates != "") {
                    $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";
                    $filter123 = "";
                    $dates123 = "AND `date_text` = '".$dates."'";
                }
            } else if($filter != "") {
                if($dates == "") {
                    $parents123 = "WHERE consultation_parent_id = '".$parent_id."'";
                    $filter123 = "AND consultation_status = '".$filter."'";
                    $dates123 = "";
                } else if($dates != "") {
                    $parents123 = "WHERE consultation_parent_id = '".$parent_id."'";
                    $filter123 = "AND consultation_status = '".$filter."'";
                    $dates123 = "AND `date_text` = '".$dates."'";	
                }
            }
            $q = $this->db->query("SELECT * FROM `consultations` ".$parents123." ".$filter123." ".$dates123." ORDER BY `consultation_id` DESC LIMIT $start_from, $record_per_page");	
        }
        $arr = array();

        $count = 1;

        if($q->num_rows() > 0) {
            // existing
            // success
            foreach($q->result_array() as $row2) { 
                $getParent = $this->db->query("SELECT * FROM `parents_tbl` WHERE parent_id = '".$row2['consultation_parent_id']."'")->result_array();
                $getPatient = $this->db->query("SELECT * FROM `patients_tbl` WHERE patient_id = '".$row2['consultation_patient_id']."'")->result_array();
                $patients_illness = $this->db->query("SELECT * FROM `patients_illness_tbl` WHERE `type` = 'consultations' AND `id` = '".$row2['appointment_id']."'");
                $illness="";
                if($patients_illness->num_rows() > 0) {
                    foreach($patients_illness->result_array() as $rews) {
                        $illness .= $rews['terms_title'].", ";
                    }
                }
                $arr[] = array(
                    'overallId'            => $count,
                    'category'             => 'consultations', //
                    'id'                   => $row2['consultation_id'], //
                    'parent_id'            => $row2['consultation_parent_id'], //
                    'parent_name'         => $getParent[0]['parent_name'], //
                    'patient_id'           => $row2['consultation_patient_id'], //
                    'patient_name'         => $getPatient[0]['patient_name'], //
                    'timestamp'            => $row2['date_consultation'], //
                    'timestamp_end'        => $row2['date_consultation_end'], //
                    'timestamp_sub'            => $row2['date_consultation_sub'], //
                    'timestamp_sub_end'        => $row2['date_consultation_sub_end'], //
                    'proof_of_transaction' => $row2['consultation_proof_of_transaction'], //
                    'prescription'         => $row2['consultation_prescription'], //
                    'description'          => '',
                    'date_text'            => $row2['date_text'],
                    'datetime'             => $row2['date_consultation_datetime'], //
                    'datetime_end'         => $row2['date_consultation_datetime_end'], //
                    'reason'               => $row2['reason'], //
                    'approve_by'           => $row2['consultation_approve_by'], //
                    'approve_selection'    => $row2['consultation_approve_selection'], //
                    'interview_id'    => $row2['interview_id'], //
                    'googlelink'           => $row2['googlelink'], //
                    'money'                => $row2['money'], //
                    'survey_done'          => $row2['survey_done'], //
                    'status'               => $row2['consultation_status'], //
                    'reference_number'     => $row2['reference_number'],
                    'patient_illness'      => $illness
                );
                $count++;
            }
            return $arr;
        } else {
            return array(
                'status' => 204,
                'message' => "Transaction Consultation not found."
            );
        }
    }

    public function terms($type = "", $id = "") {
        
        // exist
        $q = $this->db->query("SELECT * FROM terms_tbl");
        $array = array();
        if($q->num_rows() > 0) {
            //exist
            foreach($q->result_array() as $row) {
                $type2 = "";
                $booleans = "";
                $patient_illness = $this->db->query("SELECT * FROM `patients_illness_tbl` WHERE `type` = '".$type."' AND `id` = '".$id."' AND `terms_id` = '".$row['terms_id']."'");
                if($patient_illness->num_rows() > 0) {
                    // exists
                    $booleans = true;
                } else {
                    // not exists
                    $booleans = false;
                }
                $array[] = array(
                    'type' => $type,
                    'id'      => $id,
                    'terms_id' => $row['terms_id'],
                    'terms_title' => $row['terms_title'],
                    'isChecked' => $booleans
                );
            }
            return $array;
            
        } else {
            // not exist
            return array(
                'status' => 204,
                'message' => "Terms not found."
            );
        }
    }

    public function getDate($type = "", $dates = "", $parent_id = "", $filter = "") {
        if($type == "consultation") {
            $q = "";
            $num = 0;

            $parents123 = "";
            $filter123 = "";
            $dates123 = "";

            if($parent_id == "") {
                if($filter == "") {
                    if($dates == "") {
                        $num = 1;
                        $parents123 = "";
                        $filter123 = "";
                        $dates123 = "";
                    } else if($dates != "") {
                        $num = 2;
                        $parents123 = "";
                        $filter123 = "";
                        $dates123 = "WHERE `date_text` = '".$dates."'";
                    }
                } else {
                    if($dates == "") {
                        $num = 3;
                        $parents123 = "";
                        $filter123 = "WHERE `consultation_status` = '".$filter."'";
                        $dates123 = "";
                    } else if($dates != "") {
                        $num = 4;
                        $parents123 = "";
                        $filter123 = "WHERE `consultation_status` = '".$filter."'";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                    
                }
            } else {
                
                if($filter == "") {
                    if($dates == "") {
                        $num = 5;
                        $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";
                        $filter123 = "";
                        $dates123 = "";
                    } else if($dates != "") {
                        $num = 6;
                        $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";
                        $filter123 = "";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                } else {
                    if($dates == "") {
                        $num = 7;
                        $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";
                        $filter123 = "AND `consultation_status` = '".$filter."'";
                        $dates123 = "";
                    } else if($dates != "") {
                        $num = 8;
                        $parents123 = "WHERE `consultation_parent_id` = '".$parent_id."'";
                        $filter123 = "AND `consultation_status` = '".$filter."'";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                }
            }
            $q = $this->db->query("SELECT `date_text` FROM `consultations` ".$parents123." ".$filter123." ".$dates123." GROUP BY `date_text`");
            $array = array();
            $array[] = array('date_text' => 'All');
            if($q->num_rows() > 0) {
                foreach($q->result_array() as $row) {
                    $array[] = array(
                        'date_text' => $row['date_text']
                    );
                }
            } else {
                return array(
                    'status' => 204,
                    'message' => "Get Date not found. " . $num
                );
            }

            return $array;
        } else if($type == "appointment") {
            $parents123 = "";
            $filter123 = "";
            $dates123 = "";
            $q = "";
            if($parent_id == "") {
                
                if($filter == "") {
                    if($dates == "") {
                        $parents123 = "";
                        $filter123 = "";
                        $dates123 = "";
                    } else if($dates != "") {
                        $parents123 = "";
                        $filter123 = "";
                        $dates123 = "WHERE `date_text` = '".$dates."'";
                    }
                } else {
                    if($dates == "") {
                        $parents123 = "";
                        $filter123 = "WHERE `appointment_status` = '".$filter."'";
                        $dates123 = "";
                    } else if($dates != "") {
                        $parents123 = "";
                        $filter123 = "WHERE `appointment_status` = '".$filter."'";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                }
                
            } else {
                $parents123 = "";
                $filter123 = "";
                $dates123 = "";
                if($filter == "") {
                    if($dates == "") {
                        $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                        $filter123 = "";
                        $dates123 = "";
                    } else if($dates != "") {
                        $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                        $filter123 = "";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                } else {
                    if($dates == "") {
                        $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                        $filter123 = "AND `appointment_status` = '".$filter."'";
                        $dates123 = "";
                    } else if($dates != "") {
                        $parents123 = "WHERE `appointment_parent_id` = '".$parent_id."'";
                        $filter123 = "AND `appointment_status` = '".$filter."'";
                        $dates123 = "AND `date_text` = '".$dates."'";
                    }
                }
            }
            $q = $this->db->query("SELECT `date_text` FROM `appointments` ".$parents123." ".$filter123." ".$dates123."  GROUP BY `date_text`");
            $array = array();
            $array[] = array('date_text' => 'All');
            if($q->num_rows() > 0) {
                foreach($q->result_array() as $row) {
                    $array[] = array(
                        'date_text' => $row['date_text']
                    );
                }
            } else {
                return array(
                    'status' => 204,
                    'message' => "Get Date not found."
                );
            }

            return $array;
        } else {
            return array(
                'status' => 204,
                'message' => "Get Date not found."
            );
        }
    }
    public function getSchedule($id = "", $type = "", $parent_id = "", $filter = "") {
        $record_per_page = 5;
        $page = "";
        if(isset($id)) {
            $page = $id;
        } else {
            $page = 1;
        }

        $start_from = ($page-1) * $record_per_page;

        if($type == "consultation") {
            if($parent_id == "") {
                if($filter == "") {
                    $q = $this->db->query("SELECT `date_text` FROM `consultations` GROUP BY `date_text` ORDER BY `consultation_id` DESC LIMIT $start_from, $record_per_page");
                } else {
                    $q = $this->db->query("SELECT `date_text` FROM `consultations` WHERE `consultation_status` = '".$filter."' GROUP BY `date_text` DESC LIMIT $start_from, $record_per_page");
                }
            } else {
                if($filter == "") {
                    $q = $this->db->query("SELECT `date_text` FROM `consultations` WHERE `consultation_parent_id` = '".$parent_id."' GROUP BY `date_text` DESC LIMIT $start_from, $record_per_page");
                } else {
                    $q = $this->db->query("SELECT `date_text` FROM `consultations` WHERE `consultation_status` = '".$filter."' AND `consultation_parent_id` = '".$parent_id."' GROUP BY `date_text` DESC LIMIT $start_from, $record_per_page");
                }
                
            }

            $array = array();
            if($q->num_rows() > 0) {
                foreach($q->result_array() as $row) {
                    $array[] = array(
                        'date_text' => $row['date_text']
                    );
                }
            } else {
                return array(
                    'status' => 204,
                    'message' => "Get Date not found."
                );
            }

            return $array;
        } else if($type == "appointment") {
            if($parent_id == "") {
                if($filter == "") {
                    $q = $this->db->query("SELECT `date_text` FROM `appointments` GROUP BY `date_text`");
                } else {
                    $q = $this->db->query("SELECT `date_text` FROM `appointments` WHERE `appointment_status` = '".$filter."' GROUP BY `date_text`");
                }
            } else {
                if($filter == "") {
                    $q = $this->db->query("SELECT `date_text` FROM `appointments` WHERE `appointment_parent_id` = '".$parent_id."' GROUP BY `date_text`");
                } else {
                    $q = $this->db->query("SELECT `date_text` FROM `appointments` WHERE `appointment_parent_id` = '".$parent_id."' AND `appointment_status` = '".$filter."' GROUP BY `date_text`");
                }
            }

            $array = array();
            if($q->num_rows() > 0) {
                foreach($q->result_array() as $row) {
                    $array[] = array(
                        'date_text' => $row['date_text']
                    );
                }
            } else {
                return array(
                    'status' => 204,
                    'message' => "Get Date not found."
                );
            }

            return $array;
        } else {
            return array(
                'status' => 204,
                'message' => "Get Date not found."
            );
        }
    }
    public function deleteIllness($type = "", $id = "") {
        $this->db->query("DELETE FROM patients_illness_tbl WHERE `type` = '".$type."' AND `id` = '".$id."'");
    }

    public function addIllness($type = "", $id = "", $terms_id = "") {
        if($type == "" && $id == "" && $terms_id == "") {
            return array(
                'status' => 204,
                'message' => "Add Illness not found."
            );
        } else {
            $q = $this->db->query("SELECT * FROM `terms_tbl` WHERE `terms_id` = '".$terms_id."'")->result_array();
            $array = array(
                "type" => $type,
                "id" => $id,
                "terms_id" => $terms_id,
                "terms_title" => $q[0]['terms_title'],
                "timestamp" => time()
            );

            $this->db->insert('patients_illness_tbl', $array);
        }
    }
    public function updateGoogleLink($id = "", $googlelink = "") {
        if($id == "" && $googlelink == "") {
            return array(
                'status' => 204,
                'message' => "Update Google Link not found."
            );
        } else {
            $q = $this->db->query("SELECT * FROM consultations WHERE consultation_id = '".$id."'");
            if($q->num_rows() > 0) {
                // exist
                
                $this->db->query("UPDATE `consultations` SET `googlelink` = '".$googlelink."' WHERE `consultation_id` = '".$id."'");

                $qs = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$qs[0]['consultation_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$qs[0]['consultation_patient_id']."'")->result_array();
                $message = "For patient name: ".$p2[0]['patient_name']."\nHere's the google link: ".$qs[0]['googlelink']."\n\nDate start: ".$qs[0]['date_consultation_datetime']."\nDate end: ".$qs[0]['date_consultation_datetime_end']."\n\nSee you there!";
                $this->auth_model->itexmo($p[0]['parent_phonenumber'], $message);

                return array(
                    'status' => 200,
                    'message' => $message
                );
            } else {
                return array(
                    'status' => 204,
                    'message' => "Update Google Link not found."
                );
            }
        }
    }
    public function approveThis($type = "", $id = "") {
        if($type == "" && $id == "") {
            return array(
                'status' => 204,
                'message' => "Type and ID not found."
            );
        } else {
            if($type == "appointments") {
                $this->db->query("UPDATE `appointments` SET `appointment_status` = 'Approved', `appointment_timestamp` = 0, `appointment_timestamp_end` = 0, WHERE `appointment_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `appointments` WHERE `appointment_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['appointment_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['appointment_patient_id']."'")->result_array();
                //$message = "Your appointment request has been approved!\n\nDate start: ".$q[0]['appointment_datetime']."\nDate end: ".$q[0]['appointment_datetime_end']."\n\nWe will message you via SMS as soon as the link is ready for your appointment";
                $message = "Your appointment request for ".$p2[0]['patient_name']." has been approved!\n\nDate start: ".$q[0]['appointment_datetime']."\nDate end: ".$q[0]['appointment_datetime_end'];
		        $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);

            } else if($type == "consultations") {
                $this->db->query("UPDATE `consultations` SET `consultation_status` = 'Approved', `date_consultation` = 0, `date_consultation_end` = 0 WHERE `consultation_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['consultation_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['consultation_patient_id']."'")->result_array();
                $message = "Your consultation request for ".$p2[0]['patient_name']." has been approved!\n\nDate start: ".$q[0]['date_consultation_datetime']."\nDate end: ".$q[0]['date_consultation_datetime_end']."\n\nWe will message you via SMS as soon as the link is ready for your consultation";
                $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);
            }
            
        }
    }
    public function cancelThis($type = "", $id = "") {
        if($type == "" && $id == "") {
            return array(
                'status' => 204,
                'message' => "Type and ID not found."
            );
        } else {
            if($type == "appointments") {
                $this->db->query("UPDATE `appointments` SET `appointment_status` = 'Cancelled' WHERE `appointment_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `appointments` WHERE `appointment_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['appointment_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['appointment_patient_id']."'")->result_array();
                //$message = "Your appointment request has been approved!\n\nDate start: ".$q[0]['appointment_datetime']."\nDate end: ".$q[0]['appointment_datetime_end']."\n\nWe will message you via SMS as soon as the link is ready for your appointment";
                $message = "Your appointment request for ".$p2[0]['patient_name']." has been cancelled!";
		        $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);

            } else if($type == "consultations") {
                $this->db->query("UPDATE `consultations` SET `consultation_status` = 'Cancelled' WHERE `consultation_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['consultation_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['consultation_patient_id']."'")->result_array();
                $message = "Your consultation request for ".$p2[0]['patient_name']." has been cancelled!";
                $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);
            }
            
        }
    }
    public function doneThis($type = "", $id = "") {
        if($type == "" && $id == "") {
            return array(
                'status' => 204,
                'message' => "Type and ID not found."
            );
        } else {
            if($type == "appointments") {
                $this->db->query("UPDATE `appointments` SET `appointment_status` = 'Finished' WHERE `appointment_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `appointments` WHERE `appointment_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['appointment_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['appointment_patient_id']."'")->result_array();
                //$message = "Your appointment request has been approved!\n\nDate start: ".$q[0]['appointment_datetime']."\nDate end: ".$q[0]['appointment_datetime_end']."\n\nWe will message you via SMS as soon as the link is ready for your appointment";
                $message = "Your appointment request for ".$p2[0]['patient_name']." has been finished!";
		        $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);

            } else if($type == "consultations") {
                $this->db->query("UPDATE `consultations` SET `consultation_status` = 'Finished' WHERE `consultation_id` = '".$id."'");

                $q = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_id` = '".$id."'")->result_array();
                $p = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$q[0]['consultation_parent_id']."'")->result_array();
                $p2 = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$q[0]['consultation_patient_id']."'")->result_array();
                $message = "Your consultation request for ".$p2[0]['patient_name']." has been finished!";
                $this->power_model->itexmo($p[0]['parent_phonenumber'], $message);
            }
            
        }
    }
}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		parent::__construct();
		$this->load->model('home_model', null, true); // auto-connect model
	}

	public function index()
	{
		$data = array(
			'title' => 'Home',
			'content' => 'Home'
		);
		$this->load->view('Home/Include/header', $data);
		$this->load->view('Home/Home_index');
		$this->load->view('Home/Include/footer');
	}

	public function resend() {
		$this->load->model('login_model', null, true); // auto-connect model


		$otp = rand(000000,999999);
		$copyOtp = $otp;
		if($this->session->selection == "doctor"){

			$llsdl = $this->db->query("SELECT * FROM `doctors_tbl` WHERE `doctor_id`= '".$this->session->id."'")->result_array();
			$this->home_model->itexmo($llsdl[0]['doctor_phonenumber'], $copyOtp . ' is your OTP. Please enter this to confirm your login. (Resend Code)');
			$this->db->query("UPDATE doctors_tbl SET doctor_sms_code = '".$copyOtp."' WHERE doctor_id= '".$this->session->id."'");
		} else if($this->session->selection == "administrator"){

			$llsdl = $this->db->query("SELECT * FROM `admins_tbl` WHERE `admin_id`= '".$this->session->id."'")->result_array();
			$this->home_model->itexmo($llsdl[0]['admin_phonenumber'], $copyOtp . ' is your OTP. Please enter this to confirm your login. (Resend Code)');
			$this->db->query("UPDATE admins_tbl SET admin_sms_code = '".$copyOtp."' WHERE admin_id= '".$this->session->id."'");
		} else if($this->session->selection == "receptionist"){

			$llsdl = $this->db->query("SELECT * FROM `receptionists_tbl` WHERE `receptionist_id`= '".$this->session->id."'")->result_array();
			$this->home_model->itexmo($llsdl[0]['receptionist_phonenumber'], $copyOtp . ' is your OTP. Please enter this to confirm your login. (Resend Code)');
			$this->db->query("UPDATE receptionists_tbl SET receptionist_sms_code = '".$copyOtp."' WHERE receptionist_id= '".$this->session->id."'");

		}
		
		redirect($this->session->selection."/verification?success");
	}

	public function insert() {
	    $this->form_validation->set_rules('fullname','Name','required');
	    $this->form_validation->set_rules('email','Email','required|valid_email');
	    $this->form_validation->set_rules('phoneNumber','Phone Number','required');
	    $this->form_validation->set_rules('title','Title','required');
	    $this->form_validation->set_rules('message','message','required');
	    
	    if($this->form_validation->run()==FALSE) {
	        echo validation_errors();
	    } else {
	    
    		$insert = [
    			'Inquiries_Name' => $this->input->post('fullname'),
    			'Inquiries_EmailAddress' => $this->input->post('email'),
    			'Inquiries_PhoneNumber' => $this->input->post('phoneNumber'),
    			'Inquiries_title' => $this->input->post('title'),
    			'Inquiries_body' => $this->input->post('message'),
    			'Inquiries_DateTime' => time()
    		];
    		$this->home_model->insertInquiries($insert);
	    }
		//redirect("../home?success=yay");
	}
	
	public function forgotpassword() {
		if($this->session->userdata('id') && $this->session->userdata('selection') == "doctor") {
			redirect('doctor');
		} else if($this->session->userdata('id') && $this->session->userdata('selection') == "administrator") {
			redirect('administrator');
		} else if($this->session->userdata('id') && $this->session->userdata('selection') == "receptionist") {
			redirect('receptionist');
		}
		
		$data = array(
			'title' => 'Forgot Password',
			'error' => '',
			'success' => ''
		);

		// form valdiation
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('selection', 'selection', 'required');

		if($this->form_validation->run() == FALSE) {
			$this->load->view('Home/Include/header', $data);
			$this->load->view('Home/forgotpassword');
			$this->load->view('Home/Include/footer');
		} else {
			$result = $this->home_model->forgotpassword($this->input->post('email'), $this->input->post('selection'));
			if($result == 'Successfully') {

				$gettingCode = $this->home_model->getCode($this->input->post('email'), $this->input->post('selection'));
				$gettingUsername = $this->home_model->getEmailToUsername($this->input->post('email'), $this->input->post('selection'));
				// email
				$config['useragent'] = 'CodeIgniter';
				$config['protocol']    = 'smtp';
				$config['smtp_host']    = 'ssl://smtp.hostinger.com';
				$config['smtp_port']    = '465';
				$config['smtp_timeout'] = '7';
				$config['smtp_user']    = 'harvs@peekabook.tech';
				$config['smtp_pass']    = 'Akashi24';
				
				//$config['smtp_host']    = 'ssl://smtp.gmail.com';
				//$config['smtp_port']    = '465';
				//$config['smtp_timeout'] = '7';
				//$config['smtp_user']    = 'blackspidermanxx66@gmail.com';
				//$config['smtp_pass']    = 'sirjeansmolpp';
				$config['charset']    = 'utf-8';
				$config['newline']    = "\r\n";
				$config['mailtype'] = 'text'; // or html
				$config['validation'] = TRUE; // bool whether to validate email or not      
				$this->email->initialize($config);
				$this->email->from('harvs@peekabook.tech', 'Forgot your password!');
				$this->email->to($this->input->post('email'));
				$this->email->subject('Please verify your account!');
				$this->email->message('Hi '.$this->input->post('email').'! '.base_url().'home/forgot/'.md5($gettingCode).'/'.$gettingUsername.'/'.$this->input->post('selection'));
				$this->email->send();
				//echo $this->email->print_debugger();

				$data['success'] = 'Successfully!';
				$this->load->view('Home/Include/header', $data);
				$this->load->view('Home/forgotpassword', $data);
				$this->load->view('Home/Include/footer');
			} else {
				// error
				$data['error'] = 'Error! Email doesn\'t exist';
				$this->load->view('Home/Include/header', $data);
				$this->load->view('Home/forgotpassword', $data);
				$this->load->view('Home/Include/footer');
			}
		}
	}
	public function tests($x,$y,$z) {
		echo $x . '<br/>';
		echo $y . '<br/>';
		echo $z . '<br/>';
	}
	public function forgot($md5, $username, $selection) {
		$data = array(
			'title' => 'Forgot Password',
			'error' => '',
			'success' => ''
		);
        if($selection != "doctor" && $selection != "administrator" &&$selection != "receptionist") {
            redirect("login?error=404");   
        }
        
		$gettingCode = $this->home_model->getCodeFromUsername($username, $selection);
        
        
		if(md5($gettingCode) == $md5) {
			$this->form_validation->set_rules('password', 'Password', 'required|min_length[5]', 
	            array(
	                "min_length" => "Your password is incorrect."
	            )
	        );
			$this->form_validation->set_rules('repassword', 'Re-type Password', 'required|min_length[5]', 
	            array(
	                "min_length" => "Your password is incorrect."
	            )
	        );
	        if($this->form_validation->run() == FALSE) {
				$this->load->view('Home/Include/header', $data);
				$this->load->view('Home/forgot', $data);
				$this->load->view('Home/Include/footer');
			} else {
				if($this->input->post('password') == $this->input->post('repassword')) {
				    if($selection == "doctor") {
    					$this->home_model->removeCode($username, $selection);
    					$this->home_model->updatePassword($username, md5($this->input->post('password')), $selection);
    					$data['success'] = 'Successfully!';
    					$this->load->view('Home/Include/header', $data);
    					$this->load->view('Home/forgot', $data);
    					$this->load->view('Home/Include/footer');
				    } else if($selection == "receptionist") {
    					$this->home_model->removeCode($username, $selection);
    					$this->home_model->updatePassword($username, md5($this->input->post('password')), $selection);
    					$data['success'] = 'Successfully!';
    					$this->load->view('Home/Include/header', $data);
    					$this->load->view('Home/forgot', $data);
    					$this->load->view('Home/Include/footer');
				    }  else if($selection == "administrator") {
    					$this->home_model->removeCode($username, $selection);
    					$this->home_model->updatePassword($username, md5($this->input->post('password')), $selection);
    					$data['success'] = 'Successfully!';
    					$this->load->view('Home/Include/header', $data);
    					$this->load->view('Home/forgot', $data);
    					$this->load->view('Home/Include/footer');
				    }
				} else {
					$data['error'] = 'Error! Password and Re-type Password doesn\'t match.';
					$this->load->view('Home/Include/header', $data);
					$this->load->view('Home/forgot', $data);
					$this->load->view('Home/Include/footer');
				}
	        }

		} else {
			redirect("login?error=404");
			//echo md5($gettingCode);
			//echo '<br/>';
			//echo $md5;
		}
	}
}

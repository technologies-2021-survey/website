<div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
    <ul class="list-group panel">
        <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>SIDE PANEL</b></li>
        <li class="list-group-item"><a href="./index"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
        <li>
            <a href="#sidebar" class="list-group-item " data-toggle="collapse">Menu  <span class="glyphicon glyphicon-chevron-right"></span></a>
        </li>
        <li class="collapse" id="sidebar">
            <a href="<?=base_url('/receptionist/inquiries_list');?>"  class="list-group-item">Inquiries List</a>
            <a href="<?=base_url('/receptionist/appointment');?>"  class="list-group-item">Appointment</a>
            <a href="<?=base_url('/receptionist/payment');?>"  class="list-group-item">Payment</a>
            <a href="<?=base_url('/receptionist/consultation');?>"  class="list-group-item">Consultation</a>
            <a href="<?=base_url('/receptionist/transaction');?>"  class="list-group-item">Transaction</a>
            <a href="<?=base_url('/receptionist/immunizationrecord');?>"  class="list-group-item">Immunization Record</a>
            <a href="<?=base_url('/receptionist/parents');?>"  class="list-group-item">Parent List</a>
            <a href="<?=base_url('/receptionist/patients');?>" class="list-group-item">Patient List</a>
        </li>
    </ul>
</div>
<?php $this->load->view('Receptionist/Receptionist_navigation'); ?>

    <h2>Child List / <?php echo $parent_name;?></h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Patient Name</th>
                <th>Patient Gender</th>
                <th>Patient Birthdate</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach($listChilds as $row) {
                echo '<tr class="listChilds-'.$row['patient_id'].'">';
                    echo '<td>'.$i++.'</td>';
                    echo '<td>'.$row['patient_name'].'</td>';
                    echo '<td>'.$row['patient_gender'].'</td>';
                    echo '<td>'.$row['patient_birthdate'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().'receptionist/editChild/'.$row['patient_id'].'" class="btn btn-warning" style="margin-right:10px;">Edit</a>';
                        echo '<a href="'.base_url().'receptionist/deleteChild/'.$row['patient_id'].'" class="btn btn-danger" style="margin-right:10px;">Delete</a>';
                        echo '<a href="'.base_url().'receptionist/viewImmunizationRecord/'.$row['patient_id'].'" class="btn btn-info">View Immunization Record</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
    <?php echo $links; ?>
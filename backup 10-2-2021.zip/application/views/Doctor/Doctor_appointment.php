<?php $this->load->view('Doctor/Doctor_navigation'); ?>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment-with-locales.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>

        <!-- Tempus Dominus JavaScript -->
        <script src="https://rawgit.com/tempusdominus/bootstrap-3/master/build/js/tempusdominus-bootstrap-3.js" crossorigin="anonymous"></script>

        <!-- Tempus Dominus Styles -->
        <link href="https://rawgit.com/tempusdominus/bootstrap-3/master/build/css/tempusdominus-bootstrap-3.css" rel="stylesheet" crossorigin="anonymous">
        
        
        <h2>Appointment</h2>
        <div id="calendar"></div>
        
        <!-- Modal -->
        <div class="modal fade" id="addAppointmentModel" tabindex="-1" role="dialog" aria-labelledby="addAppointmentLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addAppointmentLabel">Add Appointment</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button> 
                    </div>
                    <div class="modal-body">
                        <form id="addAppointment">
                        <div class="form-group">
                                <label>Details</label>
                                <textarea id="details" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Start date / time</label>
                                <div class="input-group date"  id="dateTime" data-target-input="nearest">
                                    <input type="text" id="getTime" class="form-control datetimepicker-input" data-target="#dateTime"/>
                                    <span class="input-group-addon" data-target="#dateTime" data-toggle="datetimepicker">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>End date / time</label>
                                <input type="text" id="getTime2" class="form-control" readonly=""/>
                            </div>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function(){
                var calendar = $('#calendar').fullCalendar({
                    editable:true,
                    header:{
                        left:'prev,next today',
                        center:'title',
                        right:'month,agendaWeek,agendaDay'
                    },
                    events:"<?php echo base_url(); ?>doctor/getAppointment",
                    selectable:true,
                    selectHelper:true,
                    select:function(start, end, allDay)
                    {
                        $('#addAppointmentModel').modal();
                        $('#addAppointment').submit(function(e) {
                            e.preventDefault();
                            var details = $('#details').val();
                            var start = $('#getTime').val();

                            var date = new Date(start);
                            var options = {
                                year: 'numeric',
                                day: 'numeric',
                                month: 'numeric',
                                hour: 'numeric',
                                minute: 'numeric',
                                second: 'numeric',
                                hour12: false
                            };
                            var timeString = date.toLocaleString('en-US', options);

                            $.ajax({
                                url:"<?php echo base_url(); ?>doctor/addAppointment",
                                type:"POST",
                                data:{
                                    appointment_description:details, 
                                    appointment_datetime:timeString
                                },
                                success:function(data) {
                                    if(data == "exist") {
                                        alert("That reservation has been exist!");
                                        return false;
                                    } else {
                                        calendar.fullCalendar('refetchEvents');
                                        alert("Added Successfully");
                                        return false;
                                    }
                                }
                            });
                        });
                        /*
                        var title = prompt("Enter Event Title");
                        if(title)
                        {
                            var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                            var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
                            $.ajax({
                                url:"<?php echo base_url(); ?>fullcalendar/insert",
                                type:"POST",
                                data:{title:title, start:start, end:end},
                                success:function()
                                {
                                    calendar.fullCalendar('refetchEvents');
                                    alert("Added Successfully");
                                }
                            })
                        }*/
                    },
                    editable:true,
                    eventResize:function(event)
                    {
                        var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                        var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");

                        var title = event.title;

                        var id = event.id;

                        $.ajax({
                            url:"<?php echo base_url(); ?>fullcalendar/update",
                            type:"POST",
                            data:{title:title, start:start, end:end, id:id},
                            success:function()
                            {
                                calendar.fullCalendar('refetchEvents');
                                alert("Event Update");
                            }
                        })
                    },
                    eventDrop:function(event)
                    {
                        var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                        //alert(start);
                        var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                        //alert(end);
                        var title = event.title;
                        var id = event.id;
                        $.ajax({
                            url:"<?php echo base_url(); ?>fullcalendar/update",
                            type:"POST",
                            data:{title:title, start:start, end:end, id:id},
                            success:function()
                            {
                                calendar.fullCalendar('refetchEvents');
                                alert("Event Updated");
                            }
                        })
                    },
                    eventClick:function(event)
                    {
                        if(confirm("Are you sure you want to remove it?"))
                        {
                            var id = event.id;
                            $.ajax({
                                url:"<?php echo base_url(); ?>fullcalendar/delete",
                                type:"POST",
                                data:{id:id},
                                success:function()
                                {
                                    calendar.fullCalendar('refetchEvents');
                                    alert('Event Removed');
                                }
                            })
                        }
                    }
                });
            });
            $(function () {
                $('#dateTime').datetimepicker({
                    useSeconds: false,
                    stepping: 30,
                    disabledHours: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                    enabledHours: [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
                });
                $('input#getTime').on('input', function(){
                    var datetime = $('#getTime').val();
                    var d = new Date(datetime);
                    d.setMinutes ( d.getMinutes() + 30 );
                    $('#getTime2').val(getDateTimeFromTimestamp(d));
                });
            });
            function getDateTimeFromTimestamp(unixTimeStamp) {
                var date = new Date(unixTimeStamp + 30 * 60000);
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                minutes = minutes < 10 ? '0'+minutes : minutes;
            
                return ('0' + (date.getMonth() + 1)).slice(-2) + '/' +  ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear() + ' ' + ('0' + hours).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2) + ampm;
            }
        </script>

<?php $this->load->view('Doctor/Doctor_navigation'); ?>

    <form id="changepasswords">
        <div class="form-group">
            <label>
                Old Password
            </label>
            <input type="password" class="form-control" id="oldpassword" required="">
        </div>
        <div class="form-group">
            <label>
                New Password
            </label>
            <input type="password" class="form-control" id="newpassword" required="">
        </div>
        <div class="form-group">
            <label>
                Re-type New Password
            </label>
            <input type="password" class="form-control" id="retypenewpassword" required="">
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Change Password" name="submit" >
        </div>
    </form>
    <script type="text/javascript">
    $(document).ready(function() {
        
        $('#changepasswords').submit(function(e) {
            e.preventDefault();
            var oldpassword = $('#oldpassword').val();
            var newpassword = $('#newpassword').val();
            var retypenewpassword = $('#retypenewpassword').val();

            $.ajax({
                type: 'post',
                url: "<?php echo base_url(); ?>index.php/doctor/change_password2",
                data:{oldpassword:oldpassword, newpassword:newpassword, retypenewpassword:retypenewpassword},
                success:function(response) {
                    if(response != "success") {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops....',
                            html: response
                        })
                    } else {
                        Swal.fire({
                            icon: 'success',
                            title: 'Successfully',
                            text: 'Your password has been changed successfully.'
                        })
                    }
                }
            });
        });
    });
    </script>
<div class="container" style="padding-top: 15%;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <?php
            if($error != ""):
            ?>
			<div class="alert alert-danger">
			<?php
				echo $error;
			?>
			</div>
			<?php
			    endif;
			?>
            <div class="panel panel-primary" >
                <div class="panel-body" style="padding-top: 50px;padding-bottom: 50px;">
                    <h4 style="text-align:center;">Please enter your one time password to verify your account</h4>
                    <?php
					echo form_open('doctor/verification');
					?>
                        <input type="text" name="otp" class="form-control" />
                        <input type="submit" name="submit" class="btn btn-primary" style="margin: 0 auto;display:block;margin-top: 25px;" value="Validate">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
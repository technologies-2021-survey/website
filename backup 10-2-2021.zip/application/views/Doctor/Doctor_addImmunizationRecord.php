<?php $this->load->view('Doctor/Doctor_navigation'); ?>

    <h2>Add Immunization Record</h2>

    <form action="<?php echo base_url(); ?>doctor/addImmunizationRecord/<?php echo $this->uri->segment(3); ?>" method="POST">
        <div class="form-group">
            <label>Patient Name</label>
            <input type="text" name="patient_name" class="form-control" value="<?php echo $patient_name; ?>" disabled="">
        </div>
        <div class="form-group">
            <label>Parent Name</label>
            <input type="text" name="parent_name" class="form-control" value="<?php echo $parent_name; ?>" disabled="">
        </div>
        <div class="form-group">
            <label>Date</label>
            <input type="date" name="dates" class="form-control">
        </div>
        <div class="form-group">
            <label>Vaccine</label>
            <input type="text" name="vaccine" class="form-control">
        </div>
        <div class="form-group">
            <label>Route</label>
            <input type="text" name="route" class="form-control">
        </div>
        <div class="pull-right">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
        </div>
        <div style="clear:both;"></div>
    </form>
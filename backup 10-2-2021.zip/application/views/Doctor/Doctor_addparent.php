    <?php $this->load->view('Doctor/Doctor_navigation'); ?>

    
        <h2>Add Parent</h2>
        
        <form action="<?php echo base_url(); ?>doctor/addParents" method="POST">
            <div class="form-group">
                <label>Parent Name</label>
                <input type="text" name="parent_name" class="form-control">
            </div>
            <div class="form-group">
                <label>Parent Username</label>
                <input type="text" name="parent_username" class="form-control">
            </div>
            <div class="form-group">
                <label>Parent Email</label>
                <input type="email" name="parent_emailaddress" class="form-control">
            </div>
            <div class="form-group">
                <label>Parent Phone Number</label>
                <input type="text" name="parent_phonenumber" class="form-control">
            </div>
            <div class="pull-right">
                <input type="submit" name="submit" value="Submit" class="btn btn-primary">
            </div>
            <div style="clear:both;"></div>
        </form>
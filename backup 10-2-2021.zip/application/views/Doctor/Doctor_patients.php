<?php $this->load->view('Doctor/Doctor_navigation'); ?>
    <h2>Patient List</h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Patient Name</th>
                <th>Gender</th>
                <th>Birthdate</th>
                <th>Parent Name</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($patients as $row) {
                echo '<tr class="patients-'.$row['parent_id'].'">';
                    echo '<td>'.$row['patient_id'].'</td>';
                    echo '<td>'.$row['patient_name'].'</td>';
                    echo '<td>'.$row['patient_gender'].'</td>';


                    $birthDate = $row['patient_birthdate'];
                    $from = new DateTime($birthDate);
                    $to   = new DateTime('today');
                    $age = $from->diff($to)->y;

                    echo '<td>'.$row['patient_birthdate'].'<br/>(Age: '.$age.')</td>';
                    echo '<td>'.$row['parent_name'].'</td>';
                    echo '<td><a href="'.base_url().'doctor/addImmunizationRecord/'.$row['patient_id'].'" class="btn btn-warning" style="margin-right:10px;">Add Immunization Record</a></td>';
                    echo '<td><a href="'.base_url().'doctor/viewImmunizationRecord/'.$row['patient_id'].'" class="btn btn-warning" style="margin-right:10px;">View Immunization Record</a></td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

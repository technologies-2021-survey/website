<?php $this->load->view('Doctor/Doctor_navigation'); ?>

		
		<div class="chat-container">
			<div class="col-sm-4">
				<div class="search">
					<input type="text" id="search" class="form-control">
				</div>
				<div class="people-list">
					<div class="people-info">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<p>test</p>
					</div>
					<div class="people-info">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<p>test</p>
					</div>
					<div class="people-info">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<p>test</p>
					</div>
					<div class="people-info">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<p>test</p>
					</div>
					<div class="people-info">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<p>test</p>
					</div>
				</div>
				<div style="clear:both;"></div>
			</div>
			<div class="col-sm-8" style="position: relative; height: 100%;">
				<div class="chat" style="height: 100%; position: relative;">
					<div class="chat-heading">
						<img src="<?php echo base_url(). 'assets/img/whealth.png';?>" class="img-circle img-thumbnail img-responsive">
						<div class="chat-info">
						</div>
						<div style="clear:both;"></div>
					</div>
					<div class="chat-history">
						<ul class="user-messages">
							
						</ul>
					</div>
					<div class="chat-footer">
						<textarea id="messages" class="form-control" placeholder="Type your message" rows="3" style="margin-bottom: 10px;"></textarea>
						<div class="pull-right">
							<button class="btn btn-primary">Send</button>
						</div>
						<div style="clear:both;"></div>
					</div>
				</div>
			</div>
		</div>
		<style type="text/css">
		.chat-container{height: 900px; background: #2c3e50;}
		.chat-heading { height: 99px; background: #eee; padding: 20px; position: absolute; margin: -15px; top: 15px; left: 0; right: 0; z-index: 1; }
		.chat-heading img{float: left;height: 100%;}
		.chat-info{margin-top: 10px; margin-left: 20px; display: block; float: left;}
		.chat-history { padding: 0px; padding-top: 112px!important; border-bottom: 2px solid white; overflow-y: scroll; margin: -15px; margin-top: 0px; height: 728px; background: #E6EAEA; }
		.chat-footer { background: #eee; margin: -15px; padding: 15px; margin-top: 15px; }
		.user-messages li p {display: inline-block; padding: 10px 15px; border-radius: 20px; max-width: 205px; line-height: 130%; background: #2c3e50; color: #fff;}
		.user-messages li img { width: 37px; border-radius: 50%; float: left; }
		.user-messages li { display: inline-block; clear: both; float: left; margin: 0 0 5px 0; width: calc(100% - 25px); font-size: 0.9em; }
		.user-messages li.replies img { width: 37px; border-radius: 50%; float: right; }
		.user-messages li.sent p {margin-left:10px;}
		.user-messages li.replies p {float: right; margin-right: 10px; background: #fff; color: #2c3e50;}
		@media screen and (min-width: 768px) {
			.user-messages li p {
				max-width: 300px;
			}
		}
		
		.search {padding: 10px; margin: -15px; margin-top: 0px; margin-bottom: 0px; background: #1b2631;}
		
		
		@media (min-width: 769px) {
			.people-list { height: 835px; overflow-y: scroll; margin: -15px; margin-top: 0; padding: 10px;}
			.people-info {
				height: 77px;
				padding: 11px;
				color: #fff;
			}
			.people-info img {
				height: 100%;
				float: left;
			}
			.people-info p { margin-left: 13px; margin-top: 10px; display: inline-block; }	
		}
		@media (max-width: 768px)  {
			.people-list { height: 120px; overflow-x: scroll; overflow-y: hidden; white-space: nowrap; margin: -15px; margin-bottom: 0px; margin-top: 0px; }
			.people-info { display: inline-block; height: inherit; padding: 12px 22px; }
			.people-info img { height: 74%; display: block; }
			.people-info p { color: white; text-align: center; margin-top: 6px; font-size: 14px; word-break: break-word; }
		}
		</style>
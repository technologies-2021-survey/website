<?php $this->load->view('Doctor/Doctor_navigation'); ?>

    <h2>View Immunization Record / <?php echo $patient_name;?></h2>
    <?php
        echo '<a href="'.base_url().'doctor/addImmunizationRecord/'.$patient_id.'" class="btn btn-success">Add Immunization Record</a>';
    ?>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Vaccine</th>
                <th>Route</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach($viewImmunizationRecords as $row) {
                echo '<tr class="viewImmunizationRecords-'.$row['immunization_record_id'].'">';
                    echo '<td>'.$i++.'</td>';
                    echo '<td>'.$row['date'].'</td>';
                    echo '<td>'.$row['vaccine'].'</td>';
                    echo '<td>'.$row['route'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().'doctor/editImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-warning" style="margin-right:10px;">Edit</a>';
                        echo '<a href="'.base_url().'doctor/deleteImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-danger">Delete</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
    <?php echo $links; ?>

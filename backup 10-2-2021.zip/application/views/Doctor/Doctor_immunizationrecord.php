<?php $this->load->view('Doctor/Doctor_navigation'); ?>

    <h2>Immunization Record</h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Patient Name</th>
                <th>Date</th>
                <th>Vaccine</th>
                <th>Route</th>
                <th>Parent Name</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($immunizationrecords as $row) {
                echo '<tr class="immunization_record-'.$row['immunization_record_id'].'">';
                    echo '<td>'.$row['immunization_record_id'].'</td>';
                    echo '<td>'.$row['patient_name'].'</td>';
                    echo '<td>'.$row['date'].'</td>';
                    echo '<td>'.$row['vaccine'].'</td>';
                    echo '<td>'.$row['route'].'</td>';
                    echo '<td>'.$row['parent_name'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().'doctor/viewImmunizationRecord/'.$row['patient_id'].'" class="btn btn-info" style="margin-right:10px;">View</a>';
                        echo '<a href="'.base_url().'doctor/editImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-warning" style="margin-right:10px;">Edit</a>';
                        echo '<a href="'.base_url().'doctor/deleteImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-danger">Delete</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
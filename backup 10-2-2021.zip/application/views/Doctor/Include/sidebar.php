<div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
    <ul class="list-group panel">
        <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>SIDE PANEL</b></li>
        <li class="list-group-item"><a href="./index"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
        <li>
            <a href="#sidebar" class="list-group-item " data-toggle="collapse">Menu  <span class="glyphicon glyphicon-chevron-right"></span></a>
        </li>
        <li class="collapse" id="sidebar">
            <a href="<?=base_url('/doctor/inquiries_list');?>"  class="list-group-item">Inquiries List</a>
            <a href="<?=base_url('/doctor/appointment');?>"  class="list-group-item">Appointment</a>
            <a href="<?=base_url('/doctor/payment');?>"  class="list-group-item">Payment</a>
            <a href="<?=base_url('/doctor/consultation');?>"  class="list-group-item">Consultation</a>
            <a href="<?=base_url('/doctor/transaction');?>"  class="list-group-item">Transaction</a>
            <a href="<?=base_url('/doctor/immunizationrecord');?>"  class="list-group-item">Immunization Record</a>
            <a href="<?=base_url('/doctor/parents');?>"  class="list-group-item">Parent List</a>
            <a href="<?=base_url('/doctor/patients');?>" class="list-group-item">Patient List</a>
        </li>
    </ul>
</div>
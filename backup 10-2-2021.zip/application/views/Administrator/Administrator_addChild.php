<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    <h2><?php echo $parent_name; ?> | Add Child</h2>

    <form action="<?php echo base_url(); ?>administrator/addChild/<?php echo $this->uri->segment(3); ?>" method="POST">
        <div class="form-group">
            <label>Patient Name</label>
            <input type="text" name="patient_name" class="form-control">
        </div>
        <div class="form-group">
            <label>Patient Gender</label>
            <select name="patient_gender" class="form-control">
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="form-group">
            <label>Patient Birthdate</label>
            <input type="date" name="patient_birthdate" class="form-control">
        </div>
        <div class="pull-right">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
        </div>
        <div style="clear:both;"></div>
    </form>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title><?=$title;?></title>
		<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="<?=base_url('dist/css/site.min.css');?>">
		<link rel="stylesheet" href="<?=base_url('assets/css/style.css');?>" media="screen">
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="../bower_components/html5shiv/dist/html5shiv.js"></script>
			<script src="../bower_components/respond/dest/respond.min.js"></script>
		<![endif]-->
		<script type="text/javascript" src="<?=base_url('assets/js/jquery-1.10.2.min.js');?>"></script>
		<script type="text/javascript" src="<?=base_url('assets/js/jquery-ui.min.js');?>"></script>
		<script type="text/javascript" src="<?=base_url('dist/js/site.min.js');?>"></script>
		<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		<style type="text/css">.modal-body{padding-bottom: 15px;}.navbar-default .btn-link, .navbar-default .navbar-brand, .navbar-default .navbar-link,.navbar-default .navbar-nav>li>a, .navbar-default .navbar-text{color:#fff;}</style>
	</head>
	<body>
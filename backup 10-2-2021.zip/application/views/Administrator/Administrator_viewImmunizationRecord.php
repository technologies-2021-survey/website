<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    <h2>View Immunization Record / <?php echo $patient_name;?></h2>
    <?php
        echo '<a href="'.base_url().'administrator/addImmunizationRecord/'.$patient_id.'" class="btn btn-success">Add Immunization Record</a>';
    ?>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Vaccine</th>
                <th>Route</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach($viewImmunizationRecords as $row) {
                echo '<tr class="viewImmunizationRecords-'.$row['immunization_record_id'].'">';
                    echo '<td>'.$i++.'</td>';
                    echo '<td>'.$row['date'].'</td>';
                    echo '<td>'.$row['vaccine'].'</td>';
                    echo '<td>'.$row['route'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().'administrator/editImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-warning" style="margin-right:10px;">Edit</a>';
                        echo '<a href="'.base_url().'administrator/deleteImmunizationRecord/'.$row['immunization_record_id'].'" class="btn btn-danger">Delete</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
    <?php echo $links; ?>

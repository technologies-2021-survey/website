<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    <h2>Parent List</h2>
    <div class="pull-right">
        <a href="<?php echo base_url(); ?>/administrator/addParents" class="btn btn-primary">Add Parent</a>
    </div>
    <div style="clear:both;"></div>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Parent Name</th>
                <th>Username</th>
                <th>Phone Number</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach($parents as $row) {
                echo '<tr class="parents-'.$row['parent_id'].'">';
                    echo '<td>'.$row['parent_id'].'</td>';
                    echo '<td>'.$row['parent_name'].'</td>';
                    echo '<td>'.$row['parent_username'].'</td>';
                    echo '<td>'.$row['parent_phonenumber'].'</td>';
                    echo '<td>';
                        echo '<a href="'.base_url().'administrator/addChild/'.$row['parent_id'].'" class="btn btn-success" style="margin-right:10px;">Add Child</a>';
                        echo '<a href="'.base_url().'administrator/listChild/'.$row['parent_id'].'" class="btn btn-info">Child List</a>';
                    echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    <h2>Transaction</h2>
    <?php
        foreach($transactions as $row) {
            echo '<div class="transaction-'.$row['transaction_id'].'">';
                    echo '<div class="transaction-heading" style="padding: 10px;box-shadow: 0 0 2px #000 inset;">';
                        echo $row['parent_name'];
                        echo '<div style="clear:both;"></div>';
                    echo '</div>';
                    echo '<div class="transaction-body"  style="background: rgb(244 244 244);display: none;word-break:break-all;height: 600px;overflow-y: scroll; padding: 20px;">';
                        echo 'Parent Name:<br/>';
                        echo $row['parent_name'];
                        echo '<br/><br/>';
                        echo 'Patient Name:<br/>';
                        echo $row['patient_name'];
                        echo '<br/><br/>';
                        echo 'Date Consultation:<br/>';
                        echo date('m d Y h:iA', $row['date_consultation']);
                        echo '<br/><br/>';
                        echo 'Proof of Transaction:<br/>';
                        echo '<img src="data:image/png;base64,'.base64_encode($row['consultation_proof_of_transaction']).'" class="pot" style="display:block;width: 100px;margin-bottom: 20px;"/>';
                        echo '<br/><br/>';
                        echo 'Status:<br/>';
                        echo $row['status'];
                    echo '</div>';
            echo '</div>';
        }
    ?>

    <script type="text/javascript">
    $(document).ready(function() {

        $('.transaction-heading').click(function() {
            $(this).siblings(".transaction-body").slideToggle();
            console.log(0);    
        });
        $('.pot').click(function() {
            $('#viewModal').modal('show');
            var image = $(this).attr("src");
            $("#POT").attr("src", image);
        });
    });
    </script>
    <!-- Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">Proof of Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="#" id="POT">
                </div>
            </div>
        </div>
    </div>
<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    
    <div class="search">

        <?php 
            $array = array();

            function check($id, $selection, $arrays) {
                $status = '';
                for($i = 0; $i < count($arrays); $i++) {
                    if($arrays[$i]['id'] == $id && $arrays[$i]['selection'] == $selection) {
                        $status = 'exist';
                        break;
                    }
                }
                return $status;
            }

            foreach($accessprivileges as $row) {
                if(check($row['doctor_id'], '1', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['doctor_id'],
                        'selection' => '1'
                    );
                }
                if(check($row['receptionist_id'], '2', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['receptionist_id'],
                        'selection' => '2'
                    );
                }
                if(check($row['admin_id'], '3', $array) == "exist") {
                } else {
                    $array[] = array(
                        'id' => $row['admin_id'],
                        'selection' => '3'
                    );
                }
            }
            echo '<hr/>';
            foreach($array as $display) {
                echo $display['id'];
                echo '<br/>';
                echo $display['selection'];
                echo '<hr>';
            }
            echo $links;
        ?>
<?php $this->load->view('Administrator/Administrator_navigation'); ?>

    
    <div class="search">
        <form id="search">
            <div class="form-group">
                <input type="text" name="search" id="search" class="form-control" />
            </div>
        </form>

        <?php 
            foreach($consultations as $row) {
                echo '<div class="consultation-'.$row['consultation_id'].'">';
                    echo '<div class="consultation-heading" style="padding: 10px;box-shadow: 0 0 2px #000 inset;">';
                        echo $row['parent_name'];
                        echo '<div class="pull-right">';
                            echo $row['consultation_status'];
                        echo '</div>';
                        echo '<div style="clear:both;"></div>';
                    echo '</div>';
                    echo '<div class="consultation-body" style="background: rgb(244 244 244);display: none;word-break:break-all;height: 600px;overflow-y: scroll; padding: 20px;">';
                        echo 'Parent Name:<br/>';
                        echo $row['parent_name'];
                        echo '<br/><br/>';

                        echo 'Patient Name:<br/>';
                        echo $row['patient_name'];
                        echo '<br/><br/>';

                        echo 'Date Consultation:<br/>';
                        echo date('m d Y h:iA', $row['date_consultation']);
                        echo '<br/><br/>';

                        echo 'Reason:<br/>';
                        echo $row['reason'];
                        echo '<br/><br/>';
                    
                        echo 'Proof of Transaction:<br/>';
                        echo '<img src="data:image/png;base64,'.base64_encode($row['consultation_proof_of_transaction']).'" class="pot" style="display:block;width: 100px;margin-bottom: 20px;"/>';
                        
                        if($row['consultation_prescription'] != "") {
                            echo 'Prescriptions:<br/>';
                            echo $row['consultation_prescription'];
                        }
                        if($row['consultation_status'] == "Approved" || $row['consultation_status'] == "Cancelled") {
                            
                        } else {
                            echo '<hr/>';

                            echo '<form action="'.base_url().'administrator/sendlink" method="POST" style="margin-bottom: 20px;">';
                                echo '<input type="hidden" name="id" value="'.$row['consultation_id'].'">';
                                echo '<div class="form-group">';
                                    echo '<label>Google Link</label>';
                                    echo '<div class="input-group">';
                                        echo '<input type="text" name="googlelink" value="'.$row['googlelink'].'" class="form-control" placeholder="https://meet.google.com/......">';
                                        echo '<div class="input-group-btn">';
                                            echo '<span class="input-group-btn">';
                                                echo '<button class="btn btn-success" type="submit" name="submit">Send!</button>';
                                            echo '</span>';
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            echo '</form>';

                            echo '<div class="row">';
                                echo '<div class="col-md-4">';
                                    echo '<button id="addPrescription" data-id="'.$row['consultation_id'].'" class="btn btn-success btn-block">Add Prescription</button>';
                                echo '</div>';
                                echo '<div class="col-md-4">';
                                    echo '<a href="'.base_url().'administrator/cancelConsultation/'.$row['consultation_id'].'"><button class="btn btn-success btn-block">Cancel Consultation</button></a>';
                                echo '</div>';
                                echo '<div class="col-md-4">';
                                    echo '<a href="'.base_url().'administrator/doneConsultation/'.$row['consultation_id'].'"><button id="donePrescription" data-id="'.$row['consultation_id'].'" class="btn btn-success btn-block">Done Consultation</button></a>';
                                echo '</div>';
                            echo '</div>';
                        }
                    echo '</div>';
                echo '</div>';
            }

            echo $links;
        ?>
        <script type="text/javascript">
            $(document).ready(function() {

                $('.consultation-heading').click(function() {
                    $(this).siblings(".consultation-body").slideToggle();
                    console.log(0);    
                });

                $('.pot').click(function() {
                    $('#viewModal').modal('show');
                    var image = $(this).attr("src");
                    $("#POT").attr("src", image);
                });

                $('#addPrescription').click(function() {
                    var hid = $(this).attr("data-id");
                    $('input[name=prescription_id]').attr("value", hid);
                    $('#addPrescriptionModal').modal('show');
                });
            });
        </script>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">Proof of Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="#" id="POT">
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addPrescriptionModal" tabindex="-1" role="dialog" aria-labelledby="addPrescriptionModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPrescriptionModalLabel">Add Prescription</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url(); ?>administrator/addPrescription" method="POST">
                        <input type="hidden" name="prescription_id">
                        <div class="form-group">
                            <label>Add Prescription</label>
                            <textarea class="form-control" name="prescription" style="height: 200px;margin-bottom: 10px;"></textarea>
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php

class Login_model extends CI_Model {
    public function itexmo($number, $message){
		$ch = curl_init();
		$itexmo = array('1' => $number, '2' => $message, '3' => 'TR-FEUIN429327_D4FAD', 'passwd' => '}q3%u2p4ur');
		curl_setopt($ch, CURLOPT_URL,"https://www.itexmo.com/php_api/api.php");
		curl_setopt($ch, CURLOPT_POST, 1);
		 curl_setopt($ch, CURLOPT_POSTFIELDS, 
		          http_build_query($itexmo));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		return curl_exec ($ch);
		curl_close ($ch);
    }
    public function setOTP($id, $selection, $otp) {
        if($selection == "doctor") {
            $this->db->where('doctor_id', $id);
    		$this->db->set('doctor_sms_code', $otp);
    		$this->db->update('doctors_tbl');
        } else if($selection == "receptionist") {
            $this->db->where('receptionist_id', $id);
    		$this->db->set('receptionist_sms_code', $otp);
    		$this->db->update('receptionists_tbl');
        } else if($selection == "administrator") {
            $this->db->where('admin_id', $id);
    		$this->db->set('admin_sms_code', $otp);
    		$this->db->update('admins_tbl');
        }
    }
	public function can_login($user_name, $password, $selection) {
		if($selection == "doctor") {
			$this->db->where('doctor_username', $user_name);
			$query = $this->db->get('doctors_tbl');

			if($query->num_rows() > 0) {
				// success
				foreach($query->result() as $row) { // row of this data
					if($row->doctor_password == md5($password)) {
					    $otp = rand(000000,999999);
					    $copyOtp = $otp;
					    //$this->login_model->itexmo($row->doctor_phonenumber, $copyOtp . ' is your OTP. Please enter this to confirm your login.');
					    $this->login_model->setOTP($row->doctor_id, 'doctor', $copyOtp);
						$this->session->set_userdata('id', $row->doctor_id); // setup session
						$this->session->set_userdata('selection', $selection); // setup session
						return '';
					} else {
						return 'WrongPassword';
					}
				}
			} else {
				// error
				return 'ReturnUsername';
			}
		} else if($selection == "receptionist") {
			$this->db->where('receptionist_username', $user_name);
			$query = $this->db->get('receptionists_tbl');

			if($query->num_rows() > 0) {
				// success
				foreach($query->result() as $row) { // row of this data
					if($row->receptionist_password == md5($password)) {
					    $otp = rand(000000,999999);
					    $copyOtp = $otp;
					    //$this->login_model->itexmo($row->receptionist_phonenumber, $copyOtp . ' is your OTP. Please enter this to confirm your login.');
					    $this->login_model->setOTP($row->receptionist_id, 'receptionist', $copyOtp);
						$this->session->set_userdata('id', $row->receptionist_id); // setup session
						$this->session->set_userdata('selection', $selection); // setup session
						return '';
					} else {
						return 'WrongPassword';
					}
				}
			} else {
				// error
				return 'ReturnUsername';
			}
		} else if($selection == "administrator") {
			$this->db->where('admin_username', $user_name);
			$query = $this->db->get('admins_tbl');

			if($query->num_rows() > 0) {
				// success
				foreach($query->result() as $row) { // row of this data
					if($row->admin_password == md5($password)) {
						$otp = rand(000000,999999);
					    $copyOtp = $otp;
					    //$this->login_model->itexmo($row->admin_phonenumber, $copyOtp . ' is your OTP. Please enter this to confirm your login.');
					    $this->login_model->setOTP($row->admin_id, 'administrator', $copyOtp);
						$this->session->set_userdata('id', $row->admin_id); // setup session
						$this->session->set_userdata('selection', $selection); // setup session
						return '';
					} else {
						return 'WrongPassword';
					}
				}
			} else {
				// error
				return 'ReturnUsername';
			}
		} else {
			redirect("home");
		}
		
	}
}

?>
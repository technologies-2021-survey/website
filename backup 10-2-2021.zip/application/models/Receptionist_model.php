<?php
class Receptionist_model extends CI_Model {
    
    public function submitOTP($id, $otp) {
        $this->db->where('receptionist_id', $id);
	    $query = $this->db->get('receptionists_tbl');
	    if($query->num_rows() > 0) {
			// success
			foreach($query->result() as $row) { // row of this data
			    if($row->receptionist_sms_code == $otp) {
			        $this->db->where('receptionist_id', $row->receptionist_id);
            		$this->db->set('receptionist_sms_code', "@@@@@@@@SUCCESS@@@@@@@@");
            		$this->db->update('receptionists_tbl');
			        return 'successfully';
				} else {
					return 'otpNotSame';
				}
			}
	    } else {
	       	// error
			return 'userNotExists';
	    }
    }
    public function modelLogout($id) {
        $this->db->where('receptionist_id', $id);
		$this->db->set('receptionist_sms_code', "@@@@@@@@EXIT@@@@@@@@");
		$this->db->update('receptionists_tbl');
    }
	public function getId($id) {
		$q = $this->db->query("SELECT * FROM `receptionists_tbl` WHERE `receptionist_id` = '".$id."'"); 
		return $q->result();
	}
	
	// password
	public function getPassword($id) {
		$q = $this->db->query("SELECT * FROM `receptionist_tbl` WHERE `receptionist_id` = '".$id."'"); 
		return $q->result();
	}
	public function change_password($id, $oldpassword, $newpassword, $retypenewpassword) {
		$this->db->where('receptionist_id', $id);
		$query = $this->db->get('receptionists_tbl');

		if($query->num_rows() > 0) {
			// success
			foreach($query->result() as $row) { // row of this data
				if($row->receptionist_password == $oldpassword) {
					if($newpassword == $retypenewpassword) {
						$this->db->where('receptionist_id', $id);
	    				$this->db->set('receptionist_password', $newpassword);
						$this->db->update('receptionists_tbl');
						return '';
					} else {
						return 'crNotSame';
					}
				} else {
					return 'passNotSame';
				}
			}
		} else {
			// error
			return 'userNotExists';
		}

	}

	// inquiries
	public function getInquiries() {
		$q = $this->db->query("SELECT * FROM `inquiries_tbl`"); 
		//
		// OR
		// $this->db->select('Inquiries_ID,Inquiries_title, Inquiries_body, Inquiries_Name, Inquiries_EmailAddress, Inquiries_PhoneNumber, Inquiries_DateTime');
		// $this->db->from("Inquiries_tbl"); 
		// $this->order_by('Inquiries_ID', DESC);
		// $q = $this->db->get(); 
		// this sql query will be "SELECT Inquiries_ID,Inquiries_title, Inquiries_body, Inquiries_Name, Inquiries_EmailAddress, Inquiries_PhoneNumber, Inquiries_DateTime FROM `Inquiries_tbl` ORDER BY `Inquiries_ID` DESC"
		//
		// OR
		// $this->db->select('Inquiries_ID,Inquiries_title, Inquiries_body, Inquiries_Name, Inquiries_EmailAddress, Inquiries_PhoneNumber, Inquiries_DateTime');
		// $q = $this->db->get("Inquiries_tbl");
		// this sql query will be "SELECT Inquiries_ID,Inquiries_title, Inquiries_body, Inquiries_Name, Inquiries_EmailAddress, Inquiries_PhoneNumber, Inquiries_DateTime FROM Inquiries_tbl"


		// you must add a code in application/config/autoload.php and also the code will be: autoload['libraries'] = array('database');
		// you must setup your database in application/config/database.php
		return $q->result();
	}
	public function getInquiriesById($param) {
	    $q = $this->db->query("SELECT * FROM `inquiries_tbl` WHERE Inquiries_ID = '".$param."'"); 
		//$q = $this->db->query("SELECT * FROM `inquiries_tbl` WHERE Inquiries_ID = '".$param."'"); 
		// for controllers:
		// $id = $this->uri->segment(3);
		// $this->home_model->getInquiriesById('Inquiries_tbl','Inquiries_ID', $id);
		return $q->result();
	}
	public function deleteInquiries($id) {
		$this->db->where('inquiries_id', $id);
		$this->db->delete('inquiries_tbl');
	}
	
	// chats
	public function send($array) {
		$this->db->insert('chats_history_tbl', $array);
	}
	
	/*
		public function getChats($id, $code) {

			$q = $this->db->query("SELECT * FROM `chats_history_tbl` WHERE `chats_history_id` > '".$id."' AND `chats_info_code` = '".$code."' ORDER BY `chats_history_id` DESC LIMIT 10");		
			$arr = array();
			// success
			foreach($q->result_array() as $row) { 
				//1-doctor
				//2-admin
				//3-receptionist
				//4-parent 
				$getInfo = "";
				if($row['chats_account_type'] == 1) {
					$getts = $this->receptionist_model->getUserInfoDoctor($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['doctor_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 2) {
					$getts = $this->receptionist_model->getUserInfoAdmin($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['admin_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 3) {
					$getts = $this->receptionist_model->getUserInfoReceptionist($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['receptionist_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 4) {
					$getts = $this->receptionist_model->getUserInfoParent($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['parent_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				}
				
				$text = "";
				if($row['chats_account_type'] == 1) { $text = "Doctor"; } 
				else if($row['chats_account_type'] == 2) { $text = "Administrator"; }
				else if($row['chats_account_type'] == 3) { $text = "Receptionist"; }
				else if($row['chats_account_type'] == 4) { $text = "Parent"; }

				$newRow = array(
					'chats_history_id' => (int) $row['chats_history_id'],

					'full_name' => $getInfo['full_name'],
					'active' => $getInfo['active'],
					'profile_picture' => $getInfo['profile_picture'],
					
					'chats_account_type_text' => $text,
					'chats_id' => (int) $row['chats_id'],

					'chats_message' => $row['chats_message'],
					'time' => date('m-d-Y h:i:sA', $row['time']),
					'timestamp' => $row['time']
				);
				$arr[] = $newRow;
			}
			
			$newArr = array("chats" => $arr);
			return json_encode($newArr);
		}
		public function getPreviouslyChats($id, $myid, $selection, $user_id2, $selection2) {
			$minusId = $id-9;
			$q = $this->db->query("SELECT * FROM `chats_history_tbl` WHERE (`chats_history_id` >= '".$minusId."' AND `chats_history_id` <= '".$id."') AND (`chats_account_type` = '".$selection."', `chats_id` = '".$myid."', `chats_to_account_type` = '".$selection2."', `chats_to` = '".$user_id2."') ORDER BY `chats_history_id` DESC LIMIT 10");	
			$arr = array(); 
			// success
			foreach($q->result_array() as $row) { 
				//1-doctor
				//2-admin
				//3-receptionist
				//4-parent
				$getInfo = "";
				if($row['chats_account_type'] == 1) {
					$getts = $this->receptionist_model->getUserInfoDoctor($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['doctor_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 2) {
					$getts = $this->receptionist_model->getUserInfoAdmin($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['admin_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 3) {
					$getts = $this->receptionist_model->getUserInfoReceptionist($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['receptionist_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				} else if($row['chats_account_type'] == 4) {
					$getts = $this->receptionist_model->getUserInfoParent($row['chats_id']);
					foreach($getts as $getData) {
						$getInfo = array(
							'full_name' => $getData['parent_name'],
							'active' => $getData['active'],
							'profile_picture' => $getData['profile_picture']
						);
					} 
				}
				$text = "";
				if($row['chats_account_type'] == 1) { $text = "Doctor"; } 
				else if($row['chats_account_type'] == 2) { $text = "Administrator"; }
				else if($row['chats_account_type'] == 3) { $text = "Receptionist"; }
				else if($row['chats_account_type'] == 4) { $text = "DoParentctor"; }
				
				$newRow = array(
					'chats_history_id' => (int) $row['chats_history_id'],
					'chats_account_type_text' => $text,
					'full_name' => $getInfo['full_name'],
					'active' => $getInfo['active'],
					'profile_picture' => $getInfo['profile_picture'],
					'chats_id' => (int) $row['chats_id'],
					'chats_to' => (int) $row['chats_to'],
					'chats_message' => $row['chats_message'],
					'time' => date('m-d-Y h:i:sA', $row['time']),
					'timestamp' => $row['time']
				);
				$arr[] = $newRow;
			}
			
			$newArr = array("chats" => $arr);
			return json_encode($newArr);
		}
	*/
	public function getChats($code, $id) {
		$q = $this->db->query("SELECT * FROM `chats_history_tbl` WHERE `chats_history_id` > '".$id."' AND `chats_info_code` = '".$code."' ORDER BY `chats_history_id` DESC LIMIT 10");		
		$arr = array();
		// success
		foreach($q->result_array() as $row) { 
			//1-doctor
			//2-admin
			//3-receptionist
			//4-parent 
			$getInfo = "";
			if($row['chats_account_type'] == 1) {
				$getts = $this->receptionist_model->getUserInfoDoctor($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['doctor_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 2) {
				$getts = $this->receptionist_model->getUserInfoAdmin($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['admin_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 3) {
				$getts = $this->receptionist_model->getUserInfoReceptionist($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['receptionist_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 4) {
				$getts = $this->receptionist_model->getUserInfoParent($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['parent_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			}
			
			$text = "";
			if($row['chats_account_type'] == 1) { $text = "Doctor"; } 
			else if($row['chats_account_type'] == 2) { $text = "Administrator"; }
			else if($row['chats_account_type'] == 3) { $text = "Receptionist"; }
			else if($row['chats_account_type'] == 4) { $text = "Parent"; }

			$newRow = array(
				'chats_history_id' => (int) $row['chats_history_id'],
				'chats_info_code' => (int) $row['chats_info_code'],

				'full_name' => $getInfo['full_name'],
				'active' => $getInfo['active'],
				'profile_picture' => $getInfo['profile_picture'],
				
				'chats_account_type_text' => $text,
				'chats_id' => (int) $row['chats_id'],

				'chats_message' => $row['chats_message'],
				'time' => date('m-d-Y h:i:sA', $row['time']),
				'timestamp' => $row['time']
			);
			$arr[] = $newRow;
		}
		
		$newArr = array("chats" => $arr);
		return json_encode($newArr);
	}
	public function getPreviouslyChats($code, $id) {
		$minusId = $id - 10;
		
		$q = $this->db->query("SELECT * FROM `chats_history_tbl` WHERE (`chats_history_id` >= '".$minusId."' AND `chats_history_id` <= '".$id."') AND `chats_info_code` = '".$code."' ORDER BY `chats_history_id` DESC LIMIT 10");
		$arr = array();
		// success
		foreach($q->result_array() as $row) { 
			//1-doctor
			//2-admin
			//3-receptionist
			//4-parent 
			$getInfo = "";
			if($row['chats_account_type'] == 1) {
				$getts = $this->receptionist_model->getUserInfoDoctor($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['doctor_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 2) {
				$getts = $this->receptionist_model->getUserInfoAdmin($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['admin_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 3) {
				$getts = $this->receptionist_model->getUserInfoReceptionist($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['receptionist_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			} else if($row['chats_account_type'] == 4) {
				$getts = $this->receptionist_model->getUserInfoParent($row['chats_id']);
				foreach($getts as $getData) {
					$getInfo = array(
						'full_name' => $getData['parent_name'],
						'active' => $getData['active'],
						'profile_picture' => $getData['profile_picture']
					);
				} 
			}
			
			$text = "";
			if($row['chats_account_type'] == 1) { $text = "Doctor"; } 
			else if($row['chats_account_type'] == 2) { $text = "Administrator"; }
			else if($row['chats_account_type'] == 3) { $text = "Receptionist"; }
			else if($row['chats_account_type'] == 4) { $text = "Parent"; }

			$newRow = array(
				'chats_history_id' => (int) $row['chats_history_id'],
				'chats_info_code' => (int) $row['chats_info_code'],

				'full_name' => $getInfo['full_name'],
				'active' => $getInfo['active'],
				'profile_picture' => $getInfo['profile_picture'],
				
				'chats_account_type_text' => $text,
				'chats_id' => (int) $row['chats_id'],

				'chats_message' => $row['chats_message'],
				'time' => date('m-d-Y h:i:sA', $row['time']),
				'timestamp' => $row['time']
			);
			$arr[] = $newRow;
		}
		
		$newArr = array("chats" => $arr);
		return json_encode($newArr);
	}
	public function getLastChatId($code) {
		$q = $this->db->query("SELECT * FROM `chats_history_tbl` WHERE `chats_info_code` = '".$code."' ORDER BY `chats_history_id` DESC LIMIT 1"); 
		if($q->num_rows() > 0) {
			// success
			foreach($q->result() as $row) { // row of this data
				return $row->chats_history_id;
			}
		}
	}
	public function checkChatCode($id, $selection, $code) {
		//1-doctor
		//2-admin
		//3-receptionist
		//4-parent
		$q = $this->db->query("SELECT * FROM `chats_info_tbl` WHERE `chats_id` = '".$id."' AND `chats_selection` = '".$selection."' AND `code` = '".$code."'"); 
		if($q->num_rows() > 0) {
			return '1';
		} else {
			return '0';
		}
		
	}
	public function getNameandActives($code, $id) {
		$q = $this->db->query("SELECT * FROM `chats_info_tbl` WHERE `chats_id` = '".$id."' AND `code` = '".$code."'"); 
		if($q->num_rows() > 0) {
			// success
			$id_to = "";
			$selection_to = "";
			foreach($q->result() as $row) { // row of this data
				$id_to = $row->id_to;
				$selection_to = $row->selection_to;
			}
			if($selection_to == 1) {
				$result = $this->receptionist_model->getUserInfoDoctor($id_to);
				$array = "";
				foreach($result as $getData) {
					$array = array(
						'full_name' => $getData['doctor_name'],
						'active' => $getData['active']
					);
				}
				return json_encode($array);
			} else if($selection_to == 2) {
				$result = $this->receptionist_model->getUserInfoAdmin($id_to);
				$array = "";
				foreach($result as $getData) {
					$array = array(
						'full_name' => $getData['admin_name'],
						'active' => $getData['active']
					);
				}
				return json_encode($array);
			} else if($selection_to == 3) {
				$result = $this->receptionist_model->getUserInfoReceptionist($id_to);
				$array = "";
				foreach($result as $getData) {
					$array = array(
						'full_name' => $getData['receptionist_name'],
						'active' => $getData['active']
					);
				}
				return json_encode($array);
			} else if($selection_to == 4) {
				$result = $this->receptionist_model->getUserInfoParent($id_to);
				$array = "";
				foreach($result as $getData) {
					$array = array(
						'full_name' => $getData['parent_name'],
						'active' => $getData['active']
					);
				}
				return json_encode($array);
			}
		}
	}

	// check id
	public function getUserInfoDoctor($id) {
		$q = $this->db->query("SELECT * FROM `doctors_tbl` WHERE `doctor_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function getUserInfoAdmin($id) {
		$q = $this->db->query("SELECT * FROM `admins_tbl` WHERE `admin_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function getUserInfoReceptionist($id) {
		$q = $this->db->query("SELECT * FROM `receptionists_tbl` WHERE `receptionist_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function getUserInfoParent($id) {
		$q = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function getUserInfoPatient($id) {
		$q = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function getUserInfoParentName($id) {
		$q = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$id."'"); 
		foreach($q->result() as $row) { 
			return $row->parent_name;
		}
	}
	public function getUserInfoPatientName($id) {
		$q = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$id."'"); 
		foreach($q->result() as $row) { 
			return $row->patient_name;
		}
	}
	public function getUserInfoPatientGetParentName($id) {
		$q = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$id."'"); 
		foreach($q->result() as $row) { 
			$qw = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$row->parent_id."'"); 
			foreach($qw->result() as $row2) { 
				return $row2->parent_name;
			}
		}
	}
	public function getUserInfoPatientGetParentId($id) {
		$q = $this->db->query("SELECT * FROM `patients_tbl` WHERE `patient_id` = '".$id."'"); 
		foreach($q->result() as $row) { 
			$qw = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$row->parent_id."'"); 
			foreach($qw->result() as $row2) { 
				return $row2->parent_id;
			}
		}
	}
	public function getConsultationInfo($id) {
		$q = $this->db->query("SELECT * FROM `consultations` WHERE `consultation_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function checkAccount($id, $selection) {
		//1-doctor
		//2-admin
		//3-receptionist
		//4-parent
		if($selection == "doctor") {
			$q = $this->db->query("SELECT * FROM `doctors_tbl` WHERE `doctor_id` = '".$id."'"); 
			if($q->num_rows() > 0) {
				return '1';
			} else {
				return '0';
			}
		} else if($selection == "administrator") {
			$q = $this->db->query("SELECT * FROM `admins_tbl` WHERE `admin_id` = '".$id."'"); 
			if($q->num_rows() > 0) {
				return '1';
			} else {
				return '0';
			}
		} else if($selection == "receptionist") {
			$q = $this->db->query("SELECT * FROM `receptionists_tbl` WHERE `receptionist_id` = '".$id."'"); 
			if($q->num_rows() > 0) {
				return '1';
			} else {
				return '0';
			}
		} else if($selection == "parent") {
			$q = $this->db->query("SELECT * FROM `parents_tbl` WHERE `parent_id` = '".$id."'"); 
			if($q->num_rows() > 0) {
				return '1';
			} else {
				return '0';
			}
		} 
		
	}

	// appointment
	public function getAppointment(){
		$this->db->order_by('appointment_id');
		return $this->db->get('appointments');
	}
	  
	public function addAppointment($data) {
		$this->db->insert('appointments', $data);
	}
	  
	public function updateAppointment($data, $id) {
		$this->db->where('id', $id);
		$this->db->update('appointments', $data);
	}
	  
	public function deleteAppointment($id) {
		$this->db->where('id', $id);
		$this->db->delete('appointments');
	}

	public function getCheckTimeAppointment($start, $end) {
		$q = $this->db->query("SELECT * FROM `appointments` WHERE `appointment_timestamp` = '".$start."' AND `appointment_timestamp_end` = '".$end."' ORDER BY `appointment_id` DESC LIMIT 1"); 
		if($q->num_rows() > 0) {
			return 1;
		}
	}

	//consultation
	public function get_consultations_count() {
        return $this->db->count_all("consultations");
    }

    public function get_consultations($limit, $start) {
        $this->db->limit($limit, $start);
		$q = $this->db->get("consultations");
		$array = array();

		foreach($q->result_array() as $row) {

			$result = $this->receptionist_model->getUserInfoParent($row['consultation_parent_id']);
			$result2 = $this->receptionist_model->getUserInfoPatient($row['consultation_patient_id']);

			$getInfo = (array) $result;
			$getInfo2 = (array) $result2;
			$newRow = array(
				'consultation_id' => (int) $row['consultation_id'],
				'consultation_parent_id' => (int) $row['consultation_parent_id'],
				'consultation_patient_id' => (int) $row['consultation_patient_id'],
				'parent_name' => $getInfo[0]['parent_name'],
				'patient_name' => $getInfo2[0]['patient_name'],
				'date_consultation' => $row['date_consultation'],
				'googlelink' => $row['googlelink'],
				'reason' => $row['reason'],
				'transaction_id' => $row['transaction_id'],
				'consultation_proof_of_transaction' => $row['consultation_proof_of_transaction'],
				'consultation_prescription' => $row['consultation_prescription'],
				'consultation_status' => $row['consultation_status']
			);
			$array[] = $newRow;
			
			
		}
		
		return array_reverse($array);
		
    }

	public function sendlink($data, $id) {
		$this->db->where('consultation_id', $id);
		$this->db->update('consultations', $data);
	}

	public function addPrescription($data, $id) {
		$this->db->where('consultation_id', $id);
		$this->db->insert('consultations', $data);
	}
	public function cancelConsultation($data, $id) {
		$this->db->where('consultation_id', $id);
		$this->db->update('consultations', $data);
	}
	public function doneConsultation($data, $id) {
		$this->db->where('consultation_id', $id);
		$this->db->update('consultations', $data);
	}
	
	// transaction for consultation
	public function get_transactions_count() {
        return $this->db->count_all("transactions_tbl");
    }

    public function get_transactions($limit, $start) {
		$this->db->where("status =", "Approved")->limit($limit, $start);
		$q = $this->db->get("transactions_tbl");

		$array = array();

		foreach($q->result_array() as $row) {

			$result = $this->receptionist_model->getUserInfoParent($row['parent_id']);
			$result2 = $this->receptionist_model->getUserInfoPatient($row['patient_id']);
			$result3 = $this->receptionist_model->getConsultationInfo($row['consultation_id']);

			$getInfo = (array) $result;
			$getInfo2 = (array) $result2;
			$getInfo3 = (array) $result3;

			$newRow = array(
				'transaction_id' => (int) $row['transaction_id'],
				'consultation_id' => (int) $row['consultation_id'],
				'parent_id' => (int) $row['parent_id'],
				'patient_id' => (int) $row['patient_id'],
				'parent_name' => $getInfo[0]['parent_name'],
				'patient_name' => $getInfo2[0]['patient_name'],
				'date_consultation' => $getInfo3[0]['date_consultation'],
				'consultation_proof_of_transaction' => $getInfo3[0]['consultation_proof_of_transaction'],
				'consultation_status' => $getInfo3[0]['consultation_status'],
				'status' => $row['status']
			);
			$array[] = $newRow;
			
			
		}
		
		return array_reverse($array);
		
    }

	// immunization records
	public function get_immunizationrecords_count() {
        return $this->db->count_all("immunization_record");
    }

	public function get_immunizationrecords($limit, $start) {
		$this->db->order_by('immunization_record_id','DESC')->limit($limit, $start);
		$q = $this->db->get("immunization_record");

		$array = array();

		foreach($q->result_array() as $row) {

			$result = $this->receptionist_model->getUserInfoParent($row['parent_id']);
			$result2 = $this->receptionist_model->getUserInfoPatient($row['patient_id']);
			$getInfo = (array) $result;
			$getInfo2 = (array) $result2;

			$newRow = array(
				'immunization_record_id' => (int) $row['immunization_record_id'],
				'parent_name' => $getInfo[0]['parent_name'],
				'patient_name' => $getInfo2[0]['patient_name'],
				'patient_id' => $row['patient_id'],
				'date' => $row['date'],
				'vaccine' => $row['vaccine'],
				'route' => $row['route']
			);
			$array[] = $newRow;
			
			
		}
		
		return array_reverse($array);
		
    }

	public function addImmunizationRecord($array) {
		$this->db->insert('immunization_record', $array);
	}

	public function getImmunizationRecord($id) {
		$q = $this->db->query("SELECT * FROM `immunization_record` WHERE `immunization_record_id` = '".$id."'"); 
		return $q->result_array();
	}
	public function editImmunizationRecord($data, $id) {
		$this->db->where('immunization_record_id', $id);
		$this->db->update('immunization_record', $data);
	}
	public function deleteImmunizationRecord($id) {
		$this->db->where('immunization_record_id', $id);
		$this->db->delete('immunization_record');
	}
	
	//parent lsikt
	public function get_parents_count() {
        return $this->db->count_all("parents_tbl");
    }

	public function get_parents($limit, $start) {
		$this->db->order_by('parent_id','DESC')->limit($limit, $start);
		$q = $this->db->get("parents_tbl");

		$array = array();

		foreach($q->result_array() as $row) {
			$newRow = array(
				'parent_id' => (int) $row['parent_id'],
				'parent_name' => $row['parent_name'],
				'parent_username' => $row['parent_username'],
				'parent_phonenumber' => $row['parent_phonenumber']
			);
			$array[] = $newRow;
			
			
		}
		
		return array_reverse($array);
		
    }

	//patient list
	public function get_patients_count() {
        return $this->db->count_all("patients_tbl");
    }
	public function get_patients($limit, $start) {
		$this->db->order_by('patient_id','DESC')->limit($limit, $start);
		$q = $this->db->get("patients_tbl");

		$array = array();

		foreach($q->result_array() as $row) {
			$newRow = array(
				'patient_id' => (int) $row['patient_id'],
				'patient_name' => $row['patient_name'],
				'patient_gender' => $row['patient_gender'],
				'patient_birthdate' => $row['patient_birthdate'],
				'parent_name' => $this->receptionist_model->getUserInfoPatientGetParentName($row['patient_id'])
			);
			$array[] = $newRow;
		}
		
		return array_reverse($array);
		
    }

	public function get_viewImmunizationRecords($patient_id) {
		$this->db->order_by('patient_id','DESC');
		$q = $this->db->where('patient_id', $patient_id)->get("immunization_record");

		$array = array();

		foreach($q->result_array() as $row) {
			$newRow = array(
				'immunization_record_id' => $row['immunization_record_id'],
				'patient_id' => $row['patient_id'],
				'date' => $row['date'],
				'vaccine' => $row['vaccine'],
				'route' => $row['route']
			);
			$array[] = $newRow;
		}
		
		return array_reverse($array);
		
    }

	public function addParents($data) {
		$this->db->insert('parents_tbl', $data);
	}
	
	public function addChild($array) {
		$this->db->insert('patients_tbl', $array);
	}
	public function editChild($data, $id) {
		$this->db->where('patient_id', $id);
		$this->db->update('patients_tbl', $data);
	}
	public function deleteChild($id) {
		$this->db->where('patient_id', $id);
		$this->db->delete('patients_tbl');
	}
	public function get_listChilds($parent_id) {
		$this->db->order_by('patient_id','DESC');
		$q = $this->db->where('parent_id', $parent_id)->get("patients_tbl");

		$array = array();

		foreach($q->result_array() as $row) {
			$newRow = array(
				'patient_id' => $row['patient_id'],
				'patient_name' => $row['patient_name'],
				'patient_gender' => $row['patient_gender'],
				'patient_birthdate' => $row['patient_birthdate']
			);
			$array[] = $newRow;
		}
		
		return array_reverse($array);
		
    }
}
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator extends MY_Controller {
	public function __construct() {
		parent::__construct();
		
		$this->load->model('administrator_model', null, true); // auto-connect model
		if(!$this->session->userdata('id') && !$this->session->userdata('selection') == "administrator") {
			redirect('home');
		}
		
		
	}
	// access privilege
	public function accessprivilege() {
		$data = array(
			'title' => 'Access Privilege',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'accessprivilege' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/accessprivilege";
        $config["total_rows"] = $this->administrator_model->get_accessprivileges_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['accessprivileges'] = $this->administrator_model->get_accessprivileges($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_accessprivilege.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	// appointment
	public function appointment() {
		$data = array(
			'title' => 'Appointment',
			'data' => $this->administrator_model->getId($this->session->id)
		);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_appointment.php', $data);
		$this->load->view('Administrator/Include/footer');
	}
	public function addAppointment() {
		// // converter date and time to timestamp
		// $date = '9/22/2021, 17:10:00';
		// $date = str_replace(' ', '/', $date);
		// $fulldate = explode('/', $date);

		// $time = '9/22/2021, 17:10:00';
		// $time = str_replace(' ', ':', $time);
		// $fulltime = explode(':', $time);

		
		// echo '<br/>';

		// echo  var_dump($fulldate) . ' <br/>';
		// echo var_dump($fulltime) . ' <br/>';

		// $dateandtime = $fulldate[0] . '/' . $fulldate[1]. '/' . $fulldate[2] . ' ' .$fulltime[1] .':'.$fulltime[2].':'.$fulltime[3]; 
		// echo strtotime($dateandtime); // 1632345000

		$this->form_validation->set_rules('appointment_description', 'Details', 'required');
		$this->form_validation->set_rules('appointment_datetime', 'Date Time', 'required');

		if($this->form_validation->run() == FALSE) {
			echo 'error';
		} else {
			$date = $this->input->post('appointment_datetime');
			$date = str_replace(' ', '/', $date);
			$date = str_replace(',', '', $date);
		  	$fulldate = explode('/', $date);

			$time = $this->input->post('appointment_datetime');
			$time = str_replace(' ', ':', $time);
			$time = str_replace(',', '', $time);
			$fulltime = explode(':', $time);
			$dateandtime = $fulldate[0] . '/' . $fulldate[1]. '/' . $fulldate[2] . ' ' .$fulltime[1] .':'.$fulltime[2].':'.$fulltime[3]; 
			$timestamp = strtotime($dateandtime);

			$date2 = $date;
			$date2 = str_replace(' ', '/', $date2);
			$date2 = str_replace(',', '', $date2);
		  	$fulldate2 = explode('/', $date2);

			$time2 = $date;
			$time2 = str_replace('/', ':', $time2);
			$time2 = str_replace(',', '', $time2);
			$fulltime2 = explode(':', $time2);

			$dateandtime2 = $fulldate2[0] . '/' . $fulldate2[1]. '/' . $fulldate2[2] . ' ' .$fulltime2[3] .':'.$fulltime2[4].':'.$fulltime2[5]; 
			$timestamp2 = strtotime($dateandtime2 . '+30 minutes');
			$newdateandtime2 = date('m/d/Y H:i:s', $timestamp2);

			$result = $this->administrator_model->getCheckTimeAppointment($timestamp, $timestamp2);

			if($result == 1) {
				 echo "exist";
			} else {
				$data = array(
					'appointment_timestamp'  => $timestamp,
					'appointment_timestamp_end'  => $timestamp2,
					'appointment_description'  => $this->input->post('appointment_description'),
					'appointment_datetime'  => $dateandtime,
					'appointment_datetime_end'  => $newdateandtime2,
					'appointment_status'=> 0
				);
				$this->administrator_model->addAppointment($data);
				echo "success"; //if success will return string "success"
			}
		}
	}
	public function getCheckTimeAppointment($start, $end) {

		$result = $this->administrator_model->getCheckTimeAppointment($start, $end);
		if($result == 1) {
			echo '1';
		} else {
			echo '0';
		}
	}
	public function getAppointment() {
		$event_data = $this->administrator_model->getAppointment();
		foreach($event_data->result_array() as $row) {
			$data[] = array(
				'id' => $row['appointment_id'],
				'title' => $row['appointment_description'],
				'start' => $row['appointment_datetime'],
				'end' => $row['appointment_datetime_end'],
				'appointment_parent_id' => $row['appointment_parent_id'],
				'appointment_timestamp' => $row['appointment_timestamp'],
				'appointment_timestamp_end' => $row['appointment_timestamp_end'],
				'appointment_status' => $row['appointment_status']
			);
		}
		echo json_encode($data);
	}
	public function updateAppointment() {
		if($this->input->post('id')) {
			$data = array(
				'title'   => $this->input->post('title'),
				'start_event' => $this->input->post('start'),
				'end_event'  => $this->input->post('end')
			);

   			$this->administrator_model->updateAppointment($data, $this->input->post('id'));
		}
	}
	public function deleteAppointment() {
		if($this->input->post('id')) {
			$this->administrator_model->deleteAppointment($this->input->post('id'));
		}
	}
	public function index() {
		$AdministratorCode = "";

		$data = array(
			'title' => 'Administrator',
			'data' => $this->administrator_model->getId($this->session->id)
		);
		
		
		foreach($this->administrator_model->getId($this->session->id) as $userInfo) {
    		$AdministratorCode = $userInfo->admin_sms_code;
		}
		
		if(strlen($AdministratorCode) == 6) {
		    redirect('administrator/verification');
		} 
		
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_navigation', $data);
		$this->load->view('Administrator/Administrator_index', $data);
		$this->load->view('Administrator/Include/footer');
	}

    public function verification() {
        $AdministratorCode = "";
		foreach($this->administrator_model->getId($this->session->userdata('id')) as $userInfo) {
    		$AdministratorCode = $userInfo->admin_sms_code;
		}
		
		if(strlen($AdministratorCode) == 6) {
		} else if($AdministratorCode == "@@@@@@@@SUCCESS@@@@@@@@") {
		    redirect('administrator');
		}
		
        $data = array(
			'title' => 'Administrator',
			'data' => $this->administrator_model->getId($this->session->id), 
			'error' => ''
		);
		
		$this->form_validation->set_rules('otp', 'One Time Password', 'required');
        
        if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
    		$this->load->view('Administrator/Administrator_verification', $data);
    		$this->load->view('Administrator/Include/footer');
		} else {
		    $result = $this->administrator_model->submitOTP($this->session->id, $this->input->post('otp'));
		    if($result == "successfully") {
		        redirect('administrator');
		    } else {
		        
		        $data['error'] = 'OTP doesn\'t match.';
		        $this->load->view('Administrator/Include/header', $data);
        		$this->load->view('Administrator/Administrator_verification', $data);
        		$this->load->view('Administrator/Include/footer');
		    }
		}
    }
	
	// chats
	public function getChats($code = "", $id = "") {
		//1-doctor
		//2-admi
		//3-receptionist
		//4-parent
		
		$selection = "";
		if($this->session->selection == "doctor") { $selection = 1; }
		else if($this->session->selection == "administrator") { $selection = 2; }
		else if($this->session->selection == "receptionist") { $selection = 3; }
		else if($this->session->selection == "parent") { $selection = 4; }

		
		//if($this->doctor_model->checkChatCode($this->session->id, $selection, $code) == 1) { 
		//	redirect('home');
		//}

		$result = $this->administrator_model->getChats($code, $id);
		echo $result;
	}
	public function getPreviouslyChats($code = "", $id = "") {
		//1-doctor
		//2-admin
		//3-receptionist
		//4-parent

		$selection = "";
		if($this->session->selection == "doctor") { $selection = 1; }
		else if($this->session->selection == "administrator") { $selection = 2; }
		else if($this->session->selection == "receptionist") { $selection = 3; }
		else if($this->session->selection == "parent") { $selection = 4; }

		
		//if($this->doctor_model->checkChatCode($this->session->id, $selection, $code) == 1) { 
		//	redirect('home');
		//}

		$result = $this->administrator_model->getPreviouslyChats($code, $id);
		echo $result;
	}

	public function messages($code = "") {
		$data = array(
			'title' => 'Messages',
			'data' => $this->administrator_model->getId($this->session->id),
			'code' => $code,
		);
		if($code == "") {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/messages_idle', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$selection = "";
			if($this->session->userdata('selection') == "doctor") { $selection = 1; }
			else if($this->session->userdata('selection') == "administrator") { $selection = 2; }
			else if($this->session->userdata('selection') == "receptionist") { $selection = 3; }
			else if($this->session->userdata('selection') == "parent") { $selection = 4; }

			if($this->administrator_model->checkChatCode($this->session->userdata('id'), $selection, $code) == 0) {
				$this->load->view('Administrator/Include/header', $data);
				$this->load->view('Administrator/messages', $data);
				$this->load->view('Administrator/Include/footer');
			} else {
				redirect('administrator/messages?error=noexists');
			}
		}
	}
	public function send() {
		$this->form_validation->set_rules('messages', 'Messages', 'required|min_length[5]');
		$this->form_validation->set_rules('code', 'Code', 'required');

		$selection = "";
		if($this->session->userdata('selection') == "doctor") { $selection = 1; }
		else if($this->session->userdata('selection') == "administrator") { $selection = 2; }
		else if($this->session->userdata('selection') == "receptionist") { $selection = 3; }
		else if($this->session->userdata('selection') == "parent") { $selection = 4; }

		if($this->administrator_model->checkChatCode($this->session->userdata('id'), $selection, $code) == 0) {
			if($this->form_validation->run() == FALSE) {
				echo validation_errors();
			} else {
				$querys = array(
					'chats_info_code' => $this->input->post('code'),
					'chats_account_type' => $selection,
					'chats_id'  => $this->session->id,
					'chats_message' =>$this->input->post("messages"),
					'time' => time()
				);
				$result = $this->administrator_model->send($querys);
				echo '';
			}
		} else {
			echo 'noexists';
		}
	}
	public function getNameandActive($code) {
		echo $this->administrator_model->getNameandActives($code, $this->session->id);
	}

	// change password
	public function change_password() {
		$data = array(
			'title' => 'Administrator',
			'data' => $this->administrator_model->getId($this->session->id)
		);

		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/change_password', $data);
		$this->load->view('Administrator/Include/footer');
	}
	public function change_password2() {
		
		$this->form_validation->set_rules('oldpassword', 'Current Password', 'required|min_length[5]|callback_password_check');
		$this->form_validation->set_rules('newpassword', 'New Password', 'required|min_length[5]');
		$this->form_validation->set_rules('retypenewpassword', 'Retype New Password', 'required|min_length[5]|matches[newpassword]', 
            array(
                "matches" => "New password and Re-Enter new password should be the same"
            )
        );
		if($this->form_validation->run() == FALSE) {
			echo validation_errors();
		} else {
			$result = $this->administrator_model->change_password($this->session->id, md5($this->input->post('oldpassword')), md5($this->input->post('newpassword')), md5($this->input->post('retypenewpassword')));
			if($result == '') {
				echo 'success';
			} else {
				echo $result;
			}
		}
	}
	public function password_check($password) {
		$getCurrPass = "";
		foreach ($this->administrator_model->getPassword($this->session->id) as $userInfo) {
			$getCurrPass = $userInfo->admin_password;
		}

		if($getCurrPass == md5($password)) {
			return true;
		} else {
			$this->form_validation->set_message('password_check', '{field} is not the same with the old password');
			return false;
		}

	}

	// inquiries 
	public function inquiries() {
		$data = array(
			'title' => 'Inquiries',
			'content' => 'Inquiries'
		);
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_inquiries');
		$this->load->view('Administrator/Include/footer');
	}

	public function inquiries_list() {
		// import database
		$this->load->database();

		// import model
		$this->load->model('administrator_model');

		$data = array(
			'title' => 'Inquiries',
			'inquiries' => $this->administrator_model->getInquiries(), // get all data in inquiries
			'content' => 'Inquiries',
			'data' => $this->administrator_model->getId($this->session->id)
		);
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_inquiries_list');
		$this->load->view('Administrator/Include/footer');
	}

	public function delete() {
		$data = $this->uri->segment(3);
		$this->administrator_model->deleteInquiries($data);
		redirect("../administrator/inquiries_list");
	}

	public function view() {
		$id = $this->uri->segment(3);
		

		$data = array(
			'title' => 'Inquiries View',
			'inquiries_view' => $this->administrator_model->getInquiriesById($id),
			'data' => $this->administrator_model->getId($this->session->id)
		);
		
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_inquiries_view', $data);
		$this->load->view('Administrator/Include/footer');
	}

	public function logout() {
        $this->administrator_model->modelLogout($this->session->id);
        
		$data = $this->session->all_userdata();
		foreach($data as $row => $rows_value) {
			$this->session->unset_userdata($row);
		}
		
		redirect('home');
	}

	// consultation
	public function consultation() {
		$data = array(
			'title' => 'Consultation',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'consultations' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/consultation";
        $config["total_rows"] = $this->administrator_model->get_consultations_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['consultations'] = $this->administrator_model->get_consultations($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_consultation.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	public function sendlink() {
		$this->form_validation->set_rules('id', 'Consultation ID', 'required');
		$this->form_validation->set_rules('googlelink', 'Google Link', 'required');

		if($this->form_validation->run() == FALSE) {
			redirect("administrator/consultation");
		} else {
			$datas = array(
				"googlelink" => $this->input->post('googlelink') 
			);
			$this->administrator_model->sendlink($datas, $this->input->post('id'));
			redirect("administrator/consultation?success");
		}
	}

	public function addPrescription() {
		$this->form_validation->set_rules('prescription_id', 'Consultation ID', 'required');
		$this->form_validation->set_rules('prescription', 'Prescription', 'required');

		if($this->form_validation->run() == FALSE) {
			redirect("administrator/consultation");
		} else {
			$datas = array(
				"consultation_prescription" => $this->input->post('prescription', true) 
			);
			$this->administrator_model->addPrescription($datas, $this->input->post('prescription_id', true));
			redirect("administrator/consultation?success");
		}
	}

	public function cancelConsultation() {

		if(is_numeric($this->uri->segment(3)) == 1) {
			$datas = array(
				"consultation_status" => "Cancelled"
			);
			$this->administrator_model->cancelConsultation($datas, $this->uri->segment(3));
			redirect("administrator/consultation?success");
		} else {
			redirect("administrator/consultation");
		}
	}

	public function doneConsultation() {
		if(is_numeric($this->uri->segment(3)) == 1) {
			$datas = array(
				"consultation_status" => "Approved"
			);
			$this->administrator_model->doneConsultation($datas, $this->uri->segment(3));
			redirect("administrator/consultation?success");
		} else {
			redirect("administrator/consultation");
		}
	}

	// transaction
	public function transaction() {
		$data = array(
			'title' => 'Transaction',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'transactions' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/transaction";
        $config["total_rows"] = $this->administrator_model->get_transactions_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['transactions'] = $this->administrator_model->get_transactions($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_transaction.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	public function immunizationrecord() {
		$data = array(
			'title' => 'Immunization Record',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'immunizationrecords' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/immunizationrecords";
        $config["total_rows"] = $this->administrator_model->get_immunizationrecords_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['immunizationrecords'] = $this->administrator_model->get_immunizationrecords($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_immunizationrecord.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	public function addImmunizationRecord() {
		$id = $this->uri->segment(3);
		if(strlen($id) == 0) {
			redirect("administrator/immunizationrecord");
		}
		$patient = $this->administrator_model->getUserInfoPatient($id);
		$data = array(
			'title' => 'Add Immunization Record',
			'data' => $this->administrator_model->getId($this->session->id),
			'patient_name' => $this->administrator_model->getUserInfoPatientName($patient[0]['patient_id']),
			'parent_name' => $this->administrator_model->getUserInfoPatientGetParentName($patient[0]['parent_id']),
			'parent_id' => $patient[0]['parent_id']
		);

		$this->form_validation->set_rules('dates', 'Date', 'required');
		$this->form_validation->set_rules('vaccine', 'Vaccine', 'required');
		$this->form_validation->set_rules('route', 'Route', 'required');
        
		if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/Administrator_addImmunizationRecord', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$datas = [
				'patient_id' => $id,
				'parent_id' => $data['parent_id'],
				'date' => $this->input->post("dates"),
				'vaccine' => $this->input->post("vaccine"),
				'route' => $this->input->post("route")
			];
			$this->administrator_model->addImmunizationRecord($datas);
			redirect("administrator/immunizationrecord?success");
		}
	}
	public function editImmunizationRecord() {
		$id = $this->uri->segment(3);
		if(strlen($id) == 0) {
			redirect("administrator/immunizationrecord");
		}
		$result = $this->administrator_model->getImmunizationRecord($id);
		$result2 = (array) $result;
		$patient_name = $this->administrator_model->getUserInfoPatientName($result2[0]['patient_id']);
		$parent_name = $this->administrator_model->getUserInfoPatientGetParentName($result2[0]['parent_id']);

		$data = array(
			'title' => 'Edit Immunization Record',
			'data' => $this->administrator_model->getId($this->session->id),
			'patient_name' => $patient_name,
			'parent_name' => $parent_name,
			'parent_id' => $result2[0]['parent_id'],
			'immunizations' => $result
		);

		$this->form_validation->set_rules('dates', 'Date', 'required');
		$this->form_validation->set_rules('vaccine', 'Vaccine', 'required');
		$this->form_validation->set_rules('route', 'Route', 'required');
        
		if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/Administrator_editImmunizationRecord', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$datas = [
				'date' => $this->input->post("dates"),
				'vaccine' => $this->input->post("vaccine"),
				'route' => $this->input->post("route")
			];
			$this->administrator_model->editImmunizationRecord($datas, $id);
			redirect("administrator/immunizationrecord?success");
		}
	}
	public function deleteImmunizationRecord() {
		$id = $this->uri->segment(3);
		$this->administrator_model->deleteImmunizationRecord($id);
		redirect("administrator/immunizationrecord?success");
	}
	public function viewImmunizationRecord($patient_id) {
		if(strlen($patient_id) == 0) {
			redirect("administrator/immunizationrecord");
		}

		$data = array(
			'title' => 'View Immunization Record',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'viewImmunizationRecords' => '',
			'patient_name' => $this->administrator_model->getUserInfoPatientName($patient_id),
			'patient_id' => $patient_id
		);
        $data['viewImmunizationRecords'] = $this->administrator_model->get_viewImmunizationRecords($patient_id);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_viewImmunizationRecord.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	// parents
	public function parents() {
		$data = array(
			'title' => 'Parent List',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'parents' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/parents";
        $config["total_rows"] = $this->administrator_model->get_parents_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['parents'] = $this->administrator_model->get_parents($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_parents.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}

	public function addParents() {
		$data = array(
			'title' => 'Add Parent',
			'data' => $this->administrator_model->getId($this->session->id)
		);

		$this->form_validation->set_rules('parent_name', 'Parent Name', 'required');
		$this->form_validation->set_rules('parent_emailaddress', 'Parent Email', 'required|valid_email');
		$this->form_validation->set_rules('parent_phonenumber', 'phonenumber', 'required');
        
		if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/Administrator_addparent', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$datas = [
				'parent_name' => $this->input->post("parent_name"),
				'parent_username' => $this->input->post("parent_username"),
				'parent_emailaddress' => $this->input->post("parent_emailaddress"),
				'parent_phonenumber' => $this->input->post("parent_phonenumber"),
				'verified' => 1
			];
			$this->administrator_model->addParents($datas);
			redirect("administrator/parents?success");
		}
	}
    
	public function addChild() {
		$id = $this->uri->segment(3);
		if(strlen($id) == 0) {
			redirect("administrator/parents");
		}
		$data = array(
			'title' => 'Add Child',
			'data' => $this->administrator_model->getId($this->session->id),
			'parent_name' => $this->administrator_model->getUserInfoParentName($id)
		);

		$this->form_validation->set_rules('patient_name', 'Patient Name', 'required');
		$this->form_validation->set_rules('patient_gender', 'Patient Gender', 'required');
		$this->form_validation->set_rules('patient_birthdate', 'Patient Birthdate', 'required');
        
		if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/Administrator_addChild', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$datas = [
				'patient_name' => $this->input->post("patient_name"),
				'patient_gender' => $this->input->post("patient_gender"),
				'patient_birthdate' => $this->input->post("patient_birthdate"),
				'parent_id' => $id
			];
			$this->administrator_model->addChild($datas);
			redirect("administrator/parents?success");
		}
	}
	public function editChild() {
		$id = $this->uri->segment(3);
		if(strlen($id) == 0) {
			redirect("administrator/parents");
		}
		$result = $this->administrator_model->getUserInfoPatient($id);
		$result2 = (array) $result;
		$parent_name = $this->administrator_model->getUserInfoPatientGetParentName($result2[0]['parent_id']);

		$data = array(
			'title' => 'Edit Child',
			'data' => $this->administrator_model->getId($this->session->id),
			'parent_name' => $parent_name,
			'parent_id' => $result2[0]['parent_id'],
			'childs' => $result
		);

		$this->form_validation->set_rules('patient_name', 'Patient Name', 'required');
		$this->form_validation->set_rules('patient_gender', 'Patient Gender', 'required');
		$this->form_validation->set_rules('patient_birthdate', 'Patient Birthdate', 'required');
        
		if($this->form_validation->run() == FALSE) {
			$this->load->view('Administrator/Include/header', $data);
			$this->load->view('Administrator/Administrator_editChild', $data);
			$this->load->view('Administrator/Include/footer');
		} else {
			$datas = [
				'patient_name' => $this->input->post("patient_name"),
				'patient_gender' => $this->input->post("patient_gender"),
				'patient_birthdate' => $this->input->post("patient_birthdate")
			];
			$this->administrator_model->editChild($datas, $id);
			redirect("administrator/listChild/".$result2[0]['parent_id']."?success");
		}
	}
	public function listChild() {
		$id = $this->uri->segment(3);
		if(strlen($id) == 0) {
			redirect("administrator/parents");
		}
		$data = array(
			'title' => 'Child List',
			'data' => $this->administrator_model->getId($this->session->id),
			'listChilds' => '',
			'parent_name' =>  $this->administrator_model->getUserInfoParentName($id)
		);
        $data['listChilds'] = $this->administrator_model->get_listChilds($id);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_listChild.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}
	public function deleteChild() {
		$id = $this->uri->segment(3);
		$this->administrator_model->deleteChild($id);
		redirect("administrator/parents?success");
	}
	public function patients() {
		$data = array(
			'title' => 'Parent List',
			'data' => $this->administrator_model->getId($this->session->id),
			'links' => '',
			'patients' => ''
		);

		$config = array();
        $config["base_url"] = base_url() . "administrator/patients";
        $config["total_rows"] = $this->administrator_model->get_patients_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 3;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['patients'] = $this->administrator_model->get_patients($config["per_page"], $page);

		//Below code will help you to  generate calendar in view
		$this->load->view('Administrator/Include/header', $data);
		$this->load->view('Administrator/Administrator_patients.php', $data);
		$this->load->view('Administrator/Include/footer', $data);
	}
}
?>
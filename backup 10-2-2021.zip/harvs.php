<?php
    $host = "localhost";
    $user = "u964751242_anas";
    $dbname = "u964751242_anas";
    $pass = "Feutech123";
    $conn = mysqli_connect($host, $user, $pass, $dbname);
    
    /**if($conn) {
        echo 'Database is connected';
    } else {
        echo 'Database is not connected';
    }**/
    
    $action = $_GET['action'];
    if(isset($_GET['action'])) {
        if($action == "insert") {
            $email = $_GET['email'];
            $password = $_GET['password'];
            
            $result = mysqli_query($conn, "INSERT INTO `accounts_tbl` (`email`, `password`) VALUES ('$email', '$password')");
            
            if($result == "successfully") {
                echo '';
            } else {
                echo 'Error';
            }
        } else if($action == "get") {
            $query = mysqli_query($conn, "SELECT * FROM `accounts_tbl`");
            
            $array = array();
            
            while($data = mysqli_fetch_array($query)) {
                $newRow = array(
                    'email' => $data['email'],
                    'password' => $data['password']
                );
                $array[] = $newRow;
            }
            
            echo json_encode($array);
        }
    }
?>